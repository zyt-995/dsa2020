"""
括号交叉算不正确配对，例如"12{34[78}ab]"就不算正确配对。但是一对括号被包含在另一对括号里面，例如"12{ab[8]}"不影响正确性。

输入
第一行为整数n(n<40)，接下来有n行，每行一个无空格的字符串，长度小于1000。
输出
对每行字符串，如果括号配对，输出"YES"，否则输出"NO"。
样例输入
2
12{ab[8]}
12{34[78}ab]
样例输出
YES
NO
"""

n = int(input())
pairs = {')': '(', ']': '[', '}': '{'}

for _ in range(n):
    s = input().strip()
    stack = []
    valid = True
    for ch in s:
        if ch in '([{':
            stack.append(ch)
        elif ch in ')]}':
            if not stack or stack[-1] != pairs[ch]:
                valid = False
                break
            stack.pop()
    if valid and not stack:
        print("YES")
    else:
        print("NO")

"""
输入
多组数据，每组数据占一行，且都是由(、)、[、]、*、/这六种字符组成。
/*和 */ 也算一对括号
输出
每组数据输出一行，如果括号能匹配成功，输出True，否则输出False。括号匹配规则是：
( 和 ) 匹配
[ 和 ] 匹配
/* 和 */ 匹配
括号嵌套算匹配，括号交叉不算。比如 ([/**/])算匹配，([)]算交叉，不匹配。
如果含有冗余字符也算匹配失败，例如 /***/ 是匹配失败的因为中间多了一个*。
样例输入
()/*[()]*/
*/**/
样例输出
True
False
"""

r""" 
坑：
1.拆分输入字符  */和/* 不能单独拆开
2. 考虑多余字符的情况 /***/ 是匹配失败的因为中间多了一个*
"""

pairs = {')': '(', ']': '[', '*/': '/*'}
while True:
    try:
        s = input().strip()
        stack = []
        left = []
        valid = True
        i = 0
        chs = []
        while i < len(s):
            if s[i] in "()[]":
                chs.append(s[i])
                i+=1
            else:
                if s[i:i+2] == '/*':
                    chs.append('/*')
                    i += 2
                elif s[i:i+2] == '*/':
                    chs.append('*/')
                    i += 2
                else:
                    chs.append(s[i])
                    i += 1
        for ch in chs:
            if ch in pairs.values():
                stack.append(ch)
            elif ch in pairs.keys():
                if not stack or stack[-1] != pairs[ch]:
                    valid = False
                    break
                stack.pop()
            else:
                left.append(ch)
        if valid and not stack and not left:
            print(True)
        else:
            print(False)
    except EOFError:
        break

"""
输入:
多行表达式，每一行是一个语法正确的，但可能有多余括号四则运算表达式。仅含非负整数、+、*、()。* 优先级高于 +。

输出:
对应每行输入，输出简化后的表达式，删除所有不改变运算顺序的多余括号。

样例输入
(1+11)
((1+2))+3*(4+5)
1+(2+3)
样例输出
1+11
1+2+3*(4+5)
1+(2+3)
"""
"""
思路：构建表达式的抽象语法树 (Abstract Syntax Tree, AST),然后遍历 AST，根据优先级规则打印表达式。
数字节点 (Number Node)： 叶子节点，存储数字本身。
操作符节点 (Operator Node)： 内部节点，存储操作符 (+ 或 *)，并有两个子节点（左操作数和右操作数）。
"""
import sys

class Node:
    def __init__(self, value, left=None, right=None, is_op=False, precedence=0):
        self.value = value
        self.left = left
        self.right = right
        self.is_op = is_op # 是否是操作符节点
        self.precedence = precedence # 操作符的优先级 (0 for num, 1 for +, 2 for *)


def get_precedence(op_char): #获取优先级
    if op_char == '+':
        return 1
    elif op_char == '*':
        return 2
    return 0

# 将输入字符串转换为一个 Token 列表
# 注意原表达式中两个数字连接在一起是一个二位数，不能拆开
def tokenize(expression_str):
    tokens = []
    i = 0
    while i < len(expression_str):
        char = expression_str[i]
        if char.isdigit():
            num_str = ""
            while i < len(expression_str) and expression_str[i].isdigit():
                num_str += expression_str[i]
                i += 1
            tokens.append(num_str)
            continue
        elif char in ('+', '*', '(', ')'):
            tokens.append(char)
        i += 1
    return tokens

tokens = []
current_token_index = 0 #跟踪当前正在解析的 Token

def peek_token():#查看下一个即将被处理的 token，但不移动 current_token_index
    if current_token_index < len(tokens):
        return tokens[current_token_index]
    return None

def consume_token():#获取当前 token 并将 current_token_index 向前移动一位。
    global current_token_index
    if current_token_index < len(tokens):
        token = tokens[current_token_index]
        current_token_index += 1
        return token
    raise ValueError("Unexpected end of expression")


def parse_factor():#最底层，只处理数字和括号
    token = peek_token() #查看下一个 token
    if token == '(':
        consume_token()  # 消费左括号 '('
        node = parse_expression()  # 递归解析括号内的整个表达式
        # 期望括号内表达式解析完成后是右括号 ')'
        if peek_token() != ')': # 异常处理：如果期望是 ')' 但不是，表示括号不匹配
            raise ValueError("Mismatched parentheses: expected ')'")
        consume_token()  # 消费右括号 ')'
        return node # 返回括号内表达式的 AST 节点
    elif token.isdigit():# 检查 token 是否存在且是数字
        consume_token()  # 消费数字 token
        return Node(int(token), is_op=False, precedence=0) # 创建一个数字节点
    else:
        raise ValueError(f"Unexpected token in parse_factor: {token}")


def parse_term():#处理乘法
    left_node = parse_factor()
    while peek_token() == '*':
        op = consume_token()  # Consume '*'
        right_node = parse_factor()
        left_node = Node(op, left=left_node, right=right_node, is_op=True, precedence=get_precedence(op))
    return left_node


def parse_expression():#处理加法
    left_node = parse_term()
    while peek_token() == '+':
        op = consume_token()  # Consume '+'
        right_node = parse_term()
        left_node = Node(op, left=left_node, right=right_node, is_op=True, precedence=get_precedence(op))
    return left_node


def parse_full_expression(expression_str):#解析整个表达式字符串并返回 AST 根节点。
    global tokens, current_token_index
    tokens = tokenize(expression_str)
    current_token_index = 0
    ast_root = parse_expression()
    if current_token_index != len(tokens):
        raise ValueError("Extra tokens at end of expression")
    return ast_root

# 遍历抽象语法树 (AST) 并将其转换回字符串表达式
#从根开始输出时，只有当：当前运算优先级 < 父节点的优先级（比如 + 嵌套在 * 里），或者当前运算优先级 == 父节点，但你是右孩子（因为左结合），才加括号。
def print_ast_simplified(node, parent_op_precedence=-1, is_right_child=False):#通过判断当前操作符优先级和父节点优先级的比较，是否是右孩子，来决定是否加括号。
    if not node.is_op:
        return str(node.value)  # 数字节点直接打印值

    current_op_precedence = node.precedence# 获取当前操作符节点的优先级。

    # 判断是否需要为当前节点对应的子表达式添加括号
    should_wrap = False

    # 规则1：当前操作符的优先级严格低于父操作符的优先级
    # 例如：A * (B + C) 中，(B + C) 的优先级 (1) < A * 的优先级 (2)，需要括号
    if current_op_precedence < parent_op_precedence:
        should_wrap = True
    # 规则2：当前操作符的优先级等于父操作符的优先级，并且当前节点是右孩子
    # 例如：1 + (2 + 3) 中，(2 + 3) 是右孩子，其优先级 (1) == 1 + 的优先级 (1)，需要括号以保留运算顺序。
    elif current_op_precedence == parent_op_precedence and is_right_child:
        should_wrap = True

    # 递归打印左右子节点
    # 左子节点永远不是其父节点的右孩子 (is_right_child=False)
    left_str = print_ast_simplified(node.left, current_op_precedence, False)
    # 右子节点永远是其父节点的右孩子 (is_right_child=True)
    right_str = print_ast_simplified(node.right, current_op_precedence, True)

    result = left_str + str(node.value) + right_str

    if should_wrap:
        return "(" + result + ")"
    else:
        return result

def main():
    for line in sys.stdin:
        expression = line.strip()
        ast_root = parse_full_expression(expression)
        # 根节点没有父节点，所以 parent_op_precedence 设为 -1 (最低)
        # 根节点也不是右孩子 (is_right_child=False)
        simplified_expression = print_ast_simplified(ast_root, -1, False)
        sys.stdout.write(simplified_expression + "\n")

if __name__ == "__main__":
    main()

"""
每次把所有已有的线段三等分，删除中间的部分；假设操作n步之后剩下的每个小区间为一个单位长度。
共进行 n 步操作；
第 n 步结束后，你需要输出长度为 3^n 的字符串，只保留“未被删除”的位置为 *，其余位置为 -。

样例输入
3
样例输出
*-*---*-*---------*-*---*-*
"""
"""
思路：
我们初始化一个长度为 3^n 的字符串，全部用 '*' 表示；
每一轮从当前的字符串中找出每一段连续的 '*'，将它三等分，将中间部分替换为 '-'；
重复进行 n 轮操作；
"""

def cantor(n):
    length = 3 ** n
    s = ['*'] * length

    def remove_middle(l, r, depth):
        if depth == 0:
            return
        third = (r - l + 1) // 3 #一段的长度
        mid_start = l + third
        mid_end = r - third
        for i in range(mid_start, mid_end + 1):
            s[i] = '-'
        remove_middle(l, mid_start - 1, depth - 1)
        remove_middle(mid_end + 1, r, depth - 1)

    remove_middle(0, length - 1, n)
    print(''.join(s))

# 示例使用
n = int(input())
cantor(n)

"""
描述
已知矩阵的大小定义为矩阵中所有元素的和。给定一个矩阵，你的任务是找到最大的非空(大小至少是1 * 1)子矩阵。

比如，如下4 * 4的矩阵

0 -2 -7 0
9 2 -6 2
-4 1 -4 1
-1 8 0 -2

的最大子矩阵是

9 2
-4 1
-1 8

这个子矩阵的大小是15。
输入
输入是一个N * N的矩阵。输入的第一行给出N (0 < N <= 100)。再后面的若干行中，依次（首先从左到右给出第一行的N个整数，再从左到右给出第二行的N个整数……）给出矩阵中的N2个整数，整数之间由空白字符分隔（空格或者空行）。已知矩阵中整数的范围都在[-127, 127]。
输出
输出最大子矩阵的大小。
样例输入
4
0 -2 -7 0 9 2 -6 2
-4 1 -4  1 -1

8  0 -2
样例输出
15

"""
import sys

def kadane(arr):
    """
    Kadane's algorithm (卡丹算法) 用于查找一维数组中连续子数组的最大和。
    该实现能够正确处理数组中所有数字都是负数的情况。

    Args:
        arr: 一个整数列表，表示一维数组。

    Returns:
        数组中连续子数组的最大和。
    """
    # 如果输入数组为空，根据问题约束（非空子矩阵），这里理论上不会发生，但作为健壮性检查，可以返回0或负无穷。
    # 根据此题要求“非空子矩阵”，所以传入的arr不会是空。
    if not arr:
        return 0

    # max_so_far: 记录目前为止找到的最大子数组和。
    max_so_far = arr[0]
    # current_max: 记录以当前元素结尾的子数组的最大和。
    current_max = arr[0]

    # 遍历数组从第二个元素开始（索引1）
    for i in range(1, len(arr)):
        # 对于当前元素 arr[i]，有两种选择来更新 current_max：
        # 1. 重新开始一个新的子数组，只包含 arr[i] 本身。
        # 2. 将 arr[i] 添加到当前正在累积的子数组 (current_max + arr[i])。
        # 我们选择两者中较大的那个，因为我们要确保以 arr[i] 结尾的子数组和最大。
        current_max = max(arr[i], current_max + arr[i])

        # 每次更新 current_max 后，都与 max_so_far 比较，更新全局的最大和。
        max_so_far = max(max_so_far, current_max)

    return max_so_far  # 返回最终找到的最大子数组和


def solve():
    # 读取矩阵的维度 N
    N = int(sys.stdin.readline())

    # 读取所有 N*N 个整数。
    # sys.stdin.read().split() 会读取所有剩余的输入内容（包括空格、换行符），
    # 并按空白字符分割成字符串列表。这是一个非常健壮的读取方式，可以处理不同格式的空白。
    all_numbers_str = sys.stdin.read().split()
    # 将字符串列表转换为整数列表
    matrix_elements = [int(x) for x in all_numbers_str]

    # 重构 N x N 的矩阵
    matrix = []
    idx = 0  # 用于跟踪 matrix_elements 中当前读取到的索引
    for _ in range(N):
        row = []  # 当前行
        for _ in range(N):
            row.append(matrix_elements[idx])  # 从扁平化的列表中取元素填充行
            idx += 1
        matrix.append(row)  # 将完整的行添加到矩阵中

    # 初始化最大子矩阵和为负无穷。
    max_submatrix_sum = -float('inf')

    # --- 核心算法：降维到一维问题 ---

    # 外层循环：选择子矩阵的“顶行” (r1)
    # r1 从 0 到 N-1 遍历
    for r1 in range(N):
        # 初始化一个临时的 1D 数组，用于存储当前“行切片”的每列的和。
        # 例如，如果 r1=0, r2=1，那么 column_sums[c] 将是 matrix[0][c] + matrix[1][c]。
        column_sums = [0] * N

        # 中层循环：选择子矩阵的“底行” (r2)
        # r2 从 r1 到 N-1 遍历，确保 r2 总是大于或等于 r1，形成有效的行切片。
        for r2 in range(r1, N):
            # 内层循环：遍历每一列 (c)
            # 在当前 r1 到 r2 的行切片中，累加每一列的元素到 column_sums 数组中。
            # 这样，column_sums[c] 就代表了从 r1 行到 r2 行，第 c 列所有元素的垂直和。
            for c in range(N):
                column_sums[c] += matrix[r2][c]

            # 此时，column_sums 数组就相当于一个一维数组，
            # 它的每个元素代表了在当前行切片（r1到r2）中对应列的累加和。
            # 我们现在要在这个一维数组中找到一个连续子数组，使其和最大。
            # 这正是 Kadane's algorithm 的用武之地。
            current_max_slice_sum = kadane(column_sums)

            # 将 Kadane's 算法返回的最大和与全局最大子矩阵和进行比较，更新最大值。
            if current_max_slice_sum > max_submatrix_sum:
                max_submatrix_sum = current_max_slice_sum

    # 打印最终的最大子矩阵和
    sys.stdout.write(str(max_submatrix_sum) + "\n")


# 调用 solve 函数开始执行程序
solve()

"""
描述
木材厂有一些原木，现在想把这些木头切割成一些长度相同的小段木头，需要得到的小段的数目是给定的。我们希望这些小段越长越好。你的任务是计算可以切出多少厘米长的小段木头，要求长度尽可能大。

木头长度的单位是厘米。每根原木的长度是正整数，切出来的小段长度也必须是正整数。

输入
第一行是两个正整数 N 和 K，表示有 N 根原木，需要切出 K 段小段木头。
接下来的 N 行中，每行有一个 1 到 10000 之间的正整数，表示每根原木的长度。

输出
输出一个整数，表示可以切出的小段木头的最大长度。如果无法切出至少 K 段，输出 0。

样例输入
3 7
232
124
456

样例输出
114
"""
def is_valid(length, woods, k):
    # 判断是否能用给定的长度切出至少 k 段
    return sum(wood // length for wood in woods) >= k

def max_piece_length(woods, k):
    left, right = 1, max(woods)
    best = 0

    while left <= right:
        mid = (left + right) // 2
        if is_valid(mid, woods, k):
            best = mid  # mid 可行，尝试更大
            left = mid + 1
        else:
            right = mid - 1

    return best

# 读取输入
N, K = map(int, input().split())
woods = [int(input()) for _ in range(N)]

# 特殊情况处理：无论如何都切不出K段
if sum(wood for wood in woods) < K:
    print(0)
else:
    print(max_piece_length(woods, K))


"""
输入两个整数 N 和 K，N 是库存网线数，K 是需要的网线数量。接下来 N 行是每条网线的长度（单位米，精确到厘米）。要找出一个最长的长度 L（单位米，精确到厘米），使得将库存中每条网线按 L 切割后，总段数不少于 K。若无法得到至少 1 厘米长的 K 条网线，输出 0.00，否则输出符合条件的最大 L。

样例输入
4 11
8.02.
7.43.
4.57
5.39
样例输出
2.00
"""
def is_valid(length, woods, k):
    # 判断是否能用给定的长度切出至少 k 段
    return sum(wood // length for wood in woods) >= k


def max_piece_length(woods, k):
    left, right = 1, max(woods)
    best = 0

    while left <= right:
        mid = (left + right) // 2
        if is_valid(mid, woods, k):
            best = mid  # mid 可行，尝试更大
            left = mid + 1
        else:
            right = mid - 1

    return f"{(best / 100):.2f}"


# 读取输入
N, K = map(int, input().split())
woods = [int(float(input()) * 100) for _ in range(N)]

# 特殊情况处理：无论如何都切不出K段
if sum(wood for wood in woods) < K :
    print("0.00")
else:
    print(max_piece_length(woods, K))

"""
题目描述
有 n 个牛棚排在一条直线上，每个牛棚位于不同的坐标位置。你需要将 c 头牛安置到这些牛棚中，使得任意两头牛之间的最小距离尽可能大。输出这个最大的最小距离。

输入
第一行包含两个整数 n 和 c（2 ≤ n ≤ 100,000，2 ≤ c ≤ n），分别表示牛棚数量和牛的数量。
接下来的 n 行，每行一个整数，表示每个牛棚的坐标位置（坐标范围：0 ≤ 坐标 ≤ 1,000,000,000）。

输出
输出一个整数，表示最大的最小距离。

样例输入
5 3
1
2
8
4
9

样例输出
3
"""
# 输入：坐标位置
def is_possible(positions, cows, distance):
    count = 1  # 第一头牛放在第一个牛棚
    last_position = positions[0]

    for pos in positions[1:]:
        if pos - last_position >= distance:
            count += 1
            last_position = pos
        if count >= cows:
            return True
    return False

def max_min_distance(n, c, stalls):
    stalls.sort()
    left = 1  # 最小间隔不能为0
    right = stalls[-1] - stalls[0]
    result = 0

    while left <= right:
        mid = (left + right) // 2
        if is_possible(stalls, c, mid):
            result = mid
            left = mid + 1  # 试图增大最小距离
        else:
            right = mid - 1  # 减小最小距离
    return result



n, c = map(int, input().split())
stalls = [int(input()) for _ in range(n)]

print(max_min_distance(n, c, stalls))

"""
谢老师要给学生调分，原分数x调整为ax+1.1^(ax)，其中a=b/1000000000（a 是一个 0 到 1 之间的常数,b是正整数）。要求找到最小正整数b，使调分后85分及以上的学生人数占比≥60%。输入是全班原始成绩（浮点数，40-100，人数≤100000），输出满足条件的最小b值。
为了简单起见，我们假设调整后分数超过100分也没有问题。

输入
一行以空格分隔的浮点数，分别代表每个学生的原始成绩。学生数量不超过100000，每个学生的原始成绩是一个在 [40, 100] 区间的浮点数。
输出
一个整数，使得至少60%学生不小于85分的正整数b的最小值。
样例输入
50.5 100.0 40.0
样例输出
791111236
"""
scores = list(map(float,input().split()))
scores.sort()
n = len(scores)
excellentN= int(n * 0.6) + (1 if n * 0.6 > int(n * 0.6) else 0)
border_value = scores[n-excellentN]

l, r, ans = 1, 10**9, 10**9
while l<=r:
    mid = (l+r)//2
    a = mid/10**9
    adjusted =  a*border_value+1.1**(a*border_value)
    if adjusted >=85:
        ans = mid
        r=mid-1
    else:
        l=mid+1

print(ans)

"""
一共有n场考试。假如你在i场考试中可以答对bi道题中的ai道，你的累计平均分定义为：100·Σai/Σbi。

输入
有多组测试数据，每组测试数据包括3行。
每组测试数据第一行有两个数n和k，接下来一行有n个数ai，最后一行n个数bi。
(1 ≤ k < n ≤ 1000) (1 ≤ ai ≤ bi ≤ 1, 000, 000, 000)。
输入的最后一行为0 0，不作处理。
输出
输出最高的累计平均分。（四舍五入到整数）
样例输入
3 1
5 0 2
5 1 6
4 2
1 2 7 9
5 6 7 9
0 0
样例输出
83
100
"""
while True:
    n,k=map(int,input().split())
    if n==k==0:
        break
    a=list(map(int,input().split()))
    b=list(map(int,input().split()))

    l = 0
    r = 1
    while r - l > 1e-6:
        mid = (l+r)/2
        values = [(a[i]-mid*b[i]) for i in range(n)]
        values.sort()
        total = sum(values[k:])
        if total>=0:
            l = mid
        else:
            r=mid
    print(round(l*100))

"""
给定一个由正整数组成的数组 costs（长度为 N），需要将其划分为 M 个连续的子数组（每个子数组至少包含一个元素）。求所有可能的划分方式中，每个子数组的元素和的最大值的最小可能值。

输入
第一行包含两个整数 N 和 M（1 ≤ N ≤ 100,000，1 ≤ M ≤ N）。
接下来的 N 行，每行一个正整数，表示数组 costs 的每个元素（1 ≤ 元素值 ≤ 10,000）。

输出
输出一个整数，表示所有划分方式中，各子数组元素和的最大值的最小可能值。

样例输入
7 5
100
400
300
100
500
101
400
样例输出
500
"""
N,M = map(int,input().split())
costs =[int(input()) for _ in range(N)]
low = max(costs)
high = sum(costs)
ans = high
while low<=high:
    mid = (low+high)//2
    period = 1
    this_p_cost = 0
    for c in costs:
        this_p_cost += c
        if this_p_cost > mid:
            period += 1
            this_p_cost = c
        else:
            continue

    if period <= M:
        ans = mid
        high = mid -1
    else:
        low=mid+1

print(ans)

"""
有 n 个圆形蛋糕，每个蛋糕的半径已知。需要将这些蛋糕平均分给 f+1 个人（包括你自己），使得每个人得到的蛋糕体积相等，且尽可能大。求每个人最多能得到多大体积的蛋糕（保留三位小数）。

输入
第一行包含两个整数 n 和 f（1 ≤ n, f ≤ 10,000），分别表示蛋糕数量和朋友数量。
第二行包含 n 个整数，每个整数表示一个蛋糕的半径 r（1 ≤ r ≤ 10,000）。

输出
输出一个浮点数，表示每个人最多能得到的蛋糕体积，结果保留三位小数。
"""
import math
n,f = map(int,input().split())
p_num = f+1
cakes_r = list(map(int,input().split()))
cakes_v = [math.pi*r*r for r in cakes_r]
low = 0
high = max(cakes_v)
while high - low > 1e-5:
    mid = (low+high)/2
    cake_num = 0
    for v in cakes_v:
        cake_num+=int(v/mid)
    if cake_num >= p_num:
        low = mid
    else:
        high = mid
print(f"{low:.3f}")

"""
总长度：L
原本中间的岩石数：N
至多可以移走的岩石数：M

输入
第一行包含三个整数L, N, M，相邻两个整数之间用单个空格隔开。
接下来N行，每行一个整数，表示每个岩石与起点的距离。岩石按与起点距离从近到远给出，且不会有两个岩石出现在同一个位置。
输出
一个整数，最长可能的最短跳跃距离。
样例输入
25 5 2
2
11
14
17
21
样例输出
4
"""

l, n, m = map(int, input().split())
rocks = [int(input()) for _ in range(n)]
rocks = [0] + rocks + [l]  # 加上起点和终点并排序

low = 1
high = l
ans = 0

while low <= high:
    mid = (low + high) // 2
    cur_pos = 0
    move_num = 0
    for i in range(1, len(rocks)):
        if rocks[i] - cur_pos < mid:
            # 岩石太近，跳不过去，移除rocks[i]
            move_num += 1
        else:
            cur_pos = rocks[i]
    if move_num > m:
        high = mid - 1
    else:
        ans = mid
        low = mid + 1

print(ans)

def binarySearch(a, p, key=lambda x: x):
    def search(L, R):  # 在a[L:R+1]范围内二分查找p
        if L > R:
            return None
        mid = (L + R) // 2
        if key(a[mid]) == p:
            return mid
        elif key(a[mid]) < p:
            return search(mid + 1, R)
        else:
            return search(L, mid - 1)

    # 下面这一行是函数binarySearch的最后一条语句
    return search(0, len(a) - 1)


a = [9, 12, 27, 33, 33, 41, 80]  # a有序
print(binarySearch(a, 33))  # >>3
print(binarySearch(a, 57))  # >>None
a.sort(key=lambda x: x % 10)  # 按个位数从小到大排序
print(a)  # >>[80, 41, 12, 33, 33, 27, 9]
print(binarySearch(a, 57, key=lambda x: x % 10))  # >>5
"""
输出
3
None
[80, 41, 12, 33, 33, 27, 9]
5
"""

"""
给定函数 f (x)=x²+x+1+log₂x（x>0），对于每个输入的正整数 y，求方程 f (x)=y 的解 x，结果四舍五入保留四位小数。输入有多组数据，每组数据为一个正整数 y，输出对应的 x 值。
"""
import math

def f(x):
    return x * x + x + 1 + math.log2(x)

def solve(y):
    left = 1e-6  # x必须大于0，避免log2(0)报错
    right = y

    eps = 1e-7  # 精度要求足够小
    while right - left > eps:
        mid = (left + right) / 2
        if f(mid) < y:
            left = mid
        else:
            right = mid
    return round((left + right) / 2, 4)

# 处理多组输入
try:
    while True:
        line = input()
        if not line:
            break
        y = int(line)
        print(f"{solve(y):.4f}")
except EOFError:
    pass

"""
求出对于给定的n，计算并输出由操作数序列1，2，…，n，经过一系列操作可能得到的输出序列总数。
"""


def count_sequences(n):
    from functools import lru_cache

    @lru_cache(None)
    def dfs(pushed, stack_size):
        # pushed: 已经push的元素个数
        # stack_size: 当前栈中元素个数

        # 如果所有元素都已push且栈空，完成一个合法序列
        if pushed == n and stack_size == 0:
            return 1

        res = 0

        # 可以push的话
        if pushed < n:
            res += dfs(pushed + 1, stack_size + 1)

        # 可以pop的话（栈非空）
        if stack_size > 0:
            res += dfs(pushed, stack_size - 1)

        return res

    return dfs(0, 0)


# 读取输入
n = int(input())
print(count_sequences(n))

"""
输入
第一行输入一个整数t，代表有t组测试数据
对于每组测试数据，第一行输入一个整数n，代表操作的次数。
随后输入n行，每行包含两个整数 type val。
当type = 1时，表示该次操作为push操作，val表示进入的数字。当type=2时，表示该次操作为pop操作，val代表出来的数字。
3<=n<=2000
输出
每组测试数据输出一行。
输出改组数据对应的线性结构，”Stack” 或者 “Queue”。
题目保证是栈或者队列的一种。

样例输入
2
6
1 1
1 2
1 3
2 3
2 2
2 1
4
1 1
1 2
2 1
2 2
样例输出
Stack
Queue
"""
t = int(input())
for _ in range(t):
    n = int(input())
    ops = [tuple(map(int, input().split())) for _ in range(n)]

    stack = []
    queue = []
    is_stack = True
    is_queue = True

    for op_type, val in ops:
        if op_type == 1:  # push
            stack.append(val)
            queue.append(val)
        else:  # pop
            if is_stack:
                if not stack or stack.pop() != val:
                    is_stack = False
            if is_queue:
                if not queue or queue.pop(0) != val:
                    is_queue = False

    print("Stack" if is_stack else "Queue")

"""
输入
10 2
31 16
255 8
123456789012345678901234567890 36

输出
1010
1F
377
2ZRKLRWBPNSL6Y6I
"""
def decimal_to_base(n_str, base):
    if base < 2 or base > 36:
        raise ValueError("仅支持2到36进制")

    digits = '0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ'
    n = int(n_str)  # Python支持任意大整数

    if n == 0:
        return '0'

    result = []
    while n > 0:
        result.append(digits[n % base])
        n //= base
    return ''.join(reversed(result))

# 多组输入示例
while True:
    try:
        line = input().strip()
        if not line:
            continue
        num_str, base_str = line.split()
        print(decimal_to_base(num_str, int(base_str)))
    except EOFError:
        break


"""
输入
多组数据，每行为一个长度不超过30位的十进制非负整数。
（注意是10进制数字的个数可能有30个，而非30bits的整数）
输出
每行输出对应的二进制数。

样例输入
0
1
3
8
样例输出
0
1
11
1000
"""

import sys

for line in sys.stdin:
    line = line.strip()
    if line == "":
        continue
    n = int(line)
    print(bin(n)[2:])

"""
描述
小明有很多猪，他喜欢玩叠猪游戏，就是将猪一头头叠起来。猪叠上去后，还可以把顶上的猪拿下来。小明知道每头猪的重量，而且他还随时想知道叠在那里的猪最轻的是多少斤。

输入
有三种输入
1)push n
n是整数(0<=0 <=20000)，表示叠上一头重量是n斤的新猪
2)pop
表示将猪堆顶的猪赶走。如果猪堆没猪，就啥也不干
3)min
表示问现在猪堆里最轻的猪多重。如果猪堆没猪，就啥也不干

输入总数不超过100000条
输出
对每个min输入，输出答案。如果猪堆没猪，就啥也不干

样例输入
pop
min
push 5
push 2
push 3
min
push 4
min
样例输出
2
2
"""
"""
思路：
main_stack：存储所有数据（模拟正常的栈）
min_stack：存储到当前为止的最小值

每次 push(n)：
    将 n 压入 main_stack
    如果 min_stack 为空或 n <= min_stack[-1]，也压入 min_stack
每次 pop()：
    如果 main_stack.pop() 弹出的值和 min_stack[-1] 一样，min_stack 也要 pop
每次 min()：
    输出 min_stack[-1]


比如
push 5
push 2
push 2
push 3
每一步：
    main_stack：[5] → [5,2] → [5,2,2] → [5,2,2,3]
    min_stack： [5] → [5,2] → [5,2,2] → [5,2,2]
"""

import sys

main_stack = []
min_stack = []

for line in sys.stdin:
    line = line.strip()
    if not line:
        continue
    if line.startswith("push"):
        _, val = line.split()
        val = int(val)
        main_stack.append(val)
        if not min_stack or val <= min_stack[-1]:
            min_stack.append(val)
    elif line == "pop":
        if main_stack:
            val = main_stack.pop()
            if val == min_stack[-1]:
                min_stack.pop()
    elif line == "min":
        if min_stack:
            print(min_stack[-1])

"""
描述
字符串中可能有3种成对的括号，"( )"、"[ ]"、"{}"。请判断字符串的括号是否都正确配对以及有无括号嵌套。无括号也算正确配对。括号交叉算不正确配对，例如"1234[78)ab]"就不算正确配对。一对括号被包含在另一对括号里面，例如"12(ab[8])"就算括号嵌套。括号嵌套不影响配对的正确性。 给定一个字符串: 如果括号没有正确配对，则输出 "ERROR" 如果正确配对了，且有括号嵌套现象，则输出"YES" 如果正确配对了，但是没有括号嵌套现象，则输出"NO"
输入
一个字符串，长度不超过5000,仅由 ( ) [ ] { } 和小写英文字母以及数字构成
输出
根据实际情况输出 ERROR, YES 或NO
样例输入
样例1:
[](){}
样例2:
[(a)]bv[]
样例3:
[[(])]{}
样例输出
样例1:
NO
样例2:
YES
样例3:
ERROR
"""

pairs = {')': '(', ']': '[', '}': '{'}
qiantao = False

s = input().strip()
stack = []
valid = True
for ch in s:
    if ch in '([{':
        if stack:
            qiantao = True
        stack.append(ch)
    elif ch in ')]}':
        if not stack or stack[-1] != pairs[ch]:
            valid = False
            break
        stack.pop()
if valid and not stack and not qiantao:
    print("NO")
elif valid and not stack and qiantao:
    print("YES")
else:
    print("ERROR")

class Stack:
    def __init__(self):
        self.items = []

    def isEmpty(self):
        return self.items == []

    def push(self, item):
        self.items.append(item)

    def pop(self):
        return self.items.pop()

    def peek(self):
        return self.items[len(self.items) - 1]

    def size(self):
        return len(self.items)

# 创建栈对象
stack = Stack()
# 入栈操作
stack.push(10)
stack.push(20)
# 查看栈顶元素
print(stack.peek())
# 出栈操作
print(stack.pop())
# 获取栈大小
print(stack.size())
# 判断栈是否为空
print(stack.isEmpty())

def safe_eval(expr):
    # 检查表达式是否合法（可选步骤）
    for ch in expr:
        if not (ch.isdigit() or ch in '.+-*/()'):
            raise ValueError("非法字符")
    # 使用 eval 计算表达式的值
    return eval(expr)

n = int(input())
for _ in range(n):
    expr = input().strip()
    result = safe_eval(expr)
    print(f"{result:.2f}")

"""
输入
第一行是整数n(n<100)，接下来有n行，每行一个四则运算表达式，长度不超过700字符。'*'表示乘法，'/'表示除法。
输出
对每个表达式，输出该表达式的值，保留小数点后面两位。

样例输入
3
3.4
7+8.3
3+4.5*(7+2)*(3)*((3+4)*(2+3.5)/(4+5))-34*(7-(2+3))
样例输出
3.40
15.30
454.75
"""

#先转成后缀 再后缀求值
def infix_to_postfix(expression):
    precedence = {'+': 1, '-': 1, '*': 2, '/': 2}
    output = []
    stack = []
    i = 0
    while i < len(expression):
        ch = expression[i]
        if ch == ' ':
            i += 1
            continue
        elif ch.isdigit() or ch == '.':
            # 读取完整数字（包括小数）
            num = []
            while i < len(expression) and (expression[i].isdigit() or expression[i] == '.'):
                num.append(expression[i])
                i += 1
            output.append(''.join(num))
            continue
        elif ch == '(':
            stack.append(ch)
        elif ch == ')':
            while stack and stack[-1] != '(':
                output.append(stack.pop())
            stack.pop()  # 弹出 '('
        elif ch in '+-*/':
            while stack and stack[-1] != '(' and precedence.get(stack[-1], 0) >= precedence[ch]:
                output.append(stack.pop())
            stack.append(ch)
        i += 1
    while stack:
        output.append(stack.pop())
    return output

def eval_postfix(postfix):
    stack = []
    for token in postfix:
        if token not in '+-*/':
            stack.append(float(token))
        else:
            b = stack.pop()
            a = stack.pop()
            if token == '+': stack.append(a + b)
            elif token == '-': stack.append(a - b)
            elif token == '*': stack.append(a * b)
            elif token == '/': stack.append(a / b)
    return stack[0]

# 主函数
n = int(input())
for _ in range(n):
    expr = input().strip()
    postfix = infix_to_postfix(expr)
    result = eval_postfix(postfix)
    print(f"{result:.2f}")

"""
将中缀表达式整体反转（包括数字、运算符和括号）：反转的同时，左括号变右括号，右括号变左括号。
对反转后的表达式进行“中缀转后缀”
最后再把后缀表达式反转，即得到前缀表达式。

样例输入：
2
3+4
(3+4)*5

样例输出：
+ 3 4
* + 3 4 5
"""
import re

def reverse_expression(expr):
    # 将表达式拆成 token
    tokens = re.findall(r'\d+\.\d+|\d+|[()+\-*/]', expr)
    # 反转并交换括号
    tokens = tokens[::-1]
    for i in range(len(tokens)):
        if tokens[i] == '(':
            tokens[i] = ')'
        elif tokens[i] == ')':
            tokens[i] = '('
    return tokens

def infix_to_prefix(expression):
    # 步骤1：反转表达式 + 括号互换
    tokens = reverse_expression(expression)

    # 步骤2：按中缀转后缀的方法处理
    output = []
    ops = []
    priority = {'+': 1, '-': 1, '*': 2, '/': 2}

    for token in tokens:
        if re.match(r'\d', token):  # 数字
            output.append(token)
        elif token == '(':
            ops.append(token)
        elif token == ')':
            while ops and ops[-1] != '(':
                output.append(ops.pop())
            ops.pop()  # 弹出 (
        else:  # 运算符
            while ops and ops[-1] != '(' and priority[ops[-1]] >= priority[token]:
                output.append(ops.pop())
            ops.append(token)

    while ops:
        output.append(ops.pop())

    # 步骤3：将后缀表达式反转，得到前缀
    return ' '.join(output[::-1])

# 示例输入
n = int(input())
for _ in range(n):
    expr = input().strip()
    print(infix_to_prefix(expr))

"""
样例输入
3
7+8.3
3+4.5*(7+2)
(3)*((3+4)*(2+3.5)/(4+5))
样例输出
7 8.3 +
3 4.5 7 2 + * +
3 3 4 + 2 3.5 + * 4 5 + / *
"""
#re.findall() 是 Python 的正则表达式模块 re 中的一个函数，
# 用于在字符串中查找所有符合正则表达式的子串，并以列表形式返回所有匹配项
"""
遇到数字或小数：直接加入 output。
遇到左括号 (：压入 ops。
遇到右括号 )：将 ops 栈顶的运算符弹出并加入 output，直到遇到 ( 为止（弹出左括号但不加入输出）。
遇到运算符 + - * /：不断弹出 ops 栈中优先级 大于或等于 当前运算符的内容并加入 output；当前运算符再压入 ops。
表达式结束后：将 ops 中剩余运算符全部加入 output。
"""

def infix_to_postfix(expression):
    import re
    tokens = re.findall(r'\d+\.\d+|\d+|[()+\-*/]', expression)  # 拆分数字/运算符/括号
    output = []
    ops = [] #ops：操作符栈，用于管理运算符优先级和括号
    r"""
    小数（如 3.14）：\d+\.\d+
    整数（如 42）：\d+
    单个字符的符号或括号（如 +、( 等）：[()+\-*/]

    e.g. 将字符串 3+4.5*(7+2) 拆成如下列表：
    ['3', '+', '4.5', '*', '(', '7', '+', '2', ')']
    """
    priority = {'+': 1, '-': 1, '*': 2, '/': 2}

    for token in tokens:
        if re.match(r'\d', token):  # 数字
            output.append(token)
        elif token == '(':
            ops.append(token)
        elif token == ')':
            while ops and ops[-1] != '(':
                output.append(ops.pop())
            ops.pop()  # 弹出左括号
        else:  # 运算符
            while ops and ops[-1] != '(' and priority[ops[-1]] >= priority[token]:
                output.append(ops.pop())
            ops.append(token)

    while ops:
        output.append(ops.pop())

    return ' '.join(output)

n = int(input())
for _ in range(n):
    expr = input().strip()
    print(infix_to_postfix(expr))

"""
输入：
3 4 + 5 *
输出：
35.000000
"""
"""
从右到左扫描表达式：
遇到数 → 入栈
遇到运算符 → 出栈两个数，计算结果，再入栈
最后栈中剩一个数，就是结果。
"""

def evaluate_polish(expression):
    tokens = expression.strip().split()
    stack = []

    # 从右往左遍历
    for token in reversed(tokens):
        if token in '+-*/':
            a = stack.pop()
            b = stack.pop()
            if token == '+':
                stack.append(a + b)
            elif token == '-':
                stack.append(a - b)
            elif token == '*':
                stack.append(a * b)
            elif token == '/':
                stack.append(a / b)
        else:
            stack.append(float(token))

    return stack[0]

# 读取输入
expr = input()
result = evaluate_polish(expr)

# 按题目要求格式输出
print("%f" % result) #默认保留 6 位小数

"""
样例输入
3
5 3.4 +
5 3.4 + 6 /
5 3.4 + 6 * 3 +
样例输出
8.40
1.40
53.40
"""
n = int(input())
for _ in range(n):
    tokens = input().split()
    stack = []
    for token in tokens:
        if token in '+-*/':
            b = stack.pop()
            a = stack.pop()
            if token == '+':
                stack.append(a + b)
            elif token == '-':
                stack.append(a - b)
            elif token == '*':
                stack.append(a * b)
            elif token == '/':
                stack.append(a / b)
        else:
            stack.append(float(token))
    print("%.2f" % stack[0])

r"""
判断两个表达式在数学上是否是等价的。
输入
第一行：N（1<=N<=20），表示测试数据组数。
接下来每组测试数据包括两行，每行包括一个数学表达式，每个表达式的长度不超过80个字符。输入数据没有空行。

一个表达式可能包括：
单个英文字母表示的变量（区分大小写）
数字（只有一位数）
配对的括号
运算符加+、减-、乘*
任意数量的空格或tab（可能出现在表达式中间的任何位置）

注意：表达式保证是语法正确的，且所有运算符的优先级相同，运算次序从左至右。变量的系数和指数保证不超过16位整数。
输出
对每个测试数据，输出一行：等价则输出“YES”，不等价则输出“NO”。

样例输入
3
(a+b-c)*2
(a+a)+(b*2)-(3*c)+c
a*2-(a+c)+((a+c+e)*2)
3*a+c+(2*e)
(a-b)*(a-b)
(a*a)-(2*a*b)-(b*b)
样例输出
YES
YES
NO
"""

import re
from collections import defaultdict #当访问不存在的键时，自动为该键生成一个默认值，避免手动判断键是否存在。

def tokenize(expr):
    """将表达式分词，保留操作符、变量、数字和括号"""
    expr = expr.replace(" ", "")
    return re.findall(r'\d+|[a-zA-Z]+|[+\-*/()]', expr) #[a-zA-Z]+ 匹配由一个或多个英文字母组成的连续子串，例如：a、abc、XYZ、xYzA 等等。

def infix_to_postfix(tokens):
    """中缀表达式转换为后缀表达式（逆波兰表达式）"""
    precedence = {'+': 1, '-': 1, '*': 1}
    output = []
    stack = []

    for token in tokens:
        if token.isalnum():
            output.append(token)
        elif token in precedence:
            while stack and stack[-1] in precedence and precedence[stack[-1]] >= precedence[token]:
                output.append(stack.pop())
            stack.append(token)
        elif token == '(':
            stack.append(token)
        elif token == ')':
            while stack and stack[-1] != '(':
                output.append(stack.pop())
            stack.pop()

    while stack:
        output.append(stack.pop())

    return output

def evaluate_postfix(postfix):
    """求解后缀表达式，返回变量系数字典"""
    stack = []

    for token in postfix:
        if token.isdigit():
            stack.append({'': int(token)})  # 常数项用空字符串表示变量
        elif token.isalpha():
            stack.append({token: 1})
        else:
            b = stack.pop()
            a = stack.pop()
            result = defaultdict(int)

            if token == '+':
                for k in set(a) | set(b): #并集 set（）取字典的key
                    result[k] = a.get(k, 0) + b.get(k, 0) #从字典中取 key 为 k 的值，如果没有该 key，则返回 0
            elif token == '-':
                for k in set(a) | set(b):
                    result[k] = a.get(k, 0) - b.get(k, 0)
            elif token == '*':
                for ka, va in a.items():
                    for kb, vb in b.items():
                        key = ''.join(sorted(ka + kb)) #'a' * 'b' 变成 'ab'，并按字母排序（确保 'ab' 和 'ba' 等价）
                        result[key] += va * vb

            # 去除系数为0的项
            result = {k: v for k, v in result.items() if v != 0}
            stack.append(result)

    return stack[0] if stack else {}

def parse_expression(expr):
    tokens = tokenize(expr)
    postfix = infix_to_postfix(tokens)
    return evaluate_postfix(postfix)

def judge_equivalence(expr1, expr2):
    return "YES" if parse_expression(expr1) == parse_expression(expr2) else "NO"

# 主程序
N = int(input())
for _ in range(N):
    expr1 = input().strip()
    expr2 = input().strip()
    print(judge_equivalence(expr1, expr2))

"""
对于每个位置i,定义ci是从位置i向右扫描过程中，连续遇到严格小于h[i]的元素个数,计算所有ci的和

输入
第1行：奶牛数N
第2行至N+1行：第i+1行包含一个整数，表示奶牛i的高度

输出
第1行：c1 至cN的累加和

样例输入
6
10
3
7
4
12
2
样例输出
5
"""
"""
思路：单调栈
只关心下一个更大元素
"""

n = int(input())
heights = [int(input()) for _ in range(n)]
#保存的是一个递减的栈，每个元素是一个 (height, count) 元组。height：当前栈中奶牛的高度；count：它右侧能被看到的奶牛数量
stack = []
total = 0

for i in range(n - 1, -1, -1): #从右向左
    count = 0
    while stack and heights[i] > stack[-1][0]:
        h, c = stack.pop()
        count += c + 1
    stack.append((heights[i], count))
    total += count

print(total)

"""
给你一个列表 temperatures，表示每天的气温。
你需要返回一个列表 answer，其中 answer[i] 是你要等多少天才能遇到比 temperatures[i] 更高的温度。
如果没有更高温度，answer[i] = 0。

Example 1:
Input: temperatures = [73,74,75,71,69,72,76,73]
Output: [1,1,4,2,1,1,0,0]
Example 2:
Input: temperatures = [30,40,50,60]
Output: [1,1,1,0]
Example 3:
Input: temperatures = [30,60,90]
Output: [1,1,0]
"""

def dailyTemperatures(T):
    n = len(T)
    answer = [0] * n
    stack = []  # 存索引 递减栈

    for i in range(n - 1, -1, -1):
        while stack and T[i] >= T[stack[-1]]:
            stack.pop()
        if stack:
            answer[i] = stack[-1] - i #右侧第一个比他大的下标-当前下标
        stack.append(i)

    return answer

def left_smaller(nums):
    result = []
    stack = [] #递增栈

    for num in nums:
        while stack and stack[-1] >= num:
            stack.pop()
        result.append(stack[-1] if stack else -1)
        stack.append(num)

    return result

print(left_smaller([2,1,5,6,2,3]))

"""
给定一个数组 heights，表示柱状图中每个柱子的高度，求其中能构成的最大矩形面积。

Input: heights = [2,1,5,6,2,3]
Output: 10
"""
"""
思路：
对于每一个柱子，向左和向右延伸，能扩展多宽而不被更矮的柱子阻挡。
递增栈，来维护“左边比我小”的柱子
"""
def largestRectangleArea(heights):
    stack = [] #递增栈
    max_area = 0
    heights.append(0)  # 哨兵，方便清空栈

    for i, h in enumerate(heights): #从左向右
        while stack and heights[stack[-1]] > h:
            height = heights[stack.pop()]
            width = i if not stack else (i - stack[-1] - 1)
            #如果栈空了：说明前面所有柱子都比它高，它可以从 0 延伸到 i
            #如果栈没空：stack[-1] 是它左边第一个比它小的柱子，它只能从那之后到当前 i

            """
            每次弹出的柱子 = 当前考虑的“最矮”柱子
            它能向左延伸到：栈顶上一个元素之后 （这个元素是左边比他小的第一个元素）
            它能向右延伸到：当前下标（被阻挡或结束）
            所以宽度 = i - stack[-1] - 1
            面积 = height * width
            """
            max_area = max(max_area, height * width)
        stack.append(i)

    return max_area

print(largestRectangleArea([2,1,5,6,2,3]))

"""
给定两个单链表，这两个链表在某个节点处会合并为一个链表（即存在一个公共节点，从该节点开始后续所有节点均相同）。编写程序找出这个公共节点的数据值。

输入
第一行：第一个链表的节点值（整数序列，用空格分隔）。
第二行：第二个链表的节点值（整数序列，用空格分隔）。
第三行：一个整数 n，表示将第二个链表的第 n 个节点（从 1 开始计数）连接到第一个链表的尾部。
输出
输出两个链表的第一个公共节点的数据值。如果链表不相交，输出 None。
"""
class Node:
    def __init__(self, data, next=None):
        self.data, self.next = data, next


class LinkList:
    def __init__(self, lst):
        self.head = Node(lst[0])
        p = self.head
        for i in lst[1:]:
            node = Node(i)
            p.next = node
            p = p.next


def genLinkList():
    a = list(map(int, input().split()))
    b = list(map(int, input().split()))
    n = int(input())
    la = LinkList(a)
    lb = LinkList(b)
    p = la.head
    last = None
    while p is not None:
        last = p
        p = p.next
    p = lb.head
    for i in range(n - 1):
        p = p.next
    last.next = p
    return la, lb


a, b = genLinkList()


def findJointPoint(a, b):
    def get_length(head):
        length = 0
        while head is not None:
            length+=1
            head = head.next
        return length

    a_length = get_length(a.head)
    b_length = get_length(b.head)

    long = max(a_length,b_length)
    short = min(a_length,b_length)
    diff = long-short

    a_head = a.head
    b_head = b.head
    if a_length > b_length:
        for _ in range(diff):
            a_head = a_head.next
    else:
        for _ in range(diff):
            b_head = b_head.next

    for _ in range(short):
        if a_head == b_head:
            return a_head.data
        else:
            a_head=a_head.next
            b_head = b_head.next
    return None

print(findJointPoint(a, b))

"""
输入：1 2 3 4 5
输出：5 4 3 2 1
"""
class Node:
    def __init__(self, data, next=None):
        self.data, self.next = data, next


class LinkList:
    def __init__(self, lst):
        self.head = Node(lst[0])
        p = self.head
        for i in lst[1:]:
            node = Node(i)
            p.next = node
            p = p.next

    def reverse(self):
        if self.head is None or self.head.next is None:
            return
        pre = self.head
        cur = pre.next
        """
        pre的next要设置成None
        """
        pre.next = None
        while cur != None:
            next_node = cur.next
            cur.next = pre
            pre = cur
            cur = next_node
        self.head = pre

    def print(self):
        p = self.head
        while p:
            print(p.data, end=" ")
            p = p.next
        print()


a = list(map(int, input().split()))
a = LinkList(a)
a.reverse()
a.print()

"""
给定一个整数链表，在链表的中间位置插入数字 6。若链表长度为偶数，插入到靠后的中间位置（即第 len/2 个位置，从 0 开始计数）。

输入
一行整数，用空格分隔，表示链表元素。

输出
插入 6 后的链表元素，用空格分隔。

样例输入 1
8 1 0 9 7 5
样例输出 1
8 1 0 6 9 7 5
样例输入 2
1 2 3
样例输出 2
1 2 6 3
"""
class Node:
    def __init__(self, data, next=None):
        self.data, self.next = data, next


class LinkList:
    def __init__(self):
        self.head = None

    def initList(self, data):
        self.head = Node(data[0])
        p = self.head
        for i in data[1:]:
            node = Node(i)
            p.next = node
            p = p.next

    def insertCat(self):
        new_node=Node(6)
        size = 1
        m =self.head

        while m.next:
            size+=1
            m=m.next
        p = self.head
        if size%2==0:
            for _ in range(size//2-1):
                p = p.next
        else:
            for _ in range(size//2):
                p = p.next
        q = p.next
        p.next = new_node
        new_node.next = q

    def printLk(self):
        p = self.head
        while p:
            print(p.data, end=" ")
            p = p.next
        print()


lst = list(map(int, input().split()))
lkList = LinkList()
lkList.initList(lst)
lkList.insertCat()
lkList.printLk()


"""
实现一个循环链表，支持在链表头部插入元素、在链表尾部插入元素、删除指定值的元素，并输出链表的当前状态。
输入
第一行包含一个整数 t，表示测试用例的数量。
每个测试用例包含两行：
    初始链表元素（以空格分隔的整数序列）。
    需要删除的元素序列（以空格分隔的整数序列）。
输出
对于每个删除操作，根据结果输出相应信息：

如果删除成功，输出删除后的链表元素（按顺序，以空格分隔）。
如果要删除的元素不存在，输出 NOT FOUND。
如果删除后链表为空，输出 EMPTY。
每个测试用例结束后，输出一行 ---------------- 作为分隔符。
"""
class Node:
    def __init__(self, data, next=None):
        self.data, self.next = data, next


class LinkList:  # 循环链表
    def __init__(self):
        self.tail = None
        self.size = 0

    def isEmpty(self):
        return self.size == 0

    def pushFront(self, data):
        nd = Node(data)
        if self.tail == None:
            self.tail = nd
            nd.next = self.tail
        else:
            nd.next = self.tail.next
            self.tail.next = nd
        self.size += 1

    def pushBack(self, data):
        self.pushFront(data)
        self.tail = self.tail.next

    def popFront(self):
        if self.size == 0:
            return None
        else:
            nd = self.tail.next
            self.size -= 1
            if self.size == 0:
                self.tail = None
            else:
                self.tail.next = nd.next
        return nd.data

    def printList(self):
        if self.size > 0:
            ptr = self.tail.next
            while True:
                print(ptr.data, end=" ")
                if ptr == self.tail:
                    break
                ptr = ptr.next
            print("")

    def remove(self, data):
        """
        这不光要删除，还得size-1 而且如果删的是tail tail得变 因为这整个链表只维护tail
        但remove的元素是tail时，要是一删这个链表空了，那tail变为None
        要是还有，那tail变成pre
        """
        if self.size == 0:
            return None
        pre = self.tail
        cur = pre.next
        for _ in range(self.size):
            if cur.data == data:
                if self.size == 1:
                    self.tail = None
                elif cur is self.tail:
                    self.tail = pre
                self.size -= 1
                pre.next = cur.next
                return True
            pre = pre.next
            cur = cur.next
        else:
            return False


t = int(input())
for i in range(t):
    lst = list(map(int, input().split()))
    lkList = LinkList()
    for x in lst:
        lkList.pushBack(x)
    lst = list(map(int, input().split()))
    for a in lst:
        result = lkList.remove(a)
        if result == True:
            lkList.printList()
        elif result == False:
            print("NOT FOUND")
        else:
            print("EMPTY")
    print("----------------")

"""
输入包含多组测试数据，每组数据占一行，包含两个整数 n 和 m：
    n 表示链表的长度（实际链表长度会额外增加 10 个节点）。
    m 为标记值：
        若 m=0，链表为普通链表，无环。
        若 m=1，程序会在链表中随机位置创建一个环。

对于每组测试数据，输出一行结果：
若链表中存在环，输出 True。
若链表中不存在环，输出 False。
"""
#快慢指针法
import random


class Node:
    def __init__(self, data, next=None):
        self.data, self.next = data, next


class LinkList:
    def __init__(self, lst):
        self.head = Node(lst[0])
        p = self.head
        L = len(lst)
        for i in range(1, L):
            node = Node(lst[i])
            p.next = node
            p = p.next

    def loopExists(self):
            slow = self.head
            fast = self.head
            while fast and fast.next:
                slow = slow.next
                fast = fast.next.next
                if slow == fast:
                    return True
            return False


while True:
    try:
        n, m = map(int, input().split())
    except:
        break
    a = [i for i in range(n + 10)]
    random.shuffle(a)
    lst = LinkList(a)
    if m == 1: #在链表中构造一个环，方法是让最后一个节点指向中间某个节点
        if n > 10:
            pos = random.randint(0, n - 5)
        else:
            pos = 0
        p = lst.head
        q = p
        for i in range(pos):
            q = q.next
        last = None
        while p is not None:
            last = p
            p = p.next
        last.next = q#从最后一个节点可以回到中间某个节点
    print(lst.loopExists())

class Node:
    def __init__(self, initdata):
        self.data = initdata
        self.next = None

    def getData(self):
        return self.data

    def getNext(self):
        return self.next

    def setData(self, newdata):
        self.data = newdata

    def setNext(self, newnext):
        self.next = newnext


class UnorderedList:
    def __init__(self):
        self.head = None

    def add(self, item):
        temp = Node(item)
        temp.setNext(self.head)
        self.head = temp

    def isEmpty(self):
        return self.head is None

    def size(self):
        current = self.head
        count = 0
        while current is not None:
            count += 1
            current = current.getNext()
        return count

    def search(self, item):
        current = self.head
        found = False
        while current is not None and not found:
            if current.getData() == item:
                found = True
            else:
                current = current.getNext()
        return found

    def remove(self, item):
        current = self.head
        previous = None
        found = False
        #先找到位置
        while not found:
            if current.getData() == item:
                found = True
            else:
                previous = current
                current = current.getNext()
        #当第一个元素就是要删的节点
        if previous is None:
            self.head = current.getNext()
        else:
            previous.setNext(current.getNext())

"""
输入
第一行输入一个整数t，代表测试数据的组数。
每组数据的第一行输入一个整数n，表示操作的次数。
接着输入n行，每行对应一个操作，首先输入一个整数type。
当type=1，进队操作，接着输入一个整数x，表示进入队列的元素。
当type=2，出队操作，接着输入一个整数c，c=0代表从队头出队，c=1代表从队尾出队。

n <= 1000
输出
对于每组测试数据，输出执行完所有的操作后队列中剩余的元素,元素之间用空格隔开，按队头到队尾的顺序输出，占一行。如果队列中已经没有任何的元素，输出NULL。
样例输入
2
5
1 2
1 3
1 4
2 0
2 1
6
1 1
1 2
1 3
2 0
2 1
2 0
样例输出
3
NULL

"""
class Deque:
    def __init__(self):
        self.items = []

    def isEmpty(self):
        return self.items == []

    def addFront(self, item):
        self.items.append(item)

    def addRear(self, item):
        self.items.insert(0, item)

    def removeFront(self):
        return self.items.pop()

    def removeRear(self):
        return self.items.pop(0)

    def size(self):
        return len(self.items)




t = int(input())
for _ in range(t):
    # 创建双端队列对象
    deque = Deque()
    result = []
    n = int(input())
    ops = [tuple(map(int, input().split())) for _ in range(n)]

    for op_type, val in ops:
        if op_type == 1:  # push
            deque.addRear(val)
        elif op_type == 2: # pop
            if val == 0:
                deque.removeFront()
            else:
                deque.removeRear()
    if deque.size() == 0:
        print("NULL")
    else:
        for _ in range(deque.size()):
            result.append(deque.removeFront())
        print(" ".join(map(str,result)))

"""
总时间限制: 1000ms 内存限制: 262144kB
有一个容量为 M 的缓存。
按顺序访问 N 个编号。
如果编号在缓存中，什么也不做。
如果编号不在缓存中：
    缓存没满，直接加入缓存末尾；
    缓存满了，先把最早加入的编号（队头）移除，再把新编号加入队尾。
统计有多少次编号不在缓存中。

输入
第一行为两个正整数M 和N，代表内存容量和文章的长度。
第二行为N 个非负整数，按照文章的顺序，每个数（大小不超过1000000）代表一个英文单词。文章中两个单词是同一个单词，当且仅当它们对应的非负整数相同。
对于50%的数据，1<=N、M<=1000；
对于100%的数据，1<=N、M<=1000000。
输出
一个整数，为软件需要查词典的次数。

样例输入
3 7
1 2 1 5 4 4 1
样例输出
5
"""
"""
坑：
如果不使用memory会超时
到在队列中查找元素时间复杂度O(N)，用set 来快速判断单词是否在内存中（O(1) 时间复杂度）
"""

from collections import deque
queue = deque()
memory = set()
m,n=map(int,input().split())
words=list(map(int,input().split()))
check_num = 0
for word in words:
    if word not in memory:
        check_num+=1
        if len(memory) >=m:
            old_word=queue.popleft()
            memory.remove(old_word)
        memory.add(word)
        queue.append(word)
print(check_num)

class CircularQueue:
    def __init__(self, size):
        self.size = size
        self.queue = [None] * size
        self.front = 0
        self.rear = 0

    def is_empty(self):
        return self.front == self.rear

    def is_full(self):
        return (self.rear + 1) % self.size == self.front

    def enqueue(self, item):
        if self.is_full():
            print("队列已满，无法入队。")
            return
        self.queue[self.rear] = item
        self.rear = (self.rear + 1) % self.size

    def dequeue(self):
        if self.is_empty():
            print("队列为空，无法出队。")
            return None
        item = self.queue[self.front]
        self.queue[self.front] = None  # 可选：清除数据
        self.front = (self.front + 1) % self.size
        return item

    def peek(self):
        if self.is_empty():
            print("队列为空，无法查看队首元素。")
            return None
        return self.queue[self.front]

    def current_size(self):
        return (self.rear - self.front + self.size) % self.size

    def __str__(self):
        result = []
        i = self.front
        while i != self.rear:
            result.append(str(self.queue[i]))
            i = (i + 1) % self.size
        return "[" + ", ".join(result) + "]"

# 示例使用
if __name__ == "__main__":
    cq = CircularQueue(5)
    cq.enqueue(10)
    cq.enqueue(20)
    cq.enqueue(30)
    cq.enqueue(40)
    print("队列内容:", cq)
    print("队列是否满",cq.is_full())
    print("队首元素:", cq.peek())
    print("出队元素:", cq.dequeue())
    print("队列内容:", cq)

class Queue:
    def __init__(self):
        self.items = []

    def isEmpty(self):
        return self.items == []

    def enqueue(self, item):
        self.items.insert(0, item)

    def dequeue(self):
        return self.items.pop()

    def size(self):
        return len(self.items)

# 创建队列对象
queue = Queue()
# 入队操作
queue.enqueue(5)
queue.enqueue(10)
# 出队操作
print(queue.dequeue())
# 获取队列大小
print(queue.size())
# 判断队列是否为空
print(queue.isEmpty())

"""
输入
输入包括两行。
第一行包括n和k，分别表示数组的长度和窗口的大小。
第二行包括n个数。
输出
输出包括两行。
第一行包括窗口从左至右移动的每个位置的最小值。
第二行包括窗口从左至右移动的每个位置的最大值

样例输入
8 3
1 3 -1 -3 5 3 6 7
样例输出
-1 -3 -3 -3 3 3
3 3 5 5 6 7
"""

from collections import deque

def sliding_window_min_max(nums, k):
    n = len(nums)
    min_q = deque() #只存当前窗口内可能是最小值的下标
    max_q = deque() #只存当前窗口内可能是最大值的下标
    min_result = []
    max_result = []

    for i in range(n):
        # 维护最小值队列（单调递增）
        while min_q and nums[min_q[-1]] >= nums[i]: #但已有的最后一个数比现在这个大
            min_q.pop()
        min_q.append(i)
        if min_q[0] <= i - k: #但前存的最小数的下标太靠前，超出以i为最后一个数的窗口范围
            min_q.popleft()

        # 维护最大值队列（单调递减）
        while max_q and nums[max_q[-1]] <= nums[i]:
            max_q.pop()
        max_q.append(i)
        if max_q[0] <= i - k:
            max_q.popleft()

        # 记录结果
        if i >= k - 1: #当i从第3个数（下标为2）开始，每个都会是一个新的窗口
            min_result.append(nums[min_q[0]])
            max_result.append(nums[max_q[0]])

    return min_result, max_result

# 读入输入
n, k = map(int, input().split())
nums = list(map(int, input().split()))
min_vals, max_vals = sliding_window_min_max(nums, k)
print(' '.join(map(str, min_vals)))
print(' '.join(map(str, max_vals)))


"""
描述
你有⼀个字符串S，⼤小写区分，⼀旦⾥⾯出现连续的PKU三个字符，就会消除。问最终稳定下来以后，这个字符串是什么样的？

输入
⼀⾏,⼀个字符串S，表⽰消除前的字符串。
字符串S的⻓度不超过100000，且只包含⼤小写字⺟。
输出
⼀⾏,⼀个字符串T，表⽰消除后的稳定字符串
样例输入
TopSchoolPPKPPKUKUUPKUku
样例输出
TopSchoolPku
提示
请注意看样例。PKU消除后导致出现连续PKU，还要继续消除
比如APKPKUUB，消除中间PKU后，又得到PKU，就接着消除得到AB
此题用栈解决
"""
def eliminate_PKU(s):
    stack = []
    for ch in s:
        stack.append(ch)
        # 每次检查栈顶的后三个是否为PKU
        if len(stack) >= 3 and stack[-3:] == ['P', 'K', 'U']:
            stack.pop()
            stack.pop()
            stack.pop()
    return ''.join(stack)

# 输入处理
s = input().strip()
print(eliminate_PKU(s))

"""
输入
输入的第一行是一个整数 T (T <= 20) ，表示一共有 T 组数据。
接下来的 T 行，每一行都包含了一个长度不超过的 1000 的字符串，且字符串只包含了小写字母。
输出
对于每组数据，输出一行。该行包含一个整数，表示最少切割的次数，使得切割完得到的子串都是回文的。
样例输入
3
abaacca
abcd
abcba
样例输出
1
3
0
"""
"""
"""

def min_cut(s):
    n = len(s)
    if n <= 1:
        return 0

    # step 1: 预处理所有回文子串 is_pal[i][j] 表示 s[i..j] 是否为回文串
    is_pal = [[False] * n for _ in range(n)]
    for i in range(n - 1, -1, -1):  # 从后往前填表，确保 is_pal[i+1][j-1] 先被填好
        for j in range(i, n):
            if s[i] == s[j] and (j - i <= 2 or is_pal[i + 1][j - 1]):
                is_pal[i][j] = True

    # step 2: dp[i] 表示 s[0..i] 最少需要切割几次
    dp = [0] * n
    for i in range(n):
        if is_pal[0][i]:
            dp[i] = 0
        else:
            dp[i] = min(dp[j] + 1 for j in range(i) if is_pal[j + 1][i])
    return dp[-1]

T = int(input())
for _ in range(T):
    s = input().strip()
    print(min_cut(s))

"""
输入一个字符串，输出该字符串是否回文。
如果字符串是回文，输出yes；否则，输出no。
"""
def isPalindrome(s):
    if all(s[i] == s[len(s) - 1 - i] for i in range(len(s) // 2)):
        return "yes"
    else:
        return "no"
s=input()
print(isPalindrome(s))

"""
给定三个字符串 A、B、C，判断 C 是否可以由 A 和 B 中的字符按原顺序混合组成（即 C 的字符序列可以拆分为两个子序列，分别对应 A 和 B 的顺序）。

样例输入
3
cat tree tcraete
cat tree catrtee
cat tree cttaree
样例输出
Data set 1: yes
Data set 2: yes
Data set 3: no
"""
def can_form(a,b,c):
    len_a,len_b,len_c = len(a),len(b),len(c)
    if len_a+len_b != len_c:
        return False
    dp =[ [False]*(len_b+1) for _ in range(len_a+1)]
    dp[0][0] = True
    for i in range(1,len_a+1): #只用 a 的前缀来组成 c
        dp[i][0]=dp[i-1][0] and a[i-1] == c[i-1] #dp是从0到len,abc是从0到len-1
    for j in range(1,len_b+1): #只用 b 的前缀来组成 c
        dp[0][j]=dp[0][j-1] and b[j-1] == c[j-1]

    for i in range(1,len_a+1):
        for j in range(1,len_b+1):
            dp[i][j] = (dp[i-1][j] and a[i-1] == c[i+j-1]) or (dp[i][j-1] and b[j-1] == c[i+j-1])

    return dp[len_a][len_b]
n = int(input())
for case_num in range(1,n+1):
    a,b,c = input().split()
    result="yes" if can_form(a,b,c) else "no"
    print(f"Data set {case_num}: {result}")

"""
描述
有三个字符串S,S1,S2，其中，S长度不超过300，S1和S2的长度不超过10。
想检测S1和S2是否同时在S中出现，且S1位于S2的左边，并在S中互不交叉（即，S1的右边界点在S2的左边界点的左侧）。
计算满足上述条件的最大跨距（即，最大间隔距离：最右边的S2的起始点与最左边的S1的终止点之间的字符数目）。
如果没有满足条件的S1，S2存在，则输出-1。

输入
三个串：S, S1, S2，其间以逗号间隔（注意，S, S1, S2中均不含逗号和空格）；
输出
S1和S2在S最大跨距；若在S中没有满足条件的S1和S2，则输出-1。

样例输入
abcd123ab888efghij45ef67kl,ab,ef
样例输出
18
"""

s, s1, s2 = map(str, input().split(','))
if s1 in s and s2 in s:
    tail = 0
    head = len(s)
    while s1 not in s[:tail]:
        tail += 1
    while s2 not in s[head - 1:]:
        head -= 1
    if tail <= head:
        print(head - tail - 1)
    else:
        print(-1)
else:
    print(-1)

"""
描述
输入两个串s1,s2，找出s2在s1中所有出现的位置
两个子串的出现不能重叠。例如'aa'在 aaaa 里出现的位置只有0,2

输入
第一行是整数n
接下来有n行，每行两个不带空格的字符串s1,s2
输出
对每行，从小到大输出s2在s1中所有的出现位置。位置从0开始算
如果s2没出现过，输出 "no"
行末多输出空格没关系

样例输入
4
ababcdefgabdefab ab
aaaaaaaaa a
aaaaaaaaa aaa
112123323 a
样例输出
0 2 9 14
0 1 2 3 4 5 6 7 8
0 3 6
no
"""

def positions(S, S1):
    s1_positions = []
    start = 0
    while True:
        pos = S.find(S1, start) #在S[star:]找第一个S1的位置，没找到返回-1
        if pos == -1:
            break
        s1_positions.append(pos)
        start = pos + len(S1)

    if not s1_positions :
        return "no"

    return " ".join(map(str,s1_positions))

n = int(input())
for _ in range(n):
    S, S1= input().split()
    print(positions(S, S1))

"""
描述
给定一个只包含小写字母的字符串，请你找到第一个仅出现一次的字符。如果没有，输出no。

输入
一个字符串，长度小于100000。
输出
输出第一个仅出现一次的字符，若没有则输出no。

样例输入
abcabd
样例输出
c
"""
from collections import Counter
s = input()
count = Counter(s) #字典保存 时间复杂度o(n)
for ch in s:
    if count[ch] == 1: #遍历 时间复杂度o(n)
        print(ch)
        break
else:
    print("no")

#整体时间复杂度o(n)

"""
给定一个由数字组成的字符串（长度为 n）和一个整数 m（表示插入 m 个加号），要求在数字间插入 m 个加号，将字符串分割为 m+1 个子数字串，每个子串非空且顺序不变。求所有合法分割方式中，各子串数值之和的最小值。

输入
有不超过15组数据
每组数据两行。第一行是整数m，表示有m个加号要放( 0<=m<=50)
第二行是若干个数字。数字总数n不超过50,且 m <= n-1

样例输入
2
123456
1
123456
4
12345
样例输出
102
579
15
"""

from functools import lru_cache


# 高精度加法函数 e.g. add("1234", "567") -> "1801"
def add(a, b):
    # 让a是更长的那个
    if len(a) < len(b):
        a, b = b, a
    a = list(map(int, a[::-1]))
    b = list(map(int, b[::-1]))  # 字符串倒序转为数字列表 下标越小越是低位
    res = []
    carry = 0  # 进位
    for i in range(len(a)):
        x = a[i]
        y = b[i] if i < len(b) else 0
        s = x + y + carry
        res.append(str(s % 10))  # 只保留个位
        carry = s // 10  # 十位变成进位
    if carry:
        res.append(str(carry))  # 最后如果还有进位加上
    return ''.join(res[::-1])  # 倒回去


def solve_case(m, s):
    n = len(s)

    @lru_cache(None)
    def dp(i, k):  # 从位置 i 开始，在剩下的字符串中插入 k 个加号，能得到的最小结果。
        if k == 0:
            return s[i:]  # 没有加号时，剩下的是一个整体
        min_sum = None
        for j in range(i + 1, n - k + 1):  # 尝试所有可能的切分点 j 是分割点
            left = s[i:j]  # 当前切出来的数字
            right = dp(j, k - 1)  # 剩下的部分最优和
            total = add(left, right)
            # 不能直接用字符串比较大小，比如 "999" < "1000" 是错误的。所以先比长度，再比字典序。
            if (min_sum is None) or (len(total) < len(min_sum)) or (len(total) == len(min_sum) and total < min_sum):
                min_sum = total
        return min_sum

    return dp(0, m)


# 读取所有数据
def main():
    results = []
    try:
        while True:
            m = int(input())
            s = input().strip()
            results.append(solve_case(m, s))
    except EOFError:
        pass
    for res in results:
        print(res)

main()

"""
输入文件的第一行包含列表的大小 n（此值可以高达 4000）。然后有 n 行，每行包含四个整数（绝对值高达 2 28 ），分别属于 A、B、C 和 D。
对于每个输入文件，你的程序必须写出和为零的四元组的数量。

样例输入
6
-45 22 42 -16
-41 -27 56 30
-36 53 -37 77
-36 30 -75 -46
26 -38 -10 62
-32 -54 -6 45
样例输出
5
提示
以下五个四元组的和为零：(-45, -27, 42, 30)，(26, 30, -10, -46)，(-32, 22, 56, -46)，(-32, 30, -75, 77)，(-32, -54, 56, 30)
"""
from collections import defaultdict
a,b,c,d = [],[],[],[]
n = int(input())
for i in range(n):
    l = list(map(int,input().split()))
    a.append(l[0])
    b.append(l[1])
    c.append(l[2])
    d.append(l[3])
ans = 0
count1 = {} #a+b=key ，value是得到key出现次数
for i in a:
    for j in b:
        if i+j in count1:
            count1[i+j] += 1
        else:
            count1[i+j] = 1
for i in c:
    for j in d:
        if -i-j in count1:
            ans += count1[-i-j]
print(ans)

"""
若四层遍历0(N^4)
这样把时间复杂度从O(n^4)降到O(n^2)
"""

#题目还是上一个题目
from collections import defaultdict

a, b, c, d = [], [], [], []
n = int(input())
for _ in range(n):
    x = list(map(int, input().split()))
    a.append(x[0])
    b.append(x[1])
    c.append(x[2])
    d.append(x[3])

count1 = defaultdict(list)  # key: a + b, value: list of (a, b)

# 枚举 A 和 B 所有组合，存入哈希表
for x in a:
    for y in b:
        count1[x + y].append((x, y))

ans = 0
quadruples = []

# 枚举 C 和 D 所有组合，查找是否存在 -(c + d) 的 a + b
for x in c:
    for y in d:
        key = -x - y
        if key in count1:
            for ab in count1[key]:
                quadruples.append((ab[0], ab[1], x, y))
                ans += 1

# 输出数量
print(ans)

# 输出所有合法四元组
for quad in quadruples:
    print(quad)

"""
在一个游戏中，几个孩子围成一圈，轮流传递一个“热土豆”。传递进行若干次（例如 7 次）后，拿着土豆的人会被淘汰出圈，然后游戏继续，直到只剩下最后一个孩子。
模拟这个游戏，并输出最后留下的孩子的名字。

输入：
namelist：一个字符串列表，表示参与游戏的孩子名字；
num：一个整数，表示每轮传递的次数（传到第 num 次的人会被淘汰）。

输出：
最后留下的孩子的名字
"""
# 自定义队列类实现
class Queue:
    def __init__(self):
        self.items = []

    def is_empty(self):
        return len(self.items) == 0

    def enqueue(self, item):
        self.items.append(item)  # 入队操作，添加到队尾

    def dequeue(self):
        if self.is_empty():
            raise Exception("Queue is empty")
        return self.items.pop(0)  # 出队操作，从队首移除

    def size(self):
        return len(self.items)

    def peek(self):
        if self.is_empty():
            raise Exception("Queue is empty")
        return self.items[0]  # 返回队首元素但不移除


# 热土豆问题解决函数
def hot_potato(namelist, num):
    que = Queue()
    # 将所有名字加入队列
    for name in namelist:
        que.enqueue(name)

    # 当队列中人数大于1时继续游戏
    while que.size() > 1:
        # 模拟传递num次
        for _ in range(num):
            # 队首元素出队后立即入队，模拟传递
            que.enqueue(que.dequeue())
        # 传递结束后，当前队首的人被淘汰
        que.dequeue()

    # 返回最后剩下的人
    return que.dequeue()


# 测试代码
if __name__ == "__main__":
    participants = ["Bill", "David", "Susan", "Jane", "Kent", "Brad"]
    passes = 7  # 传递7次后淘汰一人
    winner = hot_potato(participants, passes)
    print(f"最后剩下的人是: {winner}")

"""
有ｎ只猴子，按顺时针方向围成一圈选大王（编号从１到ｎ），从第１号开始报数，一直数到ｍ，数到ｍ的猴子退出圈外，剩下的猴子再接着从1开始报数。就这样，直到圈内只剩下一只猴子时，这个猴子就是猴王，编程求输入ｎ，ｍ后，输出最后猴王的编号。

输入
每行是用空格分开的两个整数，第一个是 n, 第二个是 m ( 0 < m,n <=300)。最后一行是：0 0

输出
对于每行输入数据（最后一行除外)，输出数据也是一行，即最后猴王的编号
样例输入
6 2
12 4
8 3
0 0
样例输出
5
1
7
"""
def josephus(n, m):
    monkeys = list(range(1, n + 1))
    index = 0
    while len(monkeys) > 1:
        index = (index + m - 1) % len(monkeys)
        monkeys.pop(index)
    return monkeys[0]
while True:
    n, m=map(int,input().split())
    if n == m == 0:
        break
    print(josephus(n,m))

"""
输入
第一行是一个整数n，表示该排列有n个数（n <= 100000)。
第二行是n个不同的正整数，之间以空格隔开，表示该排列。
输出
输出该排列的逆序数。[(2,1),(6,3),(6,4),(6,5),(6,1),(3,1),(4,1),(5,1)]
样例输入
6
2 6 3 4 5 1
样例输出
8
"""

import sys
sys.setrecursionlimit(200000)  # 避免递归深度超限

def count_inversions(arr):
    def merge_sort(nums):
        if len(nums) <= 1:
            return nums, 0
        mid = len(nums) // 2
        left, inv_left = merge_sort(nums[:mid])
        right, inv_right = merge_sort(nums[mid:])
        merged = []
        i = j = inv_count = 0

        # 归并时统计逆序对数
        while i < len(left) and j < len(right):
            if left[i] <= right[j]:
                merged.append(left[i])
                i += 1
            else:
                merged.append(right[j])
                inv_count += len(left) - i  # 左边剩下的全是逆序对
                j += 1

        # 拼接剩余部分
        merged.extend(left[i:])
        merged.extend(right[j:])
        return merged, inv_left + inv_right + inv_count

    _, total_inv = merge_sort(arr)
    return total_inv

# 输入处理
n = int(input())
arr = list(map(int, input().split()))
print(count_inversions(arr))


class TreeNode:
    def __init__(self, val):
        self.val = val
        self.left = None
        self.right = None

# 前序遍历（根-左-右）
def preorder(node):
    if not node:
        return ""
    return str(node.val) + preorder(node.left) + preorder(node.right)

# 中序遍历（左-根-右）
def inorder(node):
    if not node:
        return ""
    return inorder(node.left) + str(node.val) + inorder(node.right)

# 后序遍历（左-右-根）
def postorder(node):
    if not node:
        return ""
    return postorder(node.left) + postorder(node.right) + str(node.val)

# 层序遍历（按层逐层，从左到右）
from collections import deque
def level_order(root):
    if not root:
        return []
    result = []
    queue = deque([root])
    while queue:
        node = queue.popleft()
        result.append(node.val)
        if node.left:
            queue.append(node.left)
        if node.right:
            queue.append(node.right)
    return result

class TreeNode:
    def __init__(self, val):
        self.val = val
        self.children = []

def preorder(root):
    if root is None:
        return ''
    result = root.val
    for child in root.children:
        result += preorder(child)
    return result


def postorder(root):
    if root is None:
        return ''
    result = ''
    for child in root.children:
        result += postorder(child)
    result += root.val
    return result

from collections import deque

def level_order(root):
    if root is None:
        return ''
    result = ''
    queue = deque([root])
    while queue:
        node = queue.popleft()
        result += node.val
        for child in node.children:
            queue.append(child)
    return result


class TreeNode:
    def __init__(self, val):
        self.val = val
        self.children = []

# 构造树结构
A = TreeNode('A')
B = TreeNode('B')
C = TreeNode('C')
D = TreeNode('D')
E = TreeNode('E')
F = TreeNode('F')

A.children = [B, C, D]
C.children = [E, F]

print("前序:", preorder(A))    # 输出: ABCEFD
print("后序:", postorder(A))  # 输出: BEFCDA
print("层序:", level_order(A))# 输出: ABCDEF

"""
序列规则：

第一个数为根节点的值。
后续每对整数 (v, d) 表示一个节点的值为 v，且该节点有 d 个子节点。子节点按顺序依次排列。

输入序列：
10 3 20 2 30 1 40 0
对应树结构：
      10
     / | \
   20 30 40
   /  \
  30  40
"""
from collections import deque


class Node:
    def __init__(self, value):
        self.value = value
        self.children = []


def build_tree(sequence):
    if not sequence:
        return None

    nodes = deque()
    root = Node(sequence[0])
    nodes.append((root, sequence[1]))

    i = 2
    while i < len(sequence):
        current, degree = nodes.popleft()
        for _ in range(degree):
            child = Node(sequence[i])
            current.children.append(child)
            nodes.append((child, sequence[i + 1]))
            i += 2
    return root

"""
输入
2行，均为大写字母组成的字符串，表示一棵二叉树的中序遍历序列与后序遍历排列。

样例输入
BADC
BDCA
"""
class TreeNode:
    def __init__(self, val):
        self.val = val
        self.left = None
        self.right = None

def build_tree(inorder, postorder):
    if not inorder or not postorder:
        return None

    root_val = postorder[-1]
    root = TreeNode(root_val)

    root_index = inorder.index(root_val)
    left_inorder = inorder[:root_index]
    right_inorder = inorder[root_index+1:]

    left_postorder = postorder[:len(left_inorder)]
    right_postorder = postorder[len(left_inorder):-1]

    root.left = build_tree(left_inorder, left_postorder)
    root.right = build_tree(right_inorder, right_postorder)

    return root

"""
描述
给定一棵二叉树的前序遍历和中序遍历的结果，求其后序遍历。

输入
输入可能有多组，以EOF结束。
每组输入包含两个字符串，分别为树的前序遍历和中序遍历。每个字符串中只包含大写字母且互不重复。
输出
对于每组输入，用一行来输出它后序遍历结果。
样例输入
DBACEGF ABCDEFG
BCAD CBAD
样例输出
ACBFGED
CDAB
"""
def convert(pre,mid):
    if len(pre)<=1:
        return pre
    root = pre[0]
    pos = mid.index(root)
    l_mid = mid[:pos]
    r_mid = mid[pos+1:]
    l_pre = pre[1:pos+1]
    r_pre = pre[pos+1:]
    return convert(l_pre,l_mid)+convert(r_pre,r_mid)+root
while True:
    try:
        pre,mid = input().split()
        print(convert(pre,mid))
    except EOFError:
        break

def count_possible_trees(preorder, postorder):
    if len(preorder) != len(postorder):
        return 0
    if len(set(preorder)) != len(preorder) or len(set(postorder)) != len(postorder):
        return 0
    if not preorder:
        return 1
    if preorder[0] != postorder[-1]:
        return 0
    if len(preorder) == 1:
        return 1


    count = 0

    for i in range(len(preorder)):
        left_pre = preorder[1:i + 1]
        left_post = postorder[:i]
        right_pre = preorder[i + 1:]
        right_post = postorder[i:-1]

        if set(left_pre) == set(left_post) and set(right_pre) == set(right_post):
            count += count_possible_trees(left_pre, left_post) * count_possible_trees(right_pre, right_post)

    return count

import sys
for line in sys.stdin:
    preorder, postorder = line.strip().split()
    print(count_possible_trees(preorder, postorder))

"""
preorder=[4,2,1,3,5]
"""
class TreeNode:
    def __init__(self,val):
        self.val = val
        self.left = None
        self.right = None

def build_tree(preorder):
    if not preorder:
        return None
    root = TreeNode(preorder[0])
    left = [x for x in preorder if x < root.val]
    right = [x for x in preorder if x > root.val]
    root.left= build_tree(left)
    root.right= build_tree(right)
    return root

class TreeNode:
    def __init__(self, val):
        self.val = val
        self.left = None
        self.right = None

def build_expression_tree(tokens):
    def helper(index):
        if index[0] >= len(tokens):
            return None

        token = tokens[index[0]]
        index[0] += 1

        node = TreeNode(token)

        if token in '+-*/':
            node.left = helper(index)
            node.right = helper(index)

        return node

    return helper([0]) #返回根节点


"""
将二叉树的空结点用·补齐,把这样处理后的二叉树称为原二叉树的扩展二叉树
现给出扩展二叉树的先序序列

输入
扩展二叉树的先序序列（全部都由大写字母或者.组成）
样例输入
ABD..EF..G..C..
"""

class TreeNode:
    def __init__(self, val):
        self.val = val
        self.left = None
        self.right = None

class BinaryTreeBuilder:
    def __init__(self, preorder):
        self.preorder = preorder
        self.index = 0  # 用来跟踪当前处理的位置

    def build_tree(self):
        if self.index >= len(self.preorder):
            return None
        ch = self.preorder[self.index]
        self.index += 1
        if ch == '.':
            return None
        node = TreeNode(ch)
        node.left = self.build_tree()
        node.right = self.build_tree()
        return node

class TreeNode:
    def __init__(self, val):
        self.val = val
        self.left = None
        self.right = None

def build_expression_tree(postfix_tokens):
    stack = []
    operators = ['+', '-', '*', '/']

    for token in postfix_tokens:
        if token not in operators:
            # 操作数：直接变成叶子节点
            node = TreeNode(token)
            stack.append(node)
        else:
            # 运算符：弹出两个子树
            right = stack.pop()
            left = stack.pop()
            node = TreeNode(token)
            node.left = left
            node.right = right
            stack.append(node)

    #返回根节点
    return stack[0] if stack else None

"""
输入为一个字符串 s，表示二叉树的括号表示法。
格式规则：
空节点：用 * 表示。
节点值：单个字符（如 A, 1, +）。
子树：用括号 () 包裹左右子树，中间用逗号 , 分隔。
例如：A(B,C) 表示根节点为 A，左子树为 B，右子树为 C。
"""
class TreeNode:
    def __init__(self, val):
        self.val = val
        self.left = None
        self.right = None

def build_tree(s: str) -> TreeNode:
    def parse(index):
        if index >= len(s):
            return None, index

        # 空树
        if s[index] == '*':
            return None, index + 1

        # 读根节点
        root = TreeNode(s[index])
        index += 1

        if index < len(s) and s[index] == '(':
            index += 1
            # 先递归解析左子树
            left, index = parse(index)

            # 如果当前是逗号，说明还有右子树
            if index < len(s) and s[index] == ',':
                index += 1
                right, index = parse(index)
            else:
                right = None

            # 遇到 ')' 说明这个子树解析完毕
            if index < len(s) and s[index] == ')':
                index += 1

            root.left = left
            root.right = right

        return root, index

    tree, _ = parse(0)
    return tree


"""
A(B,C,D(E,F(G)))
"""
class TreeNode:
    def __init__(self, val):
        self.val = val
        self.children =[]

def build_tree(s: str) -> TreeNode:
    stack = []
    curr = None
    root = None
    i = 0
    while i < len(s):
        ch = s[i]
        if ch.isalpha():  # 是一个节点字母
            node = TreeNode(ch)
            if not root:
                root = node #第一个字母是根节点
            if stack:
                stack[-1].children.append(node)
            curr = node
        elif ch == '(':  # 当前节点有子节点，入栈
            stack.append(curr)
        elif ch == ')':  # 当前子树结束，出栈
            stack.pop()
        # ',' 什么也不做，下一个孩子即将出现
        i += 1
    return root

"""
每行是一个由“u”和“d”组成的字符串，表示一棵树的深度优先搜索信息。
比如，dudduduudu可以用来表示上文中的左树，
  0
1 2 3
 4 5
因为搜索过程为：
0 Down to 1 Up to 0 Down to 2 Down to 4 Up to 2 Down to 5 Up to 2 Up to 0 Down to 3 Up to 0。
"""
class TreeNode:
    def __init__(self, val):
        self.val = val
        self.children = []

def build_tree_from_ud(ud_seq):
    stack = []
    node_id = 0  # 用数字给节点编号

    root = TreeNode(node_id)
    current = root
    stack.append(current)
    node_id += 1

    for ch in ud_seq:
        if ch == 'd':
            new_node = TreeNode(node_id)
            stack[-1].children.append(new_node)
            stack.append(new_node)
            node_id += 1
        elif ch == 'u':
            stack.pop()

    return root


class TreeNode:
    def __init__(self, val):
        self.val = val
        self.left = None
        self.right = None

def build_binary_tree_dfs(seq):
    node_id = 1  # 0 是已有的根
    root = TreeNode(0)
    stack = [root]

    for ch in seq:
        if ch == 'd':
            new_node = TreeNode(node_id)
            node_id += 1
            parent = stack[-1]
            if not parent.left:
                parent.left = new_node
            else:
                parent.right = new_node
            stack.append(new_node)
        elif ch == 'u':
            stack.pop()

    return root

"""
输入方式：
若干行，每行由若干个用空格分隔的大写字母构成，描述了树的一个非叶子结点。
每行的第一个字母代表一个结点，后面的字母代表该结点的子结点。第1行描述的是树根。
如果树只有一个结点，则输入只有一行，那一行中只有一个字母。
e.g.
A B C D
B E F
C G
D H I
F J
"""
class GeneralTreeNode:
    def __init__(self, val):
        self.val = val
        self.children = []  # 多个子节点

# 构造普通树
nodes = {}  # 字母 -> GeneralTreeNode 映射

import sys
lines=[line for line in sys.stdin]
for line in  lines:
    parts = line.strip().split()
    parent_val = parts[0]
    if parent_val not in nodes:
        nodes[parent_val] = GeneralTreeNode(parent_val)
    parent = nodes[parent_val]

    for child_val in parts[1:]:
        if child_val not in nodes:
            nodes[child_val] = GeneralTreeNode(child_val)
        parent.children.append(nodes[child_val])

"""
现在需要n个木板，且给定这n个木板的长度。现有一块长度为这n个木板长度之和的长木板，需要把这个长木板分割需要的n块（一空需要切n-1刀）。每次切一刀时，切之前木板的长度是本次切割的成本。（例如，将长度为21的木板切成长度分别为8、5、8的三块。切第一刀时的成本为21，将其切成长度分别为13和8的两块。第二刀成本为13，并且将木板切成长度为8和5的两块，这样工作完成，总成本为21+13=34。另外，假如第一刀将木板切成长度为16和5的两块，则总开销为21+16=37，比上一个方案开销更大）。请你设计一种切割的方式，使得最后切完后总成本最小。
可以应用Huffman树求解此问题。

输入：
第1行：一个整数n，为需要的木板数量
第2行----第n+1行：每块木板的长度

输出：
一个整数，最小的总成本

样例输入
3
8
5
8
样例输出
34
"""

"""
每次都将当前最短的两块木板合并，它们合并的代价就是它们的长度之和，这个“新木板”再加入木板集合中。
不断重复这个过程，直到只剩一块木板。
用一个最小堆维护当前可用的木板段，始终合并最短的两个。

为什么这样能最省成本？
因为代价总是等于合并前的两块的长度之和，所以越早合并小的，大的就不参与多次合并，从而避免高代价。

"""
import heapq

n = int(input())
lengths = [int(input()) for _ in range(n)]

if n == 1:
    print(0)
else:
    heapq.heapify(lengths)
    total_cost = 0

    while len(lengths) > 1:
        a = heapq.heappop(lengths)
        b = heapq.heappop(lengths)
        cost = a + b
        total_cost += cost
        heapq.heappush(lengths, cost)

    print(total_cost)

"""
输入
第一行是一个整数n，表示二叉树的结点个数。二叉树结点编号从0到n-1。n <= 100
接下来有n行，依次对应二叉树的编号为0,1,2....n-1的节点。
每行有两个整数，分别表示该节点的左儿子和右儿子的编号。如果第一个（第二个）数为-1则表示没有左（右）儿子

样例输入
3
-1 -1
0 2
-1 -1
"""
class TreeNode:
    def __init__(self, val, left=None, right=None):
        self.val = val
        self.left = left
        self.right = right

def build_tree(n):
    nodes = [TreeNode(i) for i in range(n)]
    children = set()
    for i in range(n):
        left, right = map(int, input().split())
        if left != -1:
            nodes[i].left = nodes[left]
            children.add(left)
        if right != -1:
            nodes[i].right = nodes[right]
            children.add(right)
    for i in range(n):
        if i not in children:
            return nodes[i]
    return None

"""
n = 5
node_info = [
    (0, 1, 2),  # 节点 0 的左孩子是 1，右孩子是 2
    (1, -1, -1),  # 节点 1 无子节点
    (2, 3, 4),  # 节点 2 的左孩子是 3，右孩子是 4
    (3, -1, -1),  # 节点 3 无子节点
    (4, -1, -1),  # 节点 4 无子节点
]
"""
class TreeNode:
    def __init__(self, val):
        self.val = val
        self.left = None
        self.right = None


def build_tree(n, node_info):
    # 预先创建所有节点
    nodes = [TreeNode(i) for i in range(n)]

    for X, Y, Z in node_info:
            nodes[X].left = nodes[Y]
            nodes[X].right = nodes[Z]

    # 根节点始终是0
    return nodes[0]

"""
样例输入
41 467 334 500 169 724 478 358 962 464 705 145 281 827 961 491 995 942 827 436
"""
class TreeNode:
    def __init__(self, val):
        self.val = val
        self.left = None
        self.right = None

def insert(root, val):
    if root is None:
        return TreeNode(val)
    if val < root.val:
        root.left = insert(root.left, val)
    else:  # 允许重复时插入右子树；若不允许可加判断
        root.right = insert(root.right, val)
    return root


import sys

data = sys.stdin.read().strip()
# 将输入字符串以空格拆分，并转换为整数列表
numbers = list(map(int, data.split()))

root = None
seen = set()  # 用于记录已出现的数字，防止重复插入
# 遍历输入的数字列表
for num in numbers:
    if num not in seen:
        seen.add(num)
        root = insert(root, num)  # 只对未出现的数字进行插入操作

"""
描述
根据字符使用频率(权值)生成一棵唯一的哈夫曼编码树。生成树时需要遵循以下规则以确保唯一性：

选取最小的两个节点合并时，节点比大小的规则是:
1) 权值小的节点算小。权值相同的两个节点，字符集里最小字符小的，算小。
例如 （{'c','k'},12) 和 ({'b','z'},12)，后者小。
2) 合并两个节点时，小的节点必须作为左子节点
3) 连接左子节点的边代表0,连接右子节点的边代表1

然后对输入的串进行编码或解码

输入
第一行是整数n，表示字符集有n个字符。
接下来n行，每行是一个字符及其使用频率（权重）。字符都是英文字母。
再接下来是若干行，有的是字母串，有的是01编码串。
输出
对输入中的字母串，输出该字符串的编码
对输入中的01串,将其解码，输出原始字符串
样例输入
3
g 4
d 8
c 10
dc
110
样例输出
110
dc
"""
import heapq
import sys

class Node:
    def __init__(self, chars, freq):
        self.chars = set(chars)
        self.freq = freq
        self.left = None
        self.right = None

    def __lt__(self, other):
        # 先按频率比，再按字符集中字典序最小的字符比
        if self.freq != other.freq:
            return self.freq < other.freq
        return min(self.chars) < min(other.chars)

def build_huffman_tree(char_freq):
    heap = [Node(ch, freq) for ch, freq in char_freq.items()]
    heapq.heapify(heap)

    while len(heap) > 1:
        a = heapq.heappop(heap)
        b = heapq.heappop(heap)
        merged = Node(a.chars | b.chars, a.freq + b.freq)
        merged.left = a
        merged.right = b
        heapq.heappush(heap, merged)

    return heap[0]

def generate_codes(node, prefix="", code_map=None):
    if code_map is None:
        code_map = {}
    if node.left is None and node.right is None:
        ch = next(iter(node.chars))
        code_map[ch] = prefix
    else:
        if node.left:
            generate_codes(node.left, prefix + "0", code_map)
        if node.right:
            generate_codes(node.right, prefix + "1", code_map)
    return code_map

def encode(s, code_map):
    return ''.join(code_map[ch] for ch in s)

def decode(bits, root):
    result = []
    node = root
    for bit in bits:
        node = node.left if bit == '0' else node.right
        if node.left is None and node.right is None:
            result.append(next(iter(node.chars)))
            node = root
    return ''.join(result)

# 读取标准输入
lines = sys.stdin.read().splitlines()
n = int(lines[0])
char_freq = {}
for i in range(1, n + 1):
    ch, freq = lines[i].split()
    char_freq[ch] = int(freq)

# 构建哈夫曼树和编码映射
root = build_huffman_tree(char_freq)
code_map = generate_codes(root)

# 处理后续输入的字母串或编码串
for line in lines[n + 1:]:
    if all(c in '01' for c in line):
        print(decode(line, root))
    else:
        print(encode(line, code_map))

"""
输入
输入数据的第一行包括一个正整数n，表示森林中非空的树的数目。
随后的 n 行，每行给出一棵树的带度数的层次序列。
树的节点名称为A-Z的单个大写字母。
输出
输出包括一行，输出对应森林的后根遍历序列。
样例输入
2
C 3 E 3 F 0 G 0 K 0 H 0 J 0
D 2 X 0 I 0
样例输出
K H J E F G C X I D

        C
      / | \
     E  F  G
    /|\
   K H J
"""

from collections import deque

class TreeNode:
    def __init__(self,val):
        self.val = val
        self.children = []

def build(s):
    if not s:
        return None

    queue = deque()
    root = TreeNode(s[0])
    queue.append((root,s[1]))

    i = 2
    while i<len(s):
        cur,degree = queue.popleft()
        for _ in range(degree):
            child = TreeNode(s[i])
            cur.children.append(child)
            queue.append((child,s[i+1]))
            i+=2
    return root

def postorder(root):
    res = []
    if root:
        for child in root.children:
            res.extend(postorder(child))
        res.append(root.val)
    return res

n=int(input())
result=[]
for i in range(n):
    s=list(input().split())
    for _ in range(1,len(s),2):
        s[_] = int(s[_])
    root = build(s)
    res = postorder(root)
    for j in res:
        result.extend(j)
print(" ".join(map(str,result)))

"""
A
	B
		*
		D
			E
	F
		G
			*
			I
		H
"""

class Node:
    def __init__(self, val):
        self.val = val
        self.left = None
        self.right = None
        self.left_processed = False
        self.right_processed = False

def build_tree(lines):
    root = None
    level_parents = {}  # 保存各层级当前的父节点
    for line in lines:
        if not line.strip():
            continue
        stripped_line = line.lstrip('\t')
        t = len(line) - len(stripped_line)
        val = stripped_line.strip()
        if t == 0:
            root = Node(val)
            level_parents = {0: root}
        else:
            parent_level = t - 1
            if parent_level not in level_parents:
                continue  # 输入错误，但题目保证输入合法
            parent = level_parents[parent_level]
            if not parent.left_processed:
                if val == '*':
                    parent.left = None
                    parent.left_processed = True
                else:
                    node = Node(val)
                    parent.left = node
                    parent.left_processed = True
                    level_parents[t] = node
            else:
                if val == '*':
                    continue  # 右子节点不能为*，题目保证输入合法
                node = Node(val)
                parent.right = node
                parent.right_processed = True
                level_parents[t] = node
    return root

"""
文本缩进树就是由若干行文本来表示一棵树。其定义如下:

1) 每一行代表一个结点，每个结点是一个英文字母。

2) 每个结点的父结点，就是它上方，离它最近的，比它往左偏移了一个制表符的那个结点。没有父结点的结点，是树根。

3) 一个结点的子树，在文本表示法中总是左边的先于右边的被表示出来。
样例输入
A
	B
		E
		F
	C
		G
	D
"""
import sys


class TreeNode:
    def __init__(self, val):
        self.val = val
        self.children = []


def build_tree(lines):
    root = None
    stack = []  # Each element is (node, indent_level)

    for line in lines:
        stripped_line = line.lstrip('\t')
        indent_level = len(line) - len(stripped_line)
        node_val = stripped_line.strip()
        if not node_val:
            continue

        node = TreeNode(node_val)

        if indent_level == 0:
            root = node
            stack = [(node, 0)]
        else:
            while stack and stack[-1][1] >= indent_level:
                stack.pop()
            parent, _ = stack[-1]
            parent.children.append(node)
            stack.append((node, indent_level))

    return root


def preorder(root):
    if not root:
        return []
    result = [root.val]
    for child in root.children:
        result.extend(preorder(child))
    return result


def postorder(root):
    if not root:
        return []
    result = []
    for child in root.children:
        result.extend(postorder(child))
    result.append(root.val)
    return result


def main():
    lines = []
    for line in sys.stdin:
        lines.append(line.rstrip('\n'))

    root = build_tree(lines)

    pre = preorder(root)
    post = postorder(root)

    print(''.join(pre))
    print(''.join(post))


if __name__ == '__main__':
    main()

"""
输入一棵文本形式表示的树，树节点都是大写字母。
建立一棵儿子兄弟形式的二叉树来表示该树

A
	B
		E
	C
		F
		G
	D
		H
			I
"""
class BinaryTree:
    def __init__(self, data, left=None, right=None):
        self.data, self.left, self.right = data, left, right

    def addLeft(self, tree):
        self.left = tree

    def addRight(self, tree):
        self.right = tree

    def preorderTravel(self, op):
        op(self.data)
        if self.left:
            self.left.preorderTravel(op)
        if self.right:
            self.right.preorderTravel(op)

    def inorderTravel(self, op):
        if self.left:
            self.left.inorderTravel(op)
        op(self.data)
        if self.right:
            self.right.inorderTravel(op)

    def postorderTravel(self, op):
        if self.left:
            self.left.postorderTravel(op)
        if self.right:
            self.right.postorderTravel(op)
        op(self.data)


nodes = []
# nodes内容形如：[(0, 'A'), (1, 'B'), (2, 'E')......]
nodesPtr = 0  # 表示看到nodes里的第几个


def buildTreeInBinary(level): #递归 level是当前要构建的树的层级
    # 要求此函数返回一个BinaryTree对象
    global nodesPtr
    if nodesPtr >= len(nodes):
        return None
    current_level, data = nodes[nodesPtr]
    if current_level != level:
        return None
    nodesPtr += 1 #指向下一个节点
    left_child = buildTreeInBinary(level + 1) #递归地处理当前节点的左子树，左子树应该是下一层级的节点。
    right_sibling = buildTreeInBinary(level) #递归地处理当前节点的右兄弟（同层级的右侧节点）
    return BinaryTree(data, left_child, right_sibling)


while True:
    try:
        s = input().rstrip()
        nodes.append((len(s) - 1, s.strip())) #(/t的个数，字母）
    except:
        break
tree = buildTreeInBinary(0)
tree.preorderTravel(lambda x: print(x, end=""))
print()
tree.inorderTravel(lambda x: print(x, end=""))

"""
有 n 堆果子，每次合并两堆，消耗体力为两堆数量之和。求将所有果子合并为一堆的最小总体力消耗。
输入

第一行：整数 n（1≤n≤10000）。
第二行：n 个整数，表示每堆果子的数量。
输出

最小总体力消耗值。
样例

输入：
3
1 2 9
输出：
15
（合并顺序：1+2=3，消耗 3；3+9=12，总消耗 3+12=15）
"""
import heapq

n = int(input())

if n == 0:
    print(0)
else:
    fruits = list(map(int, input().split()))
    heapq.heapify(fruits)
    total = 0

    while len(fruits)>1:
        a=heapq.heappop(fruits)
        b=heapq.heappop(fruits)
        merged = a+b
        total += merged
        heapq.heappush(fruits,merged)
    print(total)

"""
输入要求：
多组数据，以 '*' 结束一组，以 '#' 结束全部。
每组数据包含若干文件名或目录名：
目录名以 'd' 开头，内容以 ']' 结尾（可嵌套）
文件名以 'f' 开头
不超过 30 个子项（子目录+文件），文件名最长 30 字符，无空格

输出要求：
每组以 DATA SET x: 开头，x 从 1 开始
统一从 ROOT 开始显示目录结构
使用缩进层级表示子目录结构：每层缩进为 |
目录按出现顺序输出，文件按字典序输出
多组输出之间空一行

示例输入：
file1
file2
dir3
dir2
file1
file2
]
]
file4
dir1
]
file3
*
file2
file1
*
#

输出：
DATA SET 1:
ROOT
|     dir3
|     |     dir2
|     |     file1
|     |     file2
|     dir1
file1
file2
file3
file4

DATA SET 2:
ROOT
file1
file2


"""
import heapq

data_set_count = 0

class Dir:
    def __init__(self, name):
        self.name = name #目录名
        self.subdirs = [] #子目录列表
        self.subfiles = [] #用最小堆存储文件，保证输出时文件按字母序排列

    def add_subdir(self, subdir):
        self.subdirs.append(subdir)

    def add_file(self, filename):
        heapq.heappush(self.subfiles, filename)

def get_sub(): #递归读取目录内容（目录名和文件名），直到遇到]表示当前目录结束
    root = Dir("ROOT")
    stack = [root]

    while True:
        line = input().strip()

        if line == "#":
            break

        if line == "*":
            global data_set_count
            data_set_count += 1
            print(f"DATA SET {data_set_count}:")
            print_dir(root, 0)
            print()
            return True

        elif line == "]":
            stack.pop()

        elif line[0] == 'd':
            new_dir = Dir(line)
            stack[-1].add_subdir(new_dir)
            stack.append(new_dir)

        elif line[0] == 'f':
            stack[-1].add_file(line)

    return False

def print_dir(d, level):
    print("|     " * level + d.name)
    for subdir in d.subdirs:
        print_dir(subdir, level + 1)
    while d.subfiles:
        print("|     " * level + heapq.heappop(d.subfiles))

if __name__ == "__main__":
    while get_sub():
        continue

"""
A
	B
		*
		D
			E
	F
		G
			*
			I
		H
"""
def print_indented_tree(root):
    result = []

    def dfs(node, level):
        if not node:
            return

        # 当前节点行
        result.append('\t' * level + node.val)

        # 处理左子树
        if not node.left and node.right:
            # 左子树为空但右子树不空，添加'*'
            result.append('\t' * (level + 1) + '*')
        elif node.left:
            dfs(node.left, level + 1)

        # 处理右子树
        if node.right:
            dfs(node.right, level + 1)

    dfs(root, 0)
    return '\n'.join(result)

n = int(input()) #n个节点 一条一条边输入的
adj=[[]for _ in range(n+1)]
line = int(input()) #line条边
for _ in range(line):
    u,v = map(int,input().split())
    adj[u].append(v)
    adj[v].append(u)

"""在节点数不超过 n 的情况下，AVL 树能达到的最大高度。"""
def max_height(n):
    s = [0, 1]#AVL 树的最小节点数 s(h),高度为 1 的树至少有 1 个节点,高度为 2 的树至少有 2 个节点
    h = 2
    while True:
        next_val = 1 + s[h - 1] + s[h - 2] #高度为 h 的 AVL 树，其根节点的左子树高度至少为 h-1，右子树高度至少为 h-2
        if next_val > n:
            return h - 1
        s.append(next_val)
        h += 1

n = int(input())
print(max_height(n))

def min_nodes(n): #高度为 n 的 AVL 树所需的最少节点数
    if n == 0:
        return 0
    if n == 1:
        return 1

    dp = [0] * (n + 1)
    dp[0] = 0
    dp[1] = 1

    for i in range(2, n + 1):
        dp[i] = 1 + dp[i - 1] + dp[i - 2]

    return dp[n]

# 输入
n = int(input())
print(min_nodes(n))

"""
输入
整数n
输出
答案
样例输入
3
样例输出
5
"""

n  = int(input())
def kinds(n):
    if n==0:
        return 1
    elif n == 1:
        return 1
    else:
        sum = 0
        for i in range(n):
            left_num = kinds(i)
            right_num = kinds(n-1-i)
            sum += left_num*right_num
    return sum
print(kinds(n))

"""
程序填空
为二叉排序树类Tree添加方法lower_bound(self,x)和upper_bound(self,x)。
前者返回一个元组，包含关键字小于x的最大元素的关键字和值
后者返回一个元组，包含关键字大于x的最小元素的关键字和值
如果找不到符合要求的元组，这两个函数都返回None

输入
若干行。每行是如下三种形式之一：
1) ADD n
n是个整数。表示要往树中添加一个节点，关键字和值都是n
2) LB n
表示要求tree.lower_bound(n)
3) UB n
表示要求tree.upper_bound(n)
输出
输出:
如程序和样例所示
样例输入
ADD 68
ADD 42
LB 180
UB 35
LB 50
ADD 75
ADD 101
LB 114
UB 40
ADD 26
LB 68
UB 63
ADD 88
UB 173
UB 39
样例输出
(68, 68)
(42, 42)
(42, 42)
(101, 101)
(42, 42)
(42, 42)
(68, 68)
None
(42, 42)
"""


class TreeNode:  # 节点类
    # father在删除节点的时候有用,以及找一个节点的后继节点的时候有用
    def __init__(self, key, val, father=None, left=None, right=None):
        self.key, self.val, self.left, self.right, self.father \
            = key, val, left, right, father

    def isLeftChild(self):
        return self.father and self.father.left == self

    def isRightChild(self):
        return self.father and self.father.right == self


class Tree:
    def __init__(self, NodeType=TreeNode, less=lambda x, y: x < y):
        self.root, self.size = None, 0  # root是树根，size是节点总数
        self.less = less  # less是比较函数,
        self.NodeType = NodeType  # NodeType是节点类型

    def __find(self, key, root):  # 私有方法，不宜也不易直接访问
        if self.root == None:
            return None
        if self.less(key, root.key):
            if root.left:
                return self.__find(key, root.left)
            else:
                return None
        elif self.less(root.key, key):
            if root.right:
                return self.__find(key, root.right)
            else:
                return None
        else:
            return root

    def insert(self, key, val):  # 插入节点 #modi
        if self.root == None:
            self.root = self.NodeType(key, val)
            self.size += 1
        else:
            if self.__inserter(key, val, self.root):
                self.size += 1

    def __inserter(self, key, val, root):  # modi
        if self.less(key, root.key):
            if root.left == None:
                root.left = self.NodeType(key, val, root)  # root是father
                return True
            else:
                return self.__inserter(key, val, root.left)
        elif self.less(root.key, key):
            if root.right == None:
                root.right = self.NodeType(key, val, root)
                return True
            else:
                return self.__inserter(key, val, root.right)
        else:
            root.val = val  # 相同关键字，则更新
            return False

    def findMin(self):  # 寻找最小节点  #modi
        if self.root == None:
            return None
        nd = self.__findMin(self.root)
        return (nd.key, nd.val)

    def __findMin(self, root):
        if root.left == None:
            return root
        else:
            return self.__findMin(root.left)

    def __findMax(self, root):
        if root.right == None:
            return root
        else:
            return self.__findMax(root.right)

    def pop(self, key):
        # 删除键为key的元素，返回该元素的值。如果没有这样的元素，则引发异常
        nd = self.__find(key, self.root)
        if nd == None:
            raise Exception("key not found")
        else:
            self.size -= 1
            self.__deleteNode(nd)

    def __deleteNode(self, nd):  # 删除节点nd
        if nd.left and nd.right:  # 左右子树都有
            minNd = self.__findMin(nd.right)
            nd.key, nd.val = minNd.key, minNd.val
            self.__deleteNode(minNd)
        elif nd.left:  # 只有左子树
            if nd.isLeftChild():
                nd.father.left = nd.left
                nd.left.father = nd.father
            elif nd.isRightChild():
                nd.father.right = nd.left
                nd.left.father = nd.father
            else:  # 是树根
                self.root = nd.left
                self.root.father = None
        elif nd.right:  # 只有右子树
            if nd.isRightChild():
                nd.father.right = nd.right
                nd.right.father = nd.father
            elif nd.isLeftChild():
                nd.father.left = nd.right
                nd.right.father = nd.father
            else:
                self.root = nd.right
                self.root.father = None
        else:  # nd是叶子
            if nd.isLeftChild():
                nd.father.left = None
            elif nd.isRightChild():
                nd.father.right = None
            else:
                self.root = None

    def inorderTravelSeq(self):  # 中序遍历生成器
        if self.root == None:
            return
        stack = [[self.root, 0]]  # 0表示self的左子树还没有遍历过
        while len(stack) > 0:
            node = stack[-1]
            if node[0] == None:  # node[0]是树节点
                stack.pop()
                continue
            if node[1] == 0:  # 左子树还没有遍历过
                node[1] = 1
                stack.append([node[0].left, 0])
            elif node[1] == 1:  # 左子树已经遍历过
                yield (node[0].key, node[0].val)
                node[1] = 2
                stack.append([node[0].right, 0])
            else:  # 右子树也遍历完了
                stack.pop()

    def __contains__(self, key):
        return self.__find(key, self.root) != None

    def __iter__(self):  # 返回迭代器
        return self.inorderTravelSeq()

    def __getitem__(self, key):
        nd = self.__find(key, self.root)
        if nd == None:
            raise Exception("key not found")
        else:
            return nd.val

    def __setitem__(self, key, value):  #
        nd = self.__find(key, self.root)
        if nd == None:
            self.insert(key, value)
        else:
            nd.val = value

    def lower_bound(self, x):
        return self.__lower_bound_helper(self.root, x)

    def __lower_bound_helper(self, node, x):
        if node is None:
            return None
        if self.less(node.key, x):
            right_result = self.__lower_bound_helper(node.right, x)
            if right_result is not None:
                return right_result
            else:
                return (node.key, node.val)
        else:
            return self.__lower_bound_helper(node.left, x)

    def upper_bound(self, x):
        return self.__upper_bound_helper(self.root, x)

    def __upper_bound_helper(self, node, x):
        if node is None:
            return None
        if self.less(x, node.key):
            left_result = self.__upper_bound_helper(node.left, x)
            if left_result is not None:
                return left_result
            else:
                return (node.key, node.val)
        else:
            return self.__upper_bound_helper(node.right, x)

tree = Tree()
while True:
    try:
        s = input().split()
        if s[0] == "ADD":
            tree[int(s[1])] = int(s[1])
        elif s[0] == "LB":
            print(tree.lower_bound(int(s[1])))
        elif s[0] == "UB":
            print(tree.upper_bound(int(s[1])))
    except:
        break

"""
给定两棵二叉树，判断是否可以通过任意次交换节点的左右子树，使两棵树的结构完全相同。若可以，输出 “yes”，否则输出 “no”。

输入
第一行是整数t(t<10)，表示有t组测试数据。
每组测试数据包含两棵二叉树的描述。
对每棵二叉树，第一行是结点数目n(n<20)，结点编号从0到n-1。
在接下来的n行每行都是两个整数a,b。第i行（i从1开始算)描述的是编号为i-1的结点，其左子结点是a，右子结点是b。没有左子结点或右子结点，则a或b的值为-1。
输出
对每组数据中的两棵二叉树，如果二者同构，输出yes，否则输出no
样例输入
2
4
2 3
-1 -1
-1 -1
-1 1
4
2 3
-1 -1
-1 -1
1 -1
3
1 -1
2 -1
-1 -1
3
-1 -1
-1 2
-1 0
样例输出
yes
no
"""
def build_tree(n):
    tree = {}
    for i in range(n):
        left, right = map(int, input().split())
        tree[i] = (left, right) #存储每个节点的左右孩子
    return tree

def is_isomorphic(a_tree, a_node, b_tree, b_node):
    if a_node == -1 and b_node == -1:#两棵子树均为空
        return True
    # 一棵子树为空，另一棵不为空
    if a_node == -1 or b_node == -1:
        return False
    # 获取当前节点的左右子节点索引
    a_left, a_right = a_tree[a_node]
    b_left, b_right = b_tree[b_node]
    # 两种情况：
    # 情况1：不交换左右子树，直接匹配
    case1 = is_isomorphic(a_tree, a_left, b_tree, b_left) and is_isomorphic(a_tree, a_right, b_tree, b_right)
    # 情况2：交换左右子树后匹配
    case2 = is_isomorphic(a_tree, a_left, b_tree, b_right) and is_isomorphic(a_tree, a_right, b_tree, b_left)
    # 只要有一种情况成立，就说明同构
    return case1 or case2

t = int(input())
for _ in range(t):
    # 读取第一棵树
    n1 = int(input())
    tree1 = build_tree(n1)
    # 读取第二棵树
    n2 = int(input())
    tree2 = build_tree(n2)
    # 假设根节点均为0（题目中节点编号从0开始，根节点通常为0，除非输入中另有结构）
    # 这里需要注意：如果树可能有多个根节点（如森林），但题目中应为二叉树，根节点唯一，通常为0
    # 题目中输入的树应为有效的二叉树，根节点是没有父节点的节点，这里假设根节点是0
    # 若输入的树结构中根节点不是0，需要先找到根节点（此处简化处理，假设根节点为0）
    result = is_isomorphic(tree1, 0, tree2, 0)
    print("yes" if result else "no")

"""
由正整数1，2，3……组成了一颗二叉树。我们已知这个二叉树的最后一个结点是n。现在的问题是，结点m所在的子树中一共包括多少个结点。

输入
输入数据包括多行，每行给出一组测试数据，包括两个整数m，n (1 <= m <= n <= 1000000000)。最后一组测试数据中包括两个0，表示输入的结束，这组数据不用处理。
输出
对于每一组测试数据，输出一行，该行包含一个整数，给出结点m所在子树中包括的结点的数目。
样例输入
3 12
0 0
样例输出
4
"""
''''
层序遍历以m为根节点的树
每层取2的level次方[这一层是满的话的节点数]和 n-m+1 的较小者
'''
def count_nodes(n,m):
    level = 0
    count = 0
    while m<=n:
        count += min(2**level,n-m+1)
        level+=1
        m=2*m #下一层左节点
    return count
while True:
    m,n=map(int,input().split())
    if m==n==0:
        break
    print(count_nodes(n,m))

"""
描述
假设二叉树的节点里包含一个大写字母，每个节点的字母都不同。
给定二叉树的前序遍历序列和后序遍历序列(长度均不超过20)，请计算二叉树可能有多少种

前序序列或后序序列中出现重复字母则直接认为不存在对应的树

输入
多组数据
每组数据一行，包括前序遍历序列和后序遍历序列，用空格分开。
输入数据不保证一定存在满足条件的二叉树。
输出
每组数据，输出不同的二叉树可能有多少种
样例输入
ABCDE CDBEA
BCD DCB
AB C
AA AA
样例输出
1
4
0
0
"""

def count_possible_trees(preorder, postorder):
    if len(preorder) != len(postorder):
        return 0
    if len(set(preorder)) != len(preorder) or len(set(postorder)) != len(postorder):
        return 0
    if not preorder:
        return 1
    if preorder[0] != postorder[-1]:
        return 0
    if len(preorder) == 1:
        return 1


    count = 0

    """
    这段逻辑隐含了“左 + 右”两个孩子的结构假设，也就是隐含了“二叉树”的结构假设。
    但在 m叉树中，子树个数不固定（1到m个都行），不能只枚举成两个子树的组合，而要枚举所有可能的子树划分方式！
    """

    for i in range(len(preorder)):
        left_pre = preorder[1:i + 1]
        left_post = postorder[:i]
        right_pre = preorder[i + 1:]
        right_post = postorder[i:-1]

        if set(left_pre) == set(left_post) and set(right_pre) == set(right_post):
            count += count_possible_trees(left_pre, left_post) * count_possible_trees(right_pre, right_post)

    return count

import sys
for line in sys.stdin:
    preorder, postorder = line.strip().split()
    print(count_possible_trees(preorder, postorder))

"""
每个实例将包含一行形式m s1 s2
m 叉树，s1 是前序遍历，s2 是后序遍历.。所有遍历字符串将只包含小写字母。对于所有输入实例，1 <= m <= 20，且 s1 和 s2 的长度将在 1 到 26 之间（含）。如果 s1 的长度为 k（当然，s2 的长度也相同），则字符串将使用字母表的前 k 个字母。输入行 0 将结束输入。

对于每个问题实例，你应该输出一行，包含由该实例的前序遍历和后序遍历产生的可能树的数量。所有输出值都将在一个 32 位有符号整数范围内。对于每个问题实例，你都可以保证至少存在一棵树具有给定的前序遍历和后序遍历。

样例输入
2 abc cba
2 abc bca
10 abc bca
13 abejkcfghid jkebfghicda
0

样例输出
4
1
45
207352860
"""
import sys

def comb(n, m):
    # 组合数 C(n, m)
    if m < n - m:
        m = n - m # 利用对称性：C(n, m) = C(n, n - m)，减少计算量
    ans = 1
    for i in range(m + 1, n + 1): # 分子部分，乘 m+1 到 n
        ans *= i
    for i in range(1, n - m + 1): # 分母部分，除以 1 到 (n - m)
        ans //= i # 用整除保持结果是int
    return ans

#n：树的最大度数
# preleft：前递归子树在先序中的起始下标
# preright：当前递归子树在先序中的结束下标
# postleft：当前递归子树在后序中的起始下标
# postright：当前递归子树在后序中的结束下标

def possible(preord, postord, n, preleft, preright, postleft, postright):
    cnt = 0 # 统计当前根节点的孩子个数
    root = preleft + 1
    total = 1
    while root <= preright: #遍历尝试可能，找到这个树的所有孩子子树
        i = postleft # 寻找当前子树在后序中的结束位置 i
        while i <= postright and postord[i] != preord[root]:
            i += 1
        size = i - postleft + 1 #当前子树大小
        subtree_count = possible(preord, postord, n, root, root + size - 1, postleft, i) #递归处理这棵子树
        total *= subtree_count #对于当前这个子树结构，乘上它每一个孩子子树的可能结构数，得到整个子树的总结构数
        cnt += 1
        root += size
        postleft = i + 1
    total *= comb(n, cnt) #当前根节点有cnt 个子树，但在n个位置中可以随便排列
    return total

def solve(n, preord, postord):
    return possible(preord, postord, n, 0, len(preord) - 1, 0, len(postord) - 1)

# 处理输入
for line in sys.stdin:
    line = line.strip()
    if line == '0':
        break
    parts = line.split()
    n = int(parts[0])
    preord = parts[1]
    postord = parts[2]
    print(solve(n, preord, postord))

#二叉树宽度定义：结点最多的那一层的结点数目
import collections

class TreeNode:
    def __init__(self, val, left=None, right=None):
        self.val = val
        self.left = left
        self.right = right

def tree_width(root):
    if not root:
        return 0
    queue = collections.deque([root])
    max_width = 0
    while queue:
        max_width = max(max_width, len(queue))
        for _ in range(len(queue)):
            node = queue.popleft()
            if node.left:
                queue.append(node.left)
            if node.right:
                queue.append(node.right)
    return max_width


class BinaryTree:
    def __init__(self, val):
        self.val = val
        self.left = None
        self.right = None


def dfs_binary_tree(root):
    #空树高度 = -1, 单个结点高度 = 0
    if not root:
        return -1
    left = dfs_binary_tree(root.left)
    right = dfs_binary_tree(root.right)
    return max(left,right) + 1

"""
二叉树高度定义：从根结点到叶结点依次经过的结点（含根、叶结点）形成树的一条路径，最长路径的结点数减1为树的高度。只有一个结点的二叉树，高度是0。
输入
第一行是一个整数n，表示二叉树的结点个数。二叉树结点编号从0到n-1。n <= 100
接下来有n行，依次对应二叉树的编号为0,1,2....n-1的节点。
每行有两个整数，分别表示该节点的左儿子和右儿子的编号。如果第一个（第二个）数为-1则表示没有左（右）儿子
输出
在一行中输出2个整数，分别表示二叉树的高度和叶子结点个数
样例输入
3
-1 -1
0 2
-1 -1
样例输出
1 2
"""
"""
注意没说根节点是0
"""

import collections


class TreeNode:
    def __init__(self, val, left=None, right=None):
        self.val = val
        self.left = left
        self.right = right

def build_tree(n):
    nodes = [TreeNode(i) for i in range(n)]
    children = set()
    for i in range(n):
        left, right = map(int, input().split())
        if left != -1:
            nodes[i].left = nodes[left]
            children.add(left)
        if right != -1:
            nodes[i].right = nodes[right]
            children.add(right)
    for i in range(n):
        if i not in children:
            return nodes[i]
    return None


def count_leaves_and_get_height(root):
    if not root:
        return 0, -1
    queue = collections.deque([root])
    height = -1
    leaves = 0
    while queue:
        level_size = len(queue)
        height += 1
        for _ in range(level_size):
            node = queue.popleft()
            if not node.left and not node.right:
                leaves += 1
            if node.left:
                queue.append(node.left)
            if node.right:
                queue.append(node.right)
    return leaves, height


n = int(input())
root = build_tree(n)
leaves, height = count_leaves_and_get_height(root)
print(f"{height} {leaves}")

"""
描述
有一棵 k 层的满二叉树（一共有2k-1个节点，且从上到下从左到右依次编号为1, 2, ..., 2k-1），最开始每个节点的重量均为0。请编程实现如下两种操作：
1 x y：给以 x 为根的子树的每个节点的重量分别增加 y（ y 是整数且绝对值不超过100）
2 x：查询（此时的）以 x 为根的子树的所有节点重量之和

输入
输入有n+1行。第一行是两个整数k, n，分别表示满二叉树的层数和操作的个数。接下来n行，每行形如1 x y或2 x，表示一个操作。
k<=15（即最多32767个节点），n<=50000。

输出
输出有若干行，对每个查询操作依次输出结果，每个结果占一行。

样例输入
3 7
1 2 1
2 4
1 6 3
2 1
1 3 -2
1 4 1
2 3
样例输出
1
6
-3
"""
from math import log2

# 读取输入
k, n = map(int, input().split())

# 初始化数据结构,direct_updates[x] 记录对以x为根的子树的直接更新值
direct_updates = [0] * (1 << k)

# ancestor_effects[x][i] 记录x的某个祖先对子树x的影响（通过因子i）
ancestor_effects = [dict() for _ in range(1 << k)]

# 预计算每个节点的子树大小
# 子树大小 = 2^(子树高度) - 1
# 节点x的深度 = int(log2(x)) + 1
# 子树高度 = k - (节点x的深度 - 1) = k - int(log2(x))
subtree_sizes = [(1 << (k - int(log2(x)))) - 1 for x in range(1, 1 << k)]

# 处理操作
for _ in range(n):
    parts = list(map(int, input().split()))
    if parts[0] == 1:  # 更新操作
        node, value = parts[1], parts[2]
        # 记录对子树node的直接更新
        direct_updates[node] += value

        # 向上传递影响到所有祖先节点
        factor = 2  # 初始影响因子：父节点的子树被分为2部分
        parent = node // 2
        while parent > 0:
            # 记录祖先节点parent通过因子factor对子树node的影响
            ancestor_effects[parent].setdefault(factor, 0)
            ancestor_effects[parent][factor] += value
            parent //= 2  # 移动到更高层的祖先
            factor *= 2  # 影响因子翻倍（每向上一层，子树被划分的份数翻倍）
    else:  # 查询操作
        node = parts[1]
        total = 0

        # 计算所有祖先的直接更新对子树的影响
        current = node
        while current > 0:
            total += direct_updates[current]
            current //= 2
        # 总影响 = 所有祖先的直接更新值之和 × 当前子树大小
        total *= subtree_sizes[node - 1]

        # 计算通过影响因子间接作用的祖先更新
        for factor, value in ancestor_effects[node].items():
            # 每个影响因子的贡献 = (子树大小 // 因子) × 影响值
            total += (subtree_sizes[node - 1] // factor) * value

        print(total)

from math import log

k, n = map(int, input().split())
tree1 = [0] * (1 << k)# 记录每个子树收到的操作
tree2 = [dict() for _ in range(1 << k)]# 记录每个子树操作对祖先产生的影响
#numofnodes[x-1] 表示以节点x为根的子树的节点数.计算方式：2^(子树高度) - 1，即(1 << (k - 子树根的深度)) - 1。
numofnodes = [(1 << (k - int(log(x, 2)))) - 1 for x in range(1, 1 << k)]
for _ in range(n):
    action = list(map(int, input().split()))
    if action[0] == 1:
        tree1[action[1]] += action[2]
        i = 2 #影响因子i：表示当前节点的子树在祖先节点的子树中的划分比例。初始时，i=2，对应当前节点是父节点的左子树或右子树
        r = action[1] // 2 # 父节点
        while r > 0:
            tree2[r].setdefault(i, 0)
            tree2[r][i] += action[2]
            r //= 2
            i *= 2 #每向上移动一层（到祖父节点），i *= 2，表示当前子树在祖父节点的子树中占 1/4 的比例，以此类推。
    else:
        r = action[1]
        s = 0
        while r > 0: # 遍历所有祖先
            s += tree1[r] # 累加祖先的直接操作值
            r //= 2
        s *= numofnodes[action[1] - 1] # 祖先操作对当前子树的总影响
        for i in tree2[action[1]]: # 计算当前节点的tree2中记录的影响
            #tree2[x][i]=v表示在节点 x 的某个祖先的子树中，x 的子树占该祖先子树的 1/i 比例,且该祖先对 x 的子树执行了 v 的增量操作。
            s += numofnodes[action[1] - 1] // i * tree2[action[1]][i]
        # 计算子辈树对该子树的影响
        print(s)

"""
给定一棵有根树（根为 R），对于每个查询的两个节点 x 和 y，求它们的最近公共祖先（LCA）

输入
第一行：节点数 N 和根节点 R。
接下来 N-1 行：树的边。
接下来 Q 行：每个查询包含两个节点 x 和 y。

输出
对每个查询，输出 x 和 y 的最近公共祖先节点编号。
样例输入
21 1
1 2
1 3
1 4
2 5
3 6
3 7
8 4
9 4
10 4
11 5
12 5
13 5
14 7
9 15
16 9
17 9
9 18
16 19
16 20
18 21
10
19 20
19 18
16 10
12 21
11 6
2 5
3 9
14 6
17 1
15 15
样例输出
16
9
4
1
1
2
1
3
1
15
"""
#广度优先
from collections import deque

N,R=map(int,input().split())
adj = [[]for _ in range(N+1)] #无向邻接矩阵
for _ in range(N-1):
    u,v=map(int,input().split())
    adj[u].append(v)
    adj[v].append(u)

parent = [0]*(N+1) #记录每个节点的父节点
depth = [0]*(N+1) #记录每个节点的深度
parent[R] = R #保证根节点不会被误认为是未访问的点

q=deque([R])
while q:
    u=q.popleft()
    for v in adj[u]:
        if parent[v] ==0:
            parent[v]=u
            depth[v]=depth[u]+1
            q.append(v)

def lca(x,y):
    while depth[x]>depth[y]:
        x=parent[x]
    while depth[y]>depth[x]:
        y=parent[y]
    while x!=y:
        x = parent[x]
        y= parent[y]
    return x

q=int(input())
for _ in range(q):
    x,y=map(int,input().split())
    print(lca(x,y))

class GeneralTreeNode:
    def __init__(self, val):
        self.val = val
        self.children = []

def get_general_tree_depth(root):
    if not root:
        return 0
    return 1 + max((get_general_tree_depth(child) for child in root.children), default=0)

"""
输入
第一行：节点数 N 和根节点 R。
接下来 N-1 行：树的边。
样例输入
21 1
1 2
1 3
1 4
2 5
3 6
3 7
8 4
9 4
10 4
11 5
12 5
13 5
14 7
9 15
16 9
17 9
9 18
16 19
16 20
18 21
"""
#广度优先
from collections import deque

N,R=map(int,input().split())
adj = [[]for _ in range(N+1)] #无向邻接矩阵
for _ in range(N-1):
    u,v=map(int,input().split())
    adj[u].append(v)
    adj[v].append(u)

parent = [0]*(N+1) #记录每个节点的父节点
depth = [0]*(N+1) #记录每个节点的深度
parent[R] = R #保证根节点不会被误认为是未访问的点

q=deque([R])
while q:
    u=q.popleft()
    for v in adj[u]:
        if parent[v] ==0:
            parent[v]=u
            depth[v]=depth[u]+1
            q.append(v)

class TreeNode:
    def __init__(self, val):
        self.val = val
        self.left = None
        self.right = None

def find_parent(root, target):
    # 边界情况：空树或根节点就是目标节点
    if not root or root.val == target:
        return False

    # 如果左子节点是目标节点，返回当前节点
    if root.left and root.left.val == target:
        return root
    # 如果右子节点是目标节点，返回当前节点
    if root.right and root.right.val == target:
        return root

    # 递归查找左子树
    left_result = find_parent(root.left, target)
    if left_result:
        return left_result

    # 递归查找右子树
    right_result = find_parent(root.right, target)
    return right_result if right_result else False

"""
描述
一棵树，结点都用大写字母表示且不重复。请将一棵树用儿子-兄弟法表示出来

输入
若干行，每行由若干个用空格分隔的大写字母构成，描述了树的一个非叶子结点。
每行的第一个字母代表一个结点，后面的字母代表该结点的子结点。第1行描述的是树根。
如果树只有一个结点，则输入只有一行，那一行中只有一个字母。

样例输入
A B C D
B E
C F G
H I
D H
"""
class GeneralTreeNode:
    def __init__(self, val):
        self.val = val
        self.children = []  # 多个子节点

class BinaryTreeNode:
    def __init__(self, val):
        self.val = val
        self.left = None   # 指向第一个孩子
        self.right = None  # 指向下一个兄弟


def convert_to_binary_tree(node):
    if not node:
        return None
    b_node = BinaryTreeNode(node.val)
    if not node.children:
        return b_node

    # 第一个孩子作为 left
    b_node.left = convert_to_binary_tree(node.children[0])

    # 后续兄弟作为 right 链接
    current = b_node.left
    for child in node.children[1:]:
        current.right = convert_to_binary_tree(child)
        current = current.right
    return b_node

"""
       1
      / |
     2  3
    /|   \
   4 5    6
交换2 3后
        1
      /  \
     3    2
     \   /\
      6  4 5

输入
第一行输出一个整数t(t <= 100)，代表测试数据的组数。

对于每组测试数据，第一行输入两个整数n m，n代表二叉树节点的个数，m代表操作的次数。

随后输入n行，每行包含3个整数X Y Z，对应二叉树一个节点的信息。X表示节点的标识，Y表示其左孩子的标识，Z表示其右孩子的标识。

再输入m行，每行对应一次操作。每次操作首先输入一个整数type。

当type=1，节点交换操作，后面跟着输入两个整数x y，表示将标识为x的节点与标识为y的节点交换。输入保证对应的节点不是祖先关系。

当type=2，前驱询问操作(询问二叉树的一个节点对应的子树最左边的节点)，后面跟着输入一个整数x，表示询问标识为x的节点对应子树最左的孩子。

1<=n<=100，节点的标识从0到n-1，根节点始终是0.
m<=100
输出
对于每次询问操作，输出相应的结果。
"""
import sys

class Node:
    def __init__(self, val): #
        self.val = val
        self.left = None
        self.right = None
        self.parent = None

def solve():
    t = int(sys.stdin.readline())
    for test in range(t):
        n, m = map(int, sys.stdin.readline().split())
        nodes_map = [Node(i) for i in range(n)]

        for line in range(n):
            x, y, z = map(int, sys.stdin.readline().split())

            if y != -1:
                nodes_map[x].left = nodes_map[y]
                nodes_map[y].parent = nodes_map[x]
            if z != -1:
                nodes_map[x].right = nodes_map[z]
                nodes_map[z].parent = nodes_map[x]

        for op in range(m):
            op_parts = list(map(int, sys.stdin.readline().split()))
            op_type = op_parts[0]

            if op_type == 1:  #交换操作
                x, y = op_parts[1], op_parts[2]

                node_x = nodes_map[x]
                node_y = nodes_map[y]

                parent_x = node_x.parent
                parent_y = node_y.parent

                if parent_x.val==parent_y.val:
                    parent_xy = parent_x
                    if parent_xy.left==node_x:
                        parent_xy.left=node_y
                        parent_xy.right=node_x
                    else:
                        parent_xy.right=node_y
                        parent_xy.left=node_x

                else:#两节点不是一个父亲
                    if parent_x.left==node_x:#x是他父亲的左节点
                        parent_x.left = node_y
                        if parent_y.left==node_y:#y是他父亲的左节点
                            parent_y.left=node_x
                        else:#y是他父亲的右节点
                            parent_y.right=node_x

                    else:#x是他父亲的右节点
                        parent_x.right=node_y
                        if parent_y.left==node_y:#y是他父亲的左节点
                            parent_y.left=node_x
                        else:#y是他父亲的右节点
                            parent_y.right=node_x

                    node_x.parent=parent_y
                    node_y.parent=parent_x

            elif op_type == 2:  #查询
                x = op_parts[1]

                current_node = nodes_map[x]

                while current_node.left:
                    current_node = current_node.left

                sys.stdout.write(str(current_node.val) + "\n")


solve()

class TreeNode:
    def __init__(self, val=0, left=None, right=None):
        self.val = val
        self.left = left
        self.right = right


def invertTree(root: TreeNode) -> TreeNode:
    if not root:
        return None

    # 交换当前节点的左右子树
    root.left, root.right = root.right, root.left

    # 递归处理左子树和右子树
    invertTree(root.left)
    invertTree(root.right)

    return root
#层序遍历：[4,2,7,1,3,6,9] 变成 [4,7,2,9,6,3,1]

"""
给定一棵完全二叉树（节点编号 1-N，自上而下、自左向右），每个节点有一个宝藏价值。选取若干节点，使得任意两个选中节点不相邻（即无父子关系），求所选节点价值总和的最大值。
输入
第一行：节点数 N。
第二行：N 个非负整数，第 i 个数为节点 i 的宝藏价值。
输出
满足条件的最大价值总和。

样例输入：
6
3 4 5 1 3 1
输出：9
"""
"""
最大独立集问题，可以通过动态规划高效解决。
对于每个节点 i，有两种状态：
    选：当前节点 i 被选中时，其左右子节点（2i, 2i+1）不能被选，但可以选孙子节点（4i, 4i+1, 4i+2, 4i+3）。
    不选：当前节点 i 不被选中时，可以选择其左右子节点（2i, 2i+1），但不能选孙子节点。
"""
n = int(input())
l = list(map(int, input().split()))
l = [0] + l
#这返回的是一个函数，用于返回节点i的权重
L = lambda i : l[i] if i<=n else 0
for i in range(n, 0, -1):
    l[i] = max(L(2*i)+L(2*i+1), l[i]+L(4*i)+L(4*i+1)+L(4*i+2)+L(4*i+3))
print(l[1])

"""
问题描述
初始有n个元素，编号为1到n，每个元素在一个独立的集合中。
有m次操作，每次操作输入两个整数x和y：
- 如果x和y已经属于同一个集合，输出"Yes"；
- 否则，将y所在集合的所有元素合并到x所在集合中，并输出"No"。
所有操作完成后，输出当前有多少个集合，以及每个集合的代表元素（即每个集合的根），按升序排列

输入格式：
多组测试数据，每组数据格式如下：
n m
x₁ y₁
x₂ y₂
...
xₘ yₘ`

- `1 ≤ x, y ≤ n`
- `1 ≤ n, m ≤ 50000`
- 测试组数 < 5
输入以文件结束为止。

输出格式
对于每组测试数据：
- 前 `m` 行，每次操作输出 `"Yes"` 或 `"No"`
- 第 `m+1` 行输出当前集合的数量
- 第 `m+2` 行输出这些集合的代表元素（即每个集合的根），按升序排列
## 示例输入
3 2
1 2
2 1
4 2
1 2
4 3`
## 示例输出
No
Yes
2
1 3
No
No
2
1 4

"""

import sys

class UnionFind:
    def __init__(self, n):
        self.parent = list(range(n + 1))

    def find(self, x):
        if self.parent[x] != x:
            self.parent[x] = self.find(self.parent[x])  # 路径压缩
        return self.parent[x]

    def union(self, x, y):
        rootX = self.find(x)
        rootY = self.find(y)
        if rootX == rootY:
            return True  # 已经在同一个集合
        self.parent[rootY] = rootX  # 把y集合并到x集合
        return False


while True:
    try:
        line = sys.stdin.readline()
        if not line:
            break
        n, m = map(int, line.strip().split())
        uf = UnionFind(n)
        for _ in range(m):
            x, y = map(int, sys.stdin.readline().strip().split())
            if uf.union(x, y):
                print("Yes")
            else:
                print("No")
        # 最后统计有哪些集合代表仍然是自己的（即这些位置有“饮料”）
        result = set()
        for i in range(1, n + 1):
            result.add(uf.find(i))
        print(len(result))
        print(' '.join(map(str, sorted(result))))
    except:
        break

"""
给定一个无向图，每条边连接两个点，图是树加一条多余的边。返回这条「冗余边（即成环边）
如果有多个答案，则返回输入中最后出现的答案。

e.g.
Input: edges = [[1,2],[1,3],[2,3]]
Output: [2,3]

Input: edges = [[1,2],[2,3],[3,4],[1,4],[1,5]]
Output: [1,4]
"""


class UnionFind:
    def __init__(self, n):
        self.parent = list(range(n + 1)) #方便使用下标作为元素编号

    def find(self, x):
        if self.parent[x] != x:
            self.parent[x] = self.find(self.parent[x])
        return self.parent[x]

    def union(self, x, y):
        rootX, rootY = self.find(x), self.find(y)
        if rootX == rootY:
            return False  # 成环
        self.parent[rootX] = rootY
        return True


class Solution:
    def findRedundantConnection(self, edges):
        uf = UnionFind(len(edges))
        for u, v in edges:
            if not uf.union(u, v):
                return [u, v]


s=Solution()
print(s.findRedundantConnection([[1,2],[2,3],[3,4],[1,4],[1,5]]))

"""
题目要求
给定一个学生编号范围为 0 到 n-1 的学生集合和多个学生组，每个组包含若干个学生。
初始时，学生编号为 0 的学生被认定为嫌疑人。如果某个学生是嫌疑人，那么该学生所在组的所有成员都会成为嫌疑人。
你的任务是找出所有的嫌疑人数量。

输入
每个测试案例的第一行包含两个整数 n 和 m，分别表示学生的数量和组的数量。若 n = 0 且 m = 0，表示输入结束，不需要处理。
接下来的 m 行，每行表示一个组的信息：
每行以整数 k 开头，表示该组包含 k 个成员，后跟 k 个整数表示该组的成员编号。

输出
对于每个测试案例，输出一个整数，表示嫌疑人的数量。

约束
0 < n <= 30000
0 <= m <= 500
每个学生的编号在 0 到 n-1 之间，且每个学生最多出现在多个组中。

示例输入
100 4
2 1 2
5 10 13 11 12 14
2 0 1
2 99 2
200 2
1 5
5 1 2 3 4 5
1 0
0 0

示例输出
4
1
1
"""

"""
将每个学生看作一个节点，每个组表示若干学生的联合。
通过并查集，将同一组的学生归为同一个集合
"""

class UnionFind:
    def __init__(self, n):
        # 初始化，每个节点自己是自己的根
        self.parent = list(range(n))  # parent[i] = i
        self.size = [1] * n  # size[i] 表示以 i 为根的集合大小

    def find(self, x):
        # 如果节点不是指向自身，比如 2 → 1 → 0（0 是根），find(2) → 把 parent[2] 直接改成 0
        if self.parent[x] != x:
            self.parent[x] = self.find(self.parent[x])  # 路径压缩
        return self.parent[x]

    def union(self, x, y):
        fx, fy = self.find(x), self.find(y)
        if fx != fy:
            self.parent[fy] = fx
            self.size[fx] += self.size[fy]  # 合并集合时更新大小

    def get_size(self, x):
        return self.size[self.find(x)]

while True:
    n, m = map(int, input().split())
    if n == 0 and m == 0:
        break

    uf = UnionFind(n)

    for _ in range(m):
        group = list(map(int, input().split()))
        k = group[0]
        members = group[1:]
        for i in range(1, k):
            uf.union(members[0], members[i])  # 将组内所有人并入同一集合

    print(uf.get_size(0))  # 输出和0号学生在同一集合中的人数，即嫌疑人数

class UnionFind:
    def __init__(self, n):
        # 初始化，每个节点自己是自己的根
        self.parent = list(range(n))  # parent[i] = i
        self.size = [1] * n  # size[i] 表示以 i 为根的集合大小

    def find(self, x):
        # 如果节点不是指向自身，比如 2 → 1 → 0（0 是根），find(2) → 把 parent[2] 直接改成 0
        if self.parent[x] != x:
            self.parent[x] = self.find(self.parent[x])  # 路径压缩
        return self.parent[x]

    def union(self, x, y):
        # 合并 x 和 y 所在的集合
        root_x = self.find(x)
        root_y = self.find(y)
        if root_x == root_y:
            return  # 已经在一个集合里，无需再合并

        # 把小树挂到大树下面（按大小合并）
        if self.size[root_x] < self.size[root_y]:
            self.parent[root_x] = root_y
            self.size[root_y] += self.size[root_x]
        else:
            self.parent[root_y] = root_x
            self.size[root_x] += self.size[root_y]

    def connected(self, x, y):
        # 判断 x 和 y 是否在同一集合
        return self.find(x) == self.find(y)

"""
题目描述
初始时 n 位同学各自成一列。每次操作给出 "x y"，若 x 和 y 不在同一队列，将 x 所在队列接到 y 所在队列的末尾（x 队首接在 y 队尾之后）。最终对每个同学，输出其所在队列的队首。

输入
T 组数据。
每组：先是n, m（n个同学，m次操作）， 再是m 对 x, y。

输出
每组输出 n 个整数，依次为每位同学的队首。
"""
"""
样例输入
2
4 2
1 2
3 4
5 4
1 2
2 3
4 5
1 3
样例输出
2 2 4 4
3 3 3 5 5
"""
class UnionFind:
    def __init__(self, n):
        self.parent = list(range(n + 1))

    def find(self, x):
        if self.parent[x] != x:
            self.parent[x] = self.find(self.parent[x])  # 路径压缩
        return self.parent[x]

    def union(self, x, y):
        rootX = self.find(x)
        rootY = self.find(y)
        if rootX != rootY:
            self.parent[rootX] = rootY  # 把x集合并到y集合


T = int(input())
for _ in range(T):
    n,m = map(int,input().split())
    u = UnionFind(n+1)
    result = []
    for i in range(m):
        x,y= map(int,input().split())
        u.union(x,y)
    for j in range(1,n+1):
        result.append(u.find(j))
    print(" ".join(map(str,result)))

"""
判断是否存在一种变量的赋值，使得所有的等式与不等式成立

Example 1:
Input: equations = ["a==b","b!=a"]
Output: false

Example 2:
Input: equations = ["b==a","a==b"]
Output: true
"""


class UnionFind:
    def __init__(self):
        self.parent = {chr(i): chr(i) for i in range(ord('a'), ord('z') + 1)}

    def find(self, x):
        if self.parent[x] != x:
            self.parent[x] = self.find(self.parent[x])
        return self.parent[x]

    def union(self, x, y):
        self.parent[self.find(x)] = self.find(y)


class Solution:
    def equationsPossible(self, equations):
        uf = UnionFind()

        # 先处理等式
        for eq in equations:
            if eq[1:3] == '==':
                uf.union(eq[0], eq[3])

        # 再处理不等式
        for eq in equations:
            if eq[1:3] == '!=':
                if uf.find(eq[0]) == uf.find(eq[3]):
                    return False
        return True

"""
给定 n 个大写字母（前 n 个字母，如 n=4 则为 A-D）和 m 个形如 "A<B" 的不等式关系，按顺序处理每个关系，判断是否出现以下三种情况之一（按优先顺序）：
提前确定唯一排序：处理到第 k 个关系时，所有字母的顺序已唯一确定，且满足所有已处理的关系。
发现矛盾：处理到第 k 个关系时，当前关系与已处理的关系形成环（如 A<B 且 B<A），导致无法排序。
处理完所有关系仍无法确定：处理完所有 m 个关系后，既无矛盾也未确定唯一排序。

输入
多组数据，每组第一行 n 和 m（n=0 且 m=0 时结束）。
随后 m 行，每行一个形如 "A<B" 的关系，按处理顺序给出。

输出
每组数据输出一行，根据三种情况分别输出：
确定排序：Sorted sequence determined after k relations: 序列.
发现矛盾：Inconsistency found after k relations.
无法确定：Sorted sequence cannot be determined.

样例输入
4 6
A<B
A<C
B<C
C<D
B<D
A<B
3 2
A<B
B<A
26 1
A<Z
0 0
样例输出
Sorted sequence determined after 4 relations: ABCD.
Inconsistency found after 2 relations.
Sorted sequence cannot be determined.
"""
from collections import deque


def topological_sort(n, graph, in_degree):
    q = deque()#存下标
    temp_in = in_degree[:]
    result = ''
    for i in range(n):
        if temp_in[i] == 0:
            q.append(i)
    multiple_choices = False

    while q:
        if len(q) > 1:
            multiple_choices = True  # 多种可能
        u = q.popleft()
        result += chr(ord('A') + u)#下标0就会被转为A，2转为B……
        for v in graph[u]:
            temp_in[v] -= 1
            if temp_in[v] == 0:
                q.append(v)

    if len(result) < n:
        return "INCONSISTENT", ''
    elif multiple_choices:
        return "UNCERTAIN", ''
    else:
        return "DETERMINED", result


def main():
    while True:
        line = input()
        if not line:
            continue
        n, m = map(int, line.split())
        if n == 0 and m == 0:
            break

        graph = [[] for _ in range(n)]
        in_degree = [0] * n

        for i in range(m):
            relation = input().strip()
            a = ord(relation[0]) - ord('A') #a<b变为a指向b
            b = ord(relation[2]) - ord('A')
            graph[a].append(b)
            in_degree[b] += 1

            status, seq = topological_sort(n, graph, in_degree)
            if status == "INCONSISTENT":
                print(f"Inconsistency found after {i + 1} relations.")
                # 丢弃剩余输入
                for _ in range(i + 1, m):
                    input()
                break
            elif status == "DETERMINED":
                print(f"Sorted sequence determined after {i + 1} relations: {seq}.")
                # 丢弃剩余输入
                for _ in range(i + 1, m):
                    input()
                break
        else:
            print("Sorted sequence cannot be determined.")


if __name__ == "__main__":
    main()

"""
现在有n个队伍参加了比赛，他们进行了m次PK。现在赛事方需要给他们颁奖（奖金为整数），已知参加比赛就可获得100元，获胜方的奖金一定要比败方奖金高。
请问赛事方要准备的最小奖金为多少？奖金数额一定是整数。

输入
一组数据，第一行是两个整数n(1≤n≤1000)和m(0≤m≤2000)，分别代表n个队伍和m次pk，队伍编号从0到n-1。接下来m行是pk信息，具体信息a，b，代表编号为a的队伍打败了编号为b的队伍。
输入保证队伍之间的pk战胜关系不会形成有向环
输出
给出最小奖金w
样例输入
5 6
1 0
2 0
3 0
4 1
4 2
4 3
样例输出
505
"""
from collections import defaultdict, deque

n, m = map(int, input().split())

# 邻接表表示图：g[a] 存储所有 a 指向的节点
g = defaultdict(list)
in_deg = [0] * n  # 记录每个节点的入度

for _ in range(m):
    a, b = map(int, input().split())
    g[b].append(a)  # 从败者指向胜者，b -> a
    in_deg[a] += 1

# 拓扑排序 + 动态规划求最小奖金
q = deque()
dist = [100] * n  # 初始每人至少100元

# 所有入度为0的节点入队
for i in range(n):
    if in_deg[i] == 0:
        q.append(i)

while q:
    u = q.popleft()
    for v in g[u]:
        # 奖金递推：v 要比 u 多至少 1 元
        if dist[v] < dist[u] + 1:
            dist[v] = dist[u] + 1
        in_deg[v] -= 1
        if in_deg[v] == 0:
            q.append(v)

print(sum(dist))

"""
在火星上要建造 n 个科考站，有 m 条依赖关系，表示科考站 b 需要等科考站 a 完工后，并等待 c 单位时间（维修保养）后才能开建。建站时间忽略不计。
请你求出：
所有科考站最早全部建成所需的最短时间
在该最短时间下，有哪些关键任务，它的开始时间和结束时间不能再推迟,否则就会影响项目的最短完成时间

输入
第一行两个整数n,m，表示有n个科考站，m个维修保养任务。科考站编号为1，2.....n
接下来m行，每行三个整数a b c，表示一个维修保养任务
1 < n,m <=3000
输出格式：
第一行：最短时间
接下来每行输出一个关键任务对 a b，按字典序升序排列。

样例输入
9 11
1 2 6
1 3 4
1 4 5
2 5 1
3 5 1
4 6 2
5 7 9
5 8 7
6 8 4
7 9 2
8 9 4
样例输出
18
1 2
2 5
5 7
5 8
7 9
8 9
"""
from collections import defaultdict, deque

n, m = map(int, input().split())
edges = []
graph = [[] for _ in range(n + 1)]
in_deg = [0] * (n + 1)
out_graph = [[] for _ in range(n + 1)]  # 反图

for _ in range(m):
    a, b, c = map(int, input().split())
    edges.append((a, b, c))
    graph[a].append((b, c))
    in_deg[b] += 1
    out_graph[b].append((a, c))  # 用于反向图处理 vl

# 1. 拓扑排序求 ve（最早开始时间）
ve = [0] * (n + 1)
q = deque()
topo_order = []

for i in range(1, n + 1):
    if in_deg[i] == 0:
        q.append(i)

while q:
    u = q.popleft()
    topo_order.append(u)
    for v, w in graph[u]:
        if ve[v] < ve[u] + w:
            ve[v] = ve[u] + w
        in_deg[v] -= 1
        if in_deg[v] == 0:
            q.append(v)

total_time = max(ve) #取所有 ve[i] 中的最大值，即是整个项目最短完成时间

# 2. 逆拓扑求 vl（最晚开始时间）
vl = [total_time] * (n + 1)
for u in reversed(topo_order): #从最后拓扑序开始（从后往前），更新最晚时间：
    for v, w in graph[u]:
        if vl[u] > vl[v] - w:
            vl[u] = vl[v] - w #u最晚必须在 vl[v] - w 时间点完成

# 3. 找关键边:它的开始时间和结束时间不能再推迟,否则就会影响项目的最短完成时间
critical_tasks = []
for a, b, c in edges:
    if ve[a] == vl[b] - c:
        critical_tasks.append((a, b))

# 4. 输出
print(total_time)
for a, b in sorted(critical_tasks):
    print(f"{a} {b}")

"""
给定一个有向图，表示每个节点与其“子节点”的关系。编号为 1 到 N 的 N 个节点中，第 i 行提供第 i 个节点的所有子节点编号（以 0 结尾，可能为空）。
请输出一个节点序列，使得每个节点都排在其所有子节点之前。

可以有多种合法顺序，任意输出一种即可。保证输入图无环，且至少存在一种合法顺序。

样例输入
5
0
4 5 1 0
1 0
5 3 0
3 0
样例输出
2 4 5 3 1
"""
"""
经典方法：入度法 + 队列（Kahn 算法）
1.建图并统计每个节点的入度
2.找出所有入度为 0 的点加入队列（可以先发言）
3.不断从队列中取出节点输出，并将其指向的孩子入度减 1，如果为 0，加入队列
4.重复直到所有点都处理完
"""
from collections import deque

N = int(input())
graph = [[] for _ in range(N + 1)]
in_degree = [0] * (N + 1)

# 建图 & 统计入度
for i in range(1, N + 1):
    data = list(map(int, input().split()))
    for child in data[:-1]:  # 去掉最后的 0
        graph[i].append(child)
        in_degree[child] += 1

# 拓扑排序
q = deque()
for i in range(1, N + 1):
    if in_degree[i] == 0:
        q.append(i)

res = []
while q:
    u = q.popleft()
    res.append(u)
    for v in graph[u]:
        in_degree[v] -= 1
        if in_degree[v] == 0:
            q.append(v)

print(' '.join(map(str, res)))

"""
给定 N 个课程和这些课程的前置必修课，求可以一次性上完所有课的顺序
输入是一个正整数，表示课程数量，和一个二维矩阵，表示所有的有向边，例如 [1,0] 表示上课程 1 之前必须先上课程 0。
请你判断是否可能完成所有课程的学习？如果可以，返回 true ；否则，返回 false

示例 1：
输入：numCourses = 2, prerequisites = [[1,0]]
输出：true
解释：总共有 2 门课程。学习课程 1 之前，你需要完成课程 0 。这是可能的。

示例 2：
输入：numCourses = 2, prerequisites = [[1,0],[0,1]]
输出：false
解释：总共有 2 门课程。学习课程 1 之前，你需要先完成​课程 0 ；并且学习课程 0 之前，你还应先完成课程 1 。这是不可能的。
"""
import collections

class Solution:
    def findOrder(self, numCourses, prerequisites):
        # 存储有向图
        edges = collections.defaultdict(list)
        # 存储每个节点的入度
        indeg = [0] * numCourses
        visited= [False] * numCourses

        for info in prerequisites:
            edges[info[1]].append(info[0]) #先修课：[后续课1，后续课2……]
            indeg[info[0]] += 1

        # 将所有入度为 0 的节点放入队列中
        q = collections.deque([u for u in range(numCourses) if indeg[u] == 0])

        while q:
            # 从队首取出一个节点
            u = q.popleft()
            visited[u]=True
            for v in edges[u]:
                indeg[v] -= 1
                # 如果相邻节点 v 的入度为 0，就可以选 v 对应的课程了
                if indeg[v] == 0:
                    q.append(v)

        if all(visited):
            return True
        return False
s=Solution()
print(s.findOrder(2,[[1,0],[0,1]]))

"""
给定 N 个课程和这些课程的前置必修课，求可以一次性上完所有课的顺序
输入是一个正整数，表示课程数量，和一个二维矩阵，表示所有的有向边，例如 [1,0] 表示上课程 1 之前必须先上课程 0。
输出是一个一维数组，表示拓扑排序结果。

输入：numCourses = 4, prerequisites = [[1,0],[2,0],[3,1],[3,2]]
输出：[0,2,1,3]
解释：总共有 4 门课程。要学习课程 3，你应该先完成课程 1 和课程 2。并且课程 1 和课程 2 都应该排在课程 0 之后。因此，一个正确的课程顺序是 [0,1,2,3] 。另一个正确的排序是 [0,2,1,3] 。
"""
"""
拓扑排序的主要思路就是：考虑每一个节点的入度，当节点入度为 0 时，将其加入排序序列，同时将其指向的其他节点的入度减 1，所有节点完成遍历之后得到最终拓扑排序。
广度优先搜索
"""
import collections

class Solution:
    def findOrder(self, numCourses, prerequisites):
        # 存储有向图
        edges = collections.defaultdict(list)
        # 存储每个节点的入度
        indeg = [0] * numCourses
        # 存储答案
        result = list()

        for info in prerequisites:
            edges[info[1]].append(info[0]) #先修课：[后续课1，后续课2……]
            indeg[info[0]] += 1

        # 将所有入度为 0 的节点放入队列中
        q = collections.deque([u for u in range(numCourses) if indeg[u] == 0])

        while q:
            # 从队首取出一个节点
            u = q.popleft()
            # 放入答案中
            result.append(u)
            for v in edges[u]:
                indeg[v] -= 1
                # 如果相邻节点 v 的入度为 0，就可以选 v 对应的课程了
                if indeg[v] == 0:
                    q.append(v)

        if len(result) != numCourses:
            result = list()
        return result

"""
给定一个由大写字母前 n 个字母表示的 n 个节点的连通无向图（n≤26），每条边有一个正整数权值。要求删除部分边，使得剩余边构成一棵连通所有节点的树（即生成树），求所有可能的生成树中边权之和的最小值（最小生成树的权值和）。
输入
第一行：节点数 n（n≤26，节点为 A~ 第 n 个大写字母）。
接下来 n-1 行：每行描述一个节点（前 n-1 个字母）的边信息：
每行以节点字母开头，后跟一个整数 k（k≥0），表示该节点与后续字母节点（即字母序比它大的节点）的边数。
若 k>0，随后有 k 对数据，每对为目标节点字母和边权。

输出
一个整数，即最小生成树的边权总和。

样例输入
9
A 2 B 12 I 25
B 3 C 10 H 40 I 8
C 2 D 18 G 55
D 1 E 44
E 2 F 60 G 38
F 0
G 1 H 35
H 1 I 35
样例输出
216
"""
class UnionFind:
    def __init__(self, n):
        self.parent = list(range(n))

    def find(self, x):
        while self.parent[x] != x:
            self.parent[x] = self.parent[self.parent[x]]  # 路径压缩
            x = self.parent[x]
        return x

    def union(self, x, y):
        rx, ry = self.find(x), self.find(y)
        if rx == ry:
            return False
        self.parent[ry] = rx
        return True

n=int(input())
edges =[]
for _ in range(n-1):
    line = input().split()
    u = ord(line[0])-ord("A")
    adj_num = int(line[1])
    for i in range(2,adj_num*2+1,2):
        v = ord(line[i])-ord("A")
        w = int(line[1+i])
        edges.append((w, u, v))
edges.sort()  # 按权值升序排序，


uf = UnionFind(n)
mst_cost = 0
for w, u, v in edges:
    if uf.union(u, v):
        mst_cost += w

print(mst_cost)#最小生成树的边权

"""
给定一个无向连通图，图中节点表示农场，边权表示两农场间连接所需光纤长度。求用最少光纤将所有农场连通的总长度（即找到图的最小生成树，计算其边权和）

输入说明：
输入包括几个案例。对于每个案例，第一行：整数 N（3 ≤ N ≤ 100），表示农场数量。接下来 N 行：每行包含 N 个整数，构成 N×N 的邻接矩阵。第 i 行第 j 列的整数表示农场 i 与农场 j 之间的光纤长度。

输出说明：
对每个测试用例，输出一个整数，表示连接所有农场所需的最小光纤总长度（即最小生成树的边权和）。

样例输入
4
0 4 9 21
4 0 8 17
9 8 0 16
21 17 16 0
样例输出
28
"""
class DisjointSetUnion:
    def __init__(self, n):
        self.n = n
        self.rank = [1] * n #rank记录每个节点作为根节点时树的高度。在合并操作中，将秩较小的树合并到秩较大的树上，这样可以保证新树的高度不会超过原来两棵树的高度，从而优化查找效率。
        self.f = list(range(n))

    def find(self, x: int) -> int:
        if self.f[x] == x:
            return x
        self.f[x] = self.find(self.f[x])
        return self.f[x]

    def unionSet(self, x: int, y: int) -> bool:
        fx, fy = self.find(x), self.find(y)
        if fx == fy:
            return False

        if self.rank[fx] < self.rank[fy]:
            fx, fy = fy, fx # 确保 fx 的秩大于等于 fy 的秩

        self.rank[fx] += self.rank[fy]  # 将 fy 的秩加到 fx 上
        self.f[fy] = fx  # 将 fy 的父节点设为 fx
        return True


class Solution:
    def minCostConnectPoints(self, dist):

        n = len(dist)
        dsu = DisjointSetUnion(n)
        edges = list()

        for i in range(n):
            for j in range(i + 1, n):
                edges.append((dist[i][j], i, j))

        edges.sort()

        ret, num = 0, 1
        for length, x, y in edges:
            if dsu.unionSet(x, y):
                ret += length
                num += 1
                if num == n: #所有点都连上了
                    break

        return ret
while True:
    try:
        n=int(input())
        dist=[]
        for _ in range(n):
            dist.append(list(map(int,input().split())))
        s=Solution()
        print(s.minCostConnectPoints(dist))
    except EOFError:
        break

class UnionFind:
    def __init__(self, n):
        self.parent = list(range(n))

    def find(self, x):
        while self.parent[x] != x:
            self.parent[x] = self.parent[self.parent[x]]  # 路径压缩
            x = self.parent[x]
        return x

    def union(self, x, y):
        rx, ry = self.find(x), self.find(y)
        if rx == ry:
            return False
        self.parent[ry] = rx
        return True


n, m = map(int, input().split())
edges = []
total_cost = 0

for _ in range(m):
    u, v, w = map(int, input().split())
    edges.append((w, u, v))
    total_cost += w

edges.sort()  # 按权值升序排序，构建最小生成树

uf = UnionFind(n)
mst_cost = 0
for w, u, v in edges:
    if uf.union(u, v):
        mst_cost += w

# 答案是总边权减去最小生成树的边权
print(total_cost - mst_cost)

"""
题目描述：
给定一个连通无向图，图中有 n 个节点和 m 条边，每条边有一个权值。你每次可以选择一个环并破坏环上的一条边，重复进行直到图中无环（即成为一棵树）。
请你求出，在保证图仍连通的前提下，最多可以破坏掉的边权之和。

输入格式：
第一行：两个整数 n 和 m（1 ≤ n < 100000, 1 ≤ m < 100000）——表示节点数和边数。

接下来 m 行，每行三个整数 u、v 和 w（|w| < 1,000,000,000），表示一条连接 u 和 v 的无向边，权值为 w。

输出格式：
一行一个整数，表示最多可以破坏的边权之和。

限制：
时间限制：1000 ms
内存限制：65536 kB
"""
import sys
import heapq

n, m = map(int, sys.stdin.readline().split())
total = 0
graph = [[] for _ in range(n)]

for _ in range(m):
    u, v, w = map(int, sys.stdin.readline().split())
    total += w
    graph[u].append((v, w))
    graph[v].append((u, w))

in_mst = [False] * n
min_heap = [(0, 0)]  # (边权重, 节点编号)
mst_weight = 0

while min_heap:
    w, u = heapq.heappop(min_heap)
    if in_mst[u]:
        continue
    in_mst[u] = True
    mst_weight += w
    for v, weight in graph[u]:
        if not in_mst[v]:
            heapq.heappush(min_heap, (weight, v))

print(total - mst_weight)

"""
给你一个points 数组，表示 2D 平面上的一些点，其中 points[i] = [xi, yi] 。
连接点 [xi, yi] 和点 [xj, yj] 的费用为它们之间的 曼哈顿距离 ：|xi - xj| + |yi - yj| ，其中 |val| 表示 val 的绝对值。
请你返回将所有点连接的最小总费用。只有任意两点之间 有且仅有 一条简单路径时，才认为所有点都已连接。

输入：points = [[0,0],[2,2],[3,10],[5,2],[7,0]]
输出：20
"""
"""
Kruskal 算法:
1.将图 G={V,E}中的所有边按照长度由小到大进行排序，等长的边可以按任意顺序。
2.初始化图 ”为 {V,∅}，从前向后扫描排序后的边，如果扫描到的边 e在 ”中连接了两个相异的连通块,则将它插入 G’中。
3.最后得到的图 G'就是图 G 的最小生成树
"""

class DisjointSetUnion:
    def __init__(self, n):
        self.n = n
        self.rank = [1] * n #rank记录每个节点作为根节点时树的高度。在合并操作中，将秩较小的树合并到秩较大的树上，这样可以保证新树的高度不会超过原来两棵树的高度，从而优化查找效率。
        self.f = list(range(n))

    def find(self, x: int) -> int:
        if self.f[x] == x:
            return x
        self.f[x] = self.find(self.f[x])
        return self.f[x]

    def unionSet(self, x: int, y: int) -> bool:
        fx, fy = self.find(x), self.find(y)
        if fx == fy:
            return False

        if self.rank[fx] < self.rank[fy]:
            fx, fy = fy, fx # 确保 fx 的秩大于等于 fy 的秩

        self.rank[fx] += self.rank[fy]  # 将 fy 的秩加到 fx 上
        self.f[fy] = fx  # 将 fy 的父节点设为 fx
        return True


class Solution:
    def minCostConnectPoints(self, points):
        dist = lambda x, y: abs(points[x][0] - points[y][0]) + abs(points[x][1] - points[y][1])

        n = len(points)
        dsu = DisjointSetUnion(n)
        edges = list()

        for i in range(n):
            for j in range(i + 1, n):
                edges.append((dist(i, j), i, j))

        edges.sort()

        ret, num = 0, 1
        for length, x, y in edges:
            if dsu.unionSet(x, y):
                ret += length
                num += 1
                if num == n: #所有点都连上了
                    break

        return ret

"""
问题描述：
有 n 个人（0 < n < 100）起初互不认识，给定 m 对可安排见面的人（0 < m < 5000）及每对见面的社交成本（花费 w，0 <= w < 100000 且每对花费不同 ），部分人之间不能见面。认识具有传递性，求使所有人相互认识的最小花销及对应的见面组合（按花费升序输出，编号小的在前 ），若无法实现则输出 "NOT CONNECTED" 。

输入：
第一行 n 和 m，分别为人数和可安排见面的对数。
接下来 m 行，每行 s、e、w，表示安排编号 s 和 e 的人见面需花费 w 元 。

输出：
能实现时，第一行输出最小花销（保留 2 位小数），后续行按花费升序输出见面组合；不能实现则输出 "NOT CONNECTED" 。

样例输入
5 9
0 1 10.0
0 3 7.0
0 4 25.0
1 2 8.0
1 3 9.0
1 4 35.0
2 3 11.0
2 4 50.0
3 4 24.0
样例输出
48.00
0 3
1 2
1 3
3 4
"""
import sys

# 并查集数据结构
class DisjointSet:
    def __init__(self, n):
        self.parent = list(range(n))
        self.num_sets = n # 记录当前连通分量的数量

    def find(self, i):
        if self.parent[i] == i:
            return i
        self.parent[i] = self.find(self.parent[i]) # 路径压缩
        return self.parent[i]

    def union(self, i, j):#不在一起return True 已在一个return false
        root_i = self.find(i)
        root_j = self.find(j)
        if root_i != root_j:
            self.parent[root_i] = root_j # 将root_i连接到root_j
            self.num_sets -= 1 # 连通分量数量减1
            return True
        return False

def solve():
    n, m = map(int, sys.stdin.readline().split())

    edges = []
    for _ in range(m):
        s, e, w = sys.stdin.readline().split()
        s, e = int(s), int(e)
        w = float(w)
        edges.append((w, s, e))

    # 1. 将所有边按权重从小到大排序
    edges.sort()

    dsu = DisjointSet(n)
    total_cost = 0.0
    mst_edges = []
    edges_count = 0 # 记录MST中边的数量

    # 2. 遍历排序后的边
    for w, u, v in edges:
        # 检查u和v是否已经在同一个连通分量中
        if dsu.union(u, v):
            # 如果不在，则加入MST
            total_cost += w
            mst_edges.append((min(u, v), max(u, v))) # 确保小编号在前
            edges_count += 1
            if edges_count == n - 1: # 如果已经连接了所有N-1条边，则完成MST
                break

    # 3. 检查是否所有人都连通
    # 如果n=1，则默认是连通的，不需要任何边
    if n == 1:
        print("0.00")
        return

    # 对于n>1的情况，需要edges_count == n - 1 才能完全连通 因为for w, u, v in edges中遍历完了也会结束这一part，但有可能还没完全连通
    # 或者检查dsu.num_sets == 1 （所有节点在一个集合中）
    if dsu.num_sets == 1:
        print(f"{total_cost:.2f}")
        for s, e in mst_edges:
            print(f"{s} {e}")
    else:
        print("NOT CONNECTED")

# 处理多组测试数据 (题目只说了一组，但写成函数可以方便扩展)
# 如果题目有多组测试用例，通常第一行会有一个T，表示测试用例的数量
# For this specific problem, there is no T, so we just call solve() once.
solve()

"""
给定两个壶：
    壶 1 容量为 A 升
    壶 2 容量为 B 升
    你可以执行以下操作：
    FILL(i): 把壶 i 填满
    DROP(i): 把壶 i 倒空
    POUR(i,j): 从壶 i 倒水到壶 j，直到壶 j 满(超过j的留在i中）或壶 i 空
目标：
让两个壶中之一恰好有 C 升水，并输出最短操作序列

输入：
在第一行和唯一一行中是数字 A、B 和 C。这些都是在 1 到 100 范围内的整数，且 C≤max(A,B)。
输出：
输出第一行必须包含操作序列的长度 K。接下来的 K 行必须各自描述一个操作。如果有多个最小长度的序列，可以输出其中任意一个。如果无法实现所需的结果，文件的第一行和唯一一行必须包含单词‘impossible’

样例输入
3 5 4
样例输出
6
FILL(2)
POUR(2,1)
DROP(1)
POUR(2,1)
FILL(2)
POUR(2,1)
"""
"""
广度优先搜索
把每种壶内水量的状态看作是图中的一个节点，每次操作（倒水、装满、倒空）就是节点间的一条边。寻找从初始状态 (0, 0) 到目标状态（任一壶中为 C）的最短路径
"""
# 定义操作类型及其对应的字符串表示
path = [
    "FILL(1)",
    "FILL(2)",
    "DROP(1)",
    "DROP(2)",
    "POUR(1,2)",
    "POUR(2,1)"
]


def main():
    # 读取输入
    a, b, c = map(int, input().split())

    # 初始化访问标记数组
    visited = [[False for _ in range(b + 1)] for _ in range(a + 1)]

    # BFS队列元素：(a, b, level当前操作步数（路径长度）, path操作路径（记录操作编号的列表）)
    queue = deque()
    queue.append((0, 0, 0, []))
    visited[0][0] = True

    while queue:
        current_a, current_b, level, current_path = queue.popleft()

        # 检查是否达到目标状态
        if current_a == c or current_b == c:
            print(level)
            for op in current_path:
                print(path[op])
            return

        # 生成所有可能的操作
        # 操作1: FILL(1)
        if current_a < a:# 如果壶 1 没满，就灌满它。
            new_a = a
            new_b = current_b
            if not visited[new_a][new_b]:
                visited[new_a][new_b] = True
                queue.append((new_a, new_b, level + 1, current_path + [0]))

        # 操作2: FILL(2)
        if current_b < b: # 如果壶 2 没满，就灌满它。
            new_a = current_a
            new_b = b
            if not visited[new_a][new_b]:
                visited[new_a][new_b] = True
                queue.append((new_a, new_b, level + 1, current_path + [1]))

        # 操作3: DROP(1)
        if current_a > 0:# 如果壶 1 不空，就倒空它。
            new_a = 0
            new_b = current_b
            if not visited[new_a][new_b]:
                visited[new_a][new_b] = True
                queue.append((new_a, new_b, level + 1, current_path + [2]))

        # 操作4: DROP(2)
        if current_b > 0:# 如果壶 2 不空，就倒空它。
            new_a = current_a
            new_b = 0
            if not visited[new_a][new_b]:
                visited[new_a][new_b] = True
                queue.append((new_a, new_b, level + 1, current_path + [3]))

        # 操作5: POUR(1,2)
        if current_a > 0 and current_b < b:
            pour_amount = min(current_a, b - current_b)
            new_a = current_a - pour_amount
            new_b = current_b + pour_amount
            if not visited[new_a][new_b]:
                visited[new_a][new_b] = True
                queue.append((new_a, new_b, level + 1, current_path + [4]))

        # 操作6: POUR(2,1)
        if current_b > 0 and current_a < a:
            pour_amount = min(current_b, a - current_a)
            new_a = current_a + pour_amount
            new_b = current_b - pour_amount
            if not visited[new_a][new_b]:
                visited[new_a][new_b] = True
                queue.append((new_a, new_b, level + 1, current_path + [5]))

    # 无解情况
    print("impossible")


if __name__ == "__main__":
    main()

"""
在二维平面中，从起点（家）到终点（学校），可以步行或乘坐地铁（多条线路，每站可上下车、换乘）。步行速度为 10 km/h（即约 166.67 米 / 分钟），地铁速度为 40 km/h（即约 666.67 米 / 分钟）。求从起点到终点的最短时间（分钟，四舍五入）

输入：
输入由您家和学校的 x,y 坐标组成，后跟多条地铁线路的规格。每条地铁线路由该线路每个站点的非负整数 x,y 坐标按顺序组成。您可假设地铁在相邻站点之间直线运行，坐标表示米数的整数。每条线路至少有两个站点。每条地铁线路的末尾跟随着虚拟坐标对-1,-1。城市中总共最多有 200 个地铁站。
输出：
您到达学校所需的时间（四舍五入到最接近的分钟），采用最快的路线。

样例输入
0 0 10000 1000
0 200 5000 200 7000 200 -1 -1
2000 600 5000 600 10000 600 -1 -1
样例输出
21
"""
import math
import heapq
#读取输入和地铁线路
home_x, home_y, school_x, school_y = map(int, input().split())
subway_lines = []
while True:
    try:
        line = list(map(int, input().split()))
        stops = []
        for i in range(0, len(line), 2):
            x, y = line[i], line[i+1]
            if x == -1 and y == -1:
                break
            stops.append((x, y))
        if stops:
            subway_lines.append(stops) #每条地铁线路被解析成一个坐标列表，加入 subway_lines
    except EOFError:
        break
#构建点集与索引映射，方便后续建图。
subway_stops = []
for line in subway_lines:
    subway_stops.extend(line) #一个列表保存所有站点
all_stops = [(home_x, home_y), (school_x, school_y)] + subway_stops
stop_indices = {stop: idx for idx, stop in enumerate(all_stops)} #站点坐标：索引
num_stops = len(all_stops)
#初始化邻接表和速度常量
adj = [[] for _ in range(num_stops)]
walk_speed = 10000 / 60 #单位：m/min
subway_speed = 40000 / 60
#添加所有点之间的走路边
for i in range(num_stops):
    for j in range(i + 1, num_stops):
        x1, y1 = all_stops[i]
        x2, y2 = all_stops[j]
        distance = math.sqrt((x2-x1)**2 + (y2-y1)**2)
        time = distance / walk_speed
        adj[i].append((j, time))
        adj[j].append((i, time))
# 添加地铁边
for line in subway_lines:
    for i in range(len(line) - 1):
        stop1 = line[i]
        stop2 = line[i+1]
        idx1 = stop_indices[stop1]
        idx2 = stop_indices[stop2]
        x1, y1 = stop1
        x2, y2 = stop2
        distance = math.sqrt((x2 - x1)**2 + (y2 - y1)**2)
        time = distance / subway_speed
        adj[idx1].append((idx2, time))
        adj[idx2].append((idx1, time))
#Dijkstra 最短路径算法
home_idx = stop_indices[(home_x, home_y)]
school_idx = stop_indices[(school_x, school_y)]
min_time = [float('inf')] * num_stops
min_time[home_idx] = 0
heap = []
heapq.heappush(heap, (0, home_idx))
while heap:
    current_time, u = heapq.heappop(heap)
    if u == school_idx:
        break
    if current_time > min_time[u]:
        continue
    for v, time in adj[u]:
        if min_time[v] > current_time + time:
            min_time[v] = current_time + time
            heapq.heappush(heap, (min_time[v], v))
total_time = min_time[school_idx]
print(round(total_time))

"""
给定一个无向带权图，节点为地点名称（字符串），边为两地之间的距离（正整数）。
对于每个查询的起点和终点，求从起点到终点的最短路径并按以下格式输出：
    路径中的节点按顺序用 ->(距离)-> 连接。
    若起点与终点相同，直接输出该节点。
输入
1.地点列表：
第一行：整数 P（地点数，P<30）。
接下来 P 行：每行一个字符串，表示地点名称。
2.边列表：
第一行：整数 Q（边数，Q<50）。
接下来 Q 行：每行两个字符串和一个整数，表示两地之间的距离（无向边）。
3.查询列表：
第一行：整数 R（查询数，R<20）。
接下来 R 行：每行两个字符串，表示需要查询最短路径的起点和终点。

样例输入
6
Ginza
Sensouji
Shinjukugyoen
Uenokouen
Yoyogikouen
Meijishinguu
6
Ginza Sensouji 80
Shinjukugyoen Sensouji 40
Ginza Uenokouen 35
Uenokouen Shinjukugyoen 85
Sensouji Meijishinguu 60
Meijishinguu Yoyogikouen 35
2
Uenokouen Yoyogikouen
Meijishinguu Meijishinguu
样例输出
Uenokouen->(35)->Ginza->(80)->Sensouji->(60)->Meijishinguu->(35)->Yoyogikouen
Meijishinguu

"""
import sys
import heapq
from collections import defaultdict

def dijkstra(graph, dist_map, start, end):
    heap = [(0, start, [])]
    visited = set()
    while heap:
        cost, node, path = heapq.heappop(heap)
        if node in visited:
            continue
        visited.add(node)
        new_path = path + [node]
        if node == end:
            return cost, new_path
        for neighbor in graph[node]:
            if neighbor not in visited:
                heapq.heappush(heap, (cost + dist_map[(node, neighbor)], neighbor, new_path))
    return float('inf'), []

# 读入地点
P = int(sys.stdin.readline())
places = [sys.stdin.readline().strip() for _ in range(P)]
place_set = set(places)

# 构建映射
graph = defaultdict(list) #储存每个点的邻居
dist_map = {}

# 读入道路
Q = int(sys.stdin.readline())
for _ in range(Q):
    a, b, d = sys.stdin.readline().split()
    d = int(d)
    graph[a].append(b)
    graph[b].append(a)
    dist_map[(a, b)] = d
    dist_map[(b, a)] = d

# 读入查询
R = int(sys.stdin.readline())
queries = [tuple(sys.stdin.readline().split()) for _ in range(R)]

# 处理每个查询
for start, end in queries:
    if start == end:
        print(start)
        continue
    distance, path = dijkstra(graph, dist_map, start, end)
    output = path[0]
    for i in range(1, len(path)):
        d = dist_map[(path[i-1], path[i])]
        output += f"->({d})->{path[i]}"
    print(output)

"""
有 n 个网络节点，标记为 1 到 n。
给你一个列表 times，表示信号经过 有向 边的传递时间。 times[i] = (ui, vi, wi)，其中 ui 是源节点，vi 是目标节点， wi 是一个信号从源节点传递到目标节点的时间。
现在，从某个节点 K 发出一个信号。需要多久才能使所有节点都收到信号？如果不能使所有节点收到信号，返回 -1 。

输入：times = [[2,1,1],[2,3,1],[3,4,1]], n = 4, k = 2
输出：2
"""
"""
Dijkstra
"""
import heapq
class Solution:
    def networkDelayTime(self, times, n, k):
        g = [[] for _ in range(n)]
        for x, y, time in times:
            g[x - 1].append((y - 1, time))

        dist = [float('inf')] * n
        dist[k - 1] = 0
        q = [(0, k - 1)]
        while q:
            time, x = heapq.heappop(q)
            if dist[x] < time: #跳过已处理过的“旧路径”
                continue #continue跳过当前 while 循环中剩下的代码
            for y, time in g[x]:
                d = dist[x] + time
                if d < dist[y]:
                    dist[y] = d
                    heapq.heappush(q, (d, y))

        ans = max(dist)
        return ans if ans < float('inf') else -1

"""
题目描述：
在一个由股票经纪人组成的网络中，每人只会向自己信任的人传播消息，且每次传播有时间代价。你可以选择一名经纪人作为起点散播谣言，目标是在最短时间内让所有人收到谣言。如果网络中存在无法传播到的人员，则输出 "disjoint"。

输入格式：
多组数据，每组以一个整数 n 开头，表示经纪人数（编号 1 到 n）。
接下来的 n 行，每行以一个整数 k 开头，表示第 i 个经纪人联系的人的数量，后跟 k 对整数，每对为 目标编号 时间，表示将信息传给该人的所需时间。
输入以一行 0 结束。

输出格式：
对于每组数据，输出一行，包含两个整数 x t，表示从第 x 个经纪人开始传谣，能在 t 分钟内让所有人收到消息。
若存在无法到达的经纪人，则输出 "disjoint"。

样例输入
3
2 2 4 3 5
2 1 2 3 6
2 1 2 2 2
5
3 4 4 2 8 5 3
1 5 8
4 1 6 4 10 2 7 5 2
0
2 2 5 1 5
0
样例输出
3 2
3 10
"""
"""
对于每组输入：
    建立一个有向带权图；
    对每个节点（股票经纪人）使用 Dijkstra 算法计算它到所有其他节点的最短路径；
    找出从这个起点出发传播到所有节点所需的最大时间； #从某个起点出发，最慢的那个人多久才能收到谣言？
    最后选择最大时间最小的那个起点作为答案；
    若存在无法传播到的节点（即有节点不可达），就输出 "disjoint"。
"""
import heapq

def dijkstra(graph, start, n):
    dist = [float('inf')] * n
    dist[start] = 0
    heap = [(0, start)]

    while heap:
        d, u = heapq.heappop(heap)
        if d > dist[u]:
            continue
        for v, time in graph[u]: #每次加入u的邻接节点
            if dist[u] + time < dist[v]:
                dist[v] = dist[u] + time
                heapq.heappush(heap, (dist[v], v))
    return dist

while True:
    line = input().strip()
    if line == '0':
        break
    n = int(line)
    graph = [[] for _ in range(n)]
    for i in range(n):
        parts = list(map(int, input().strip().split()))
        k = parts[0]
        for j in range(k):
            to = parts[1 + 2 * j] - 1  # 节点标记调整为从0开始
            time = parts[2 + 2 * j]
            graph[i].append((to, time))
    min_time = float('inf')
    best_person = -1
    for i in range(n):
        dist = dijkstra(graph, i, n)
        if float('inf') in dist: #不能到达所有节点
            continue
        max_dist = max(dist)
        if max_dist < min_time:
            min_time = max_dist
            best_person = i

    if best_person == -1:
        print("disjoint")
    else:
        print(f"{best_person + 1} {min_time}")

"""
皮卡丘要穿越一片森林与小智会合。森林中的隘口构成一个图，节点代表隘口，边代表可通行的双向道路。
皮卡丘从起点 0 出发，小智在终点 1。每个中间隘口（编号为 2 到 N+1）驻守宝可梦，皮卡丘第一次路过时需打败它，耗费固定时间。之后再次经过这个隘口不再耗时。
另外，穿过每条道路也需要一定时间。
请计算：皮卡丘从 0 到 1 的最短时间。

输入：
第1行：N M（N 为中间隘口数量（不含0和1），M 为路径数量）
第2~(N+1)行：每行一个整数，表示隘口打怪耗时（编号从2到N+1）
接下来的 M 行：每行三个数 u v w，表示 u 和 v 之间有一条花费为 w 的双向道路
输出格式：
一行一个整数，表示从皮卡丘位置 0 到小智位置 1 的最短时间。

样例输入
2 5
1
1
0 2 4
3 0 1
2 3 1
2 1 2
1 3 5
样例输出
6
"""
import heapq

n, m = map(int, input().split())
fight_time = [0] * (n + 2)  # 包含点0和1，总共n+2个点
for i in range(2, n + 2):
    fight_time[i] = int(input())

graph = [[] for _ in range(n + 2)]
for _ in range(m):
    u, v, w = map(int, input().split())
    graph[u].append((v, w))
    graph[v].append((u, w))

INF = float('inf')
dist = [INF] * (n + 2)
visited = [False] * (n + 2)

dist[0] = 0
pq = [(0, 0)]  # (当前总时间, 当前点)

while pq:
    cur_time, u = heapq.heappop(pq)
    if visited[u]:
        continue
    visited[u] = True

    for v, w in graph[u]:
        extra = 0
        if v != 1 and not visited[v]:  # 点1不打怪，其它点只在第一次访问时打怪
            extra = fight_time[v]
        if dist[v] > dist[u] + w + extra:
            dist[v] = dist[u] + w + extra
            heapq.heappush(pq, (dist[v], v))

print(dist[1])

"""
描述
给定一个由方块组成的城堡地图，每个方块用数字表示其四周墙壁的存在情况（1 - 西墙，2 - 北墙，4 - 东墙，8 - 南墙，数字为各方向墙的和）。计算城堡中的房间总数和最大房间的方块数。房间定义为相邻（上下左右，无墙分隔）的方块集合。

输入
第一行：南北方向方块数 m（行数）。
第二行：东西方向方块数 n（列数）。
接下来 m 行，每行 n 个整数，表示每个方块的墙壁数字。

输出
第一行：房间总数。
第二行：最大房间的方块数。

样例输入
4
7
11 6 11 6 3 10 6
7 9 6 13 5 15 5
1 10 12 7 13 7 5
13 11 10 8 10 12 13
样例输出
5
9
"""
"""
1 - 西墙,1
2 - 北墙，10
4 - 东墙，100
8 - 南墙,1000
四个墙都有15，1111
"""
from collections import deque

# 读取输入
m = int(input())  # 行数
n = int(input())  # 列数

# 读取每个方块的墙信息
grid = []
for _ in range(m):
    row = list(map(int, input().split()))
    grid.append(row)

# 定义方向：西、北、东、南（对应墙的数字 1, 2, 4, 8）
directions = [
    (0, -1, 1),  # 西：x不变，y减1，墙的数字为1
    (-1, 0, 2),  # 北：x减1，y不变，墙的数字为2
    (0, 1, 4),  # 东：x不变，y加1，墙的数字为4
    (1, 0, 8)  # 南：x加1，y不变，墙的数字为8
]

# 初始化访问数组
visited = [[False for _ in range(n)] for _ in range(m)]


# BFS函数，计算从(x,y)出发的房间大小
def bfs(x, y):
    queue = deque()
    queue.append((x, y))
    visited[x][y] = True
    size = 1

    while queue:
        cx, cy = queue.popleft()
        walls = grid[cx][cy] #walls是此位置的墙总数

        # 尝试四个方向
        for dx, dy, wall_bit in directions:
            nx = cx + dx
            ny = cy + dy

            # 检查是否越界
            if nx < 0 or nx >= m or ny < 0 or ny >= n:
                continue

            # 检查是否有墙（使用位运算）
            if walls & wall_bit: #这个方向有墙 没法走
                continue

            # 检查是否已访问
            if not visited[nx][ny]:
                visited[nx][ny] = True
                size += 1
                queue.append((nx, ny))

    return size


# 主程序：遍历所有方块，统计房间数和最大房间大小
room_count = 0
max_size = 0

for i in range(m):
    for j in range(n):
        if not visited[i][j]:
            room_count += 1
            current_size = bfs(i, j)
            if current_size > max_size:
                max_size = current_size

# 输出结果
print(room_count)
print(max_size)

"""
输入
第一行两个整数n,m，分别表示顶点数和边数。顶点编号从0到n-1。 (1<=n<=110, 1<=m <= 10000)
接下来m行，每行两个整数u和v，表示顶点u和v之间有边。
输出
如果图是连通的，则输出“yes",否则输出“no"。
样例输入
3 2
0 1
0 2
样例输出
yes
"""
def dfs(node, visited, graph):
    visited[node] = True
    for neighbor in graph[node]:
        if not visited[neighbor]:
            dfs(neighbor, visited, graph)

def is_connected(n, edges):
    graph = [[] for _ in range(n)]
    for u, v in edges:
        graph[u].append(v)
        graph[v].append(u)

    visited = [False] * n
    dfs(0, visited, graph)

    return all(visited)  # 如果所有节点都被访问过，则图是连通的

# 示例用法
if __name__ == "__main__":
    n, m = map(int, input().split())
    edges = [tuple(map(int, input().split())) for _ in range(m)]

    if is_connected(n, edges):
        print("connected:yes")
    else:
        print("connected:no")

"""
输入
第一行两个整数n(0 < n <= 110),m( 0 <= m < 10000)，分别表示顶点数和边数。顶点编号从0到n-1。接下来m行，每行两个整数u和v，表示从顶点u到v有边。
输出
如果图中有回路，则"yes",否则输出"no"
样例输入
#样例1
3 2
0 1
0 2
#样例2
3 3
0 1
1 2
2 0
样例输出
#样例1
no
#样例2
yes
"""
"""
使用一个状态数组 visited 表示顶点的访问状态：
    0：未访问
    1：访问中（递归栈中）
    2：访问完成
"""


def dfs(u):
    visited[u] = 1  # 标记为访问中，即这条路径的访问节点
    for v in graph[u]:
        if visited[v] == 0:
            if dfs(v): #v后面会发现回路
                return True
        elif visited[v] == 1:
            # 发现回路
            return True
    visited[u] = 2  # 访问完成
    return False

n, m = map(int, input().split())
graph = [[] for _ in range(n)]
for _ in range(m):
    u, v = map(int, input().split())
    graph[u].append(v)

visited = [0] * n
has_cycle = False
for i in range(n):
    if visited[i] == 0:
        if dfs(i):
            has_cycle = True
            break

print("yes" if has_cycle else "no")

def dfs(u, parent):
    visited[u] = 1  # 标记为访问中
    for v in graph[u]:
        if v == parent:
            continue  # 跳过直接连接的父节点
        if visited[v] == 0:
            if dfs(v, u):  # 递归检测子节点，并将当前节点作为父节点传递
                return True
        elif visited[v] == 1:
            return True  # 发现回路（遇到已在当前路径中的节点）
    visited[u] = 2  # 访问完成
    return False

n, m = map(int, input().split())
graph = [[] for _ in range(n)]
for _ in range(m):
    u, v = map(int, input().split())
    graph[u].append(v)  # 无向图需要添加双向边
    graph[v].append(u)

visited = [0] * n
has_cycle = False
for i in range(n):
    if visited[i] == 0:
        if dfs(i, -1):  # 初始父节点设为-1（表示无根节点）
            has_cycle = True
            break

print("yes" if has_cycle else "no")

n,m = map(int,input().split())
isConnected = [[0]*n for _ in range(n)]
for _ in range(m):
    u,v= map(int,input().split())
    u-=1
    v-=1
    isConnected[u][v]=1
    isConnected[v][u]=1

class UnionFind:
    def __init__(self, n):
        self.parent = list(range(n))

    def find(self, x):
        if self.parent[x] != x:
            self.parent[x] = self.find(self.parent[x])  # 路径压缩
        return self.parent[x]

    def union(self, x, y):
        self.parent[self.find(x)] = self.find(y)


class Solution:
    def findCircleNum(self, isConnected):
        n = len(isConnected)
        uf = UnionFind(n)

        for i in range(n):
            for j in range(i + 1, n):  # 避免重复遍历 只遍历对角线右上角
                if isConnected[i][j]:
                    uf.union(i, j)

        # 统计根节点个数
        return len({uf.find(i) for i in range(n)}) # {}是set

s=Solution()
print(s.findCircleNum(isConnected))

"""
给定一个由字符 '#' 和 '.' 构成的二维矩阵，'#' 表示墙，'.' 表示空地。上下左右相邻的空地被认为属于同一个连通区域。请计算：
    连通区域（即房间）的数量；
    最大连通区域的面积（即包含的 '.' 个数）。
输入
第一行是两个整数r和c(1 <=r,c <=100)，表示字符矩阵共有r行c列。
样例输入
6 12
############
#...#.#.#..#
#####......#
#..#########
#..#..#....#
############
样例输出
5
10
"""
from collections import deque

# 读取输入
r, c = map(int, input().split())
grid = [list(input()) for _ in range(r)]
visited = [[False for _ in range(c)] for _ in range(r)]

room_count = 0
max_area = 0

# 遍历每个点
for i in range(1,r-1):
    for j in range(1,c-1):
        if grid[i][j] == '.' and not visited[i][j]:
            # 开始BFS
            queue = deque()
            queue.append((i, j))
            visited[i][j] = True
            area = 1

            while queue:
                x, y = queue.popleft()
                # 四个方向
                for dx, dy in [(-1, 0), (1, 0), (0, -1), (0, 1)]:
                    nx = x + dx
                    ny = y + dy
                    # 检查是否在合法范围内，并且是否是未访问的'.'
                    if 0 <= nx < r and 0 <= ny < c:
                        if grid[nx][ny] == '.' and not visited[nx][ny]:
                            visited[nx][ny] = True
                            queue.append((nx, ny))
                            area += 1
            # 更新房间数和最大面积
            room_count += 1
            if area > max_area:
                max_area = area

print(room_count)
print(max_area)

"""
输入：
3 3  
0 1  
1 2  
2 0 
输出：
loop:yes  
"""
def has_cycle_dfs(node, parent, visited, graph):
    visited[node] = True
    for neighbor in graph[node]:
        if not visited[neighbor]:
            if has_cycle_dfs(neighbor, node, visited, graph):
                return True
        elif neighbor != parent:
            return True  # 遇到已访问且不是父节点的邻居，说明有环
    return False


def has_cycle(n, edges):
    graph = [[] for _ in range(n)]
    for u, v in edges:
        graph[u].append(v)
        graph[v].append(u)

    visited = [False] * n
    for i in range(n):
        if not visited[i]:
            if has_cycle_dfs(i, -1, visited, graph):
                return True
    return False


# 示例用法
if __name__ == "__main__":
    n, m = map(int, input().split()) #n个节点m条边
    edges = [tuple(map(int, input().split())) for _ in range(m)]

    if has_cycle(n, edges):
        print("loop:yes")
    else:
        print("loop:no")

"""
输入
第一行是整数n和m(0 < n <=16)，表示无向图有n个顶点，m条边，顶点编号0到n-1。接下来m行，每行两个整数a,b，表示顶点a,b之间有一条边。
输出
任意一个深度优先遍历序列

样例输入
9 9
0 1
0 2
3 0
2 1
1 5
1 4
4 5
6 3
8 7
样例输出
0 1 2 4 5 3 6 8 7
"""


def dfs(graph, visited, node, result):
    visited[node] = True
    result.append(node)
    for neighbor in sorted(graph[node]): #在评测系统中,如果不固定访问顺序，同样的代码可能在不同平台输出不同 DFS 序列，可能会导致“不一致”或“错误”判定。
        if not visited[neighbor]:
            dfs(graph, visited, neighbor, result)


def main():
    n, m = map(int, input().split())
    graph = {i: [] for i in range(n)} #节点：[邻居1、邻居2……]

    for _ in range(m):
        a, b = map(int, input().split())
        graph[a].append(b)
        graph[b].append(a)

    visited = [False] * n
    result = []

    # 遍历所有节点，处理不连通图的情况
    for i in range(n):
        if not visited[i]:
            dfs(graph, visited, i, result)

    print(" ".join(map(str, result)))


if __name__ == "__main__":
    main()

"""
问题描述：
给定一个无向图（点数 n，0 < n <= 16 ，边数 m ），以及 k 个序列（k < 50 ），判断每个序列是否为该无向图的深度优先遍历序列。

输入：

第一行 n 和 m，分别为无向图点数和边数，顶点编号 0 到 n - 1。
接下来 m 行，每行两个整数 a、b，表示 a 和 b 间有边。
然后是整数 k，表示待判断序列数量。
最后 k 行，每行是一个含 n 个整数（范围 [0, n - 1] ）的待判断序列。

输出：
对每个序列，若是深度优先遍历序列输出 YES，否则输出 NO。

样例输入
9 9
0 1
0 2
3 0
2 1
1 5
1 4
4 5
6 3
8 7
3
0 1 2 4 5 3 6 8 7
0 1 5 4 2 3 6 8 7
0 1 5 4 3 6 2 8 7
样例输出
YES
YES
NO

"""
"""
注意本题的图可能不是全联通的，引入虚拟节点n： 将其视为一个超级源点，与所有真实节点 0 到 n-1 都连接
"""
n, m = map(int, input().split())
edges = [[] for _ in range(n)]#[[], [], [], [], [], [], [], [], []] edges[i] 存储节点 i 的所有邻居
for _ in range(m):
    a, b = map(int, input().split())
    edges[a].append(b)
    edges[b].append(a)
ans = []
k = int(input())
for _ in range(k):
    node = list(map(int, input().split()))
    if len(node) != n:
        ans.append('NO')
        continue
    father = [-1] * n #用于记录 DFS 树中每个节点的父节点,-1 表示节点 i 尚未被访问或它是一个根节点。
    # remain 表示“当前节点还有哪些未访问的邻居可以探索”的状态。
    remain = [i.copy() for i in edges] + [[i for i in range(n)]]
    # 最后一项是引入虚拟节点n： 将其视为一个超级源点，与所有真实节点 0 到 n-1 都连接，这就允许 DFS 在一个连通分量探索完毕后，“跳跃”到另一个未访问的连通分量，从而覆盖所有节点。
    now = node[0]
    for i in range(n):
        try:
            remain[i].remove(now) #从每个节点的 `remain` 列表中移除当前节点 `now`。
        except: #如果 `now` 不在 `remain[i]` 中，捕获异常，继续。
            continue
    for i in range(1, n): #从第二个节点开始
        while len(remain[now]) == 0: #如果当前点 now 没有邻居可以继续走了，就回溯到它的父节点
            now = father[now]
        if node[i] in remain[now]: #如果下一个要访问的节点 node[i] 是当前节点 now 的可访问邻居：
            father[node[i]] = now #合法走法，设为子节点
            now = node[i]#当前点变为 node[i]，进入它
            for j in range(n):
                try:
                    remain[j].remove(now) #同样从所有邻接表中移除这个点（表示“已访问”）
                except:
                    continue
        else:
            ans.append('NO')
            break
    else:
        ans.append('YES')
for i in ans:
    print(i)

"""
给定 P 个前哨站的位置，我们要把它们连接成一个网络。
你可以使用：
    卫星通道 S 条（任何两个设有卫星通道的前哨站都可以通过卫星进行通信，无论它们的位置如何。）
    无线电通信（代价是最大通信距离 D，我们要求这个 D 尽可能小）
目标是：
    确定收发器所需的最低 D 值,使得每个前哨站之间必须至少有一条通信路径
输入：
输入的第一行包含 N，测试用例的数量。每个测试用例的第一行包含 1 <= S <= 100，卫星频道的数量，以及 S < P <= 500，前哨站的数量。接下来 P 行，给出每个前哨站(x,y)坐标（单位为 km，坐标为 0 到 10,000 之间的整数）。
输出：
对于每个案例，输出应仅包含一行，给出连接网络所需的最小 D 值。输出应精确到小数点后两位。【注意D不是剩下的总长度，而是剩下的最长的】
样例输入
1
2 4
0 100
0 300
0 600
150 750
样例输出
212.13
"""
"""
1.最小生成树（MST）：
首先构建一个包含所有前哨站的 MST，确保所有节点连通且总边权最小。这里使用 Kruskal 算法，按边权从小到大排序并依次选择，直到形成一棵树。
2.卫星通道的作用：
每条卫星通道可替代 MST 中的一条边，从而消除该边的距离限制。为了最小化剩余边中的最大距离 D，我们应优先选择 MST 中最长的 S-1 条边用卫星通道替代。
3.贪心策略：
移除 MST 中最长的 S-1 条边后，剩余边中的最大边即为所求的最小 D 值。
"""
import math

class UnionFind:
    def __init__(self, n):
        self.parent = list(range(n))

    def find(self, x):
        if self.parent[x] != x:
            self.parent[x] = self.find(self.parent[x])
        return self.parent[x]

    def union(self, x, y):
        fx, fy = self.find(x), self.find(y)
        if fx == fy:
            return False
        self.parent[fx] = fy
        return True


def distance(a, b):#a,b分别为两点坐标
    return math.sqrt((a[0] - b[0])**2+(a[1] - b[1])**2)


T = int(input())
for _ in range(T):
    S, P = map(int, input().split())
    points = [tuple(map(int, input().split())) for _ in range(P)]

    edges = []
    #遍历点坐标
    for i in range(P):
        for j in range(i + 1, P):
            d = distance(points[i], points[j])
            edges.append((d, i, j))

    edges.sort()#按距离排序
    uf = UnionFind(P)
    mst = []

    for d, u, v in edges:
        if uf.union(u, v):#未联通
            mst.append(d)
            if len(mst) == P - 1:
                break

    # 去掉最大的 S-1 条边
    mst.sort(reverse=True)#现在是从大到小
    result = mst[S - 1]  # 第 S 小边对应的最大 D
    print(f"{result:.2f}")

"""
给定一个词汇表 vocabulary.txt 和两个等长的单词（如 FOOL 和 SAGE），每次只能改变一个字母，并且中间产生的每一个单词都必须是词汇表中的合法单词，问从起点单词到终点单词的最短转换路径是什么？
"""
from graph import Graph, Vertex
from bfs import bfs
def buildGraph(wordFile):
    d = {}
    g = Graph(Vertex)
    with open(wordFile, 'r') as f:
        for line in f:
            word = line[:-1]
            # create buckets of words that differ by one letter
            for i in range(len(word)):
                bucket = word[:i]+'_'+word[i+1:]
                if bucket in d:
                    d[bucket].append(word)
                else:
                    d[bucket] = [word]

    # add vertices and edges for words in the same bucket
    for bucket in d.keys():
        for word1 in d[bucket]:
            for word2 in d[bucket]:
                if word1 != word2:
                    g.addEdge(word1, word2)
    return g


def traverse(y):
    x = y
    while (x.getPred()):
        print(x.getId())
        x = x.getPred()
    print(x.getId())


if __name__ == "__main__":
    g = buildGraph("vocabulary.txt")
    bfs(g, g.getVertex('FOOL'))
    target = input("traverse:")
    traverse(g.getVertex(target))
    #print(len(g.getVertices()))
    #print(g.vertices)

"""
给定一个 N节点的有向带权图，节点编号为 1到 N.要求从起点 1出发，
经过所有中间节点（2到N−1）恰好一次，最后到达终点 N，求路径总权重的最小值。

输入
输入数据包含多行。
第一行包含一个整数N(2 < N ≤ 16)，代表一共有N个岛屿。
之后的N行每一行包含N个整数，其中，第i(1 ≤ i ≤ N)行的第j(1 ≤ j ≤ N)个整数代表从第i个岛屿出发到第j个岛屿需要的时间t(0 < t < 10000)。第i行第i个整数为0。
输出
输出为一个整数，代表从起点遍历所有中间岛屿（不重复）之后到达终点所需要的最少的时间。

样例输入1：
4
0 10 20 999
5 0 90 30
99 50 0 10
999 1 2 0

样例输入2：
5
0 18 13 98 8
89 0 45 78 43
22 38 0 96 12
68 19 29 0 52
95 83 21 24 0
样例输出
样例输出1：
100

样例输出2：
137

提示：
对于样例输入1：路飞选择从起点岛屿1出发，依次经过岛屿3，岛屿2，最后到达终点岛屿4。花费时间为20+50+30=100。
对于样例输入2：可能的路径及总时间为：
1,2,3,4,5: 18+45+96+52=211
1,2,4,3,5: 18+78+29+12=137
1,3,2,4,5: 13+38+78+52=181
1,3,4,2,5: 13+96+19+43=171
1,4,2,3,5: 98+19+45+12=174
1,4,3,2,5: 98+29+38+43=208
所以最短的时间花费为137
单纯的枚举在N=16时需要14!次运算，一定会超时。
"""
"""
dp[mask][u] 表示：当前已访问的顶点集合 为 mask,当前所在的顶点 为 u,值 为从起点到当前状态的最短路径长度
"""
import sys
import math

n = int(sys.stdin.readline())
dist = [list(map(int, sys.stdin.readline().split())) for _ in range(n)]

dp = [[math.inf] * n for _ in range(1 << n)]
dp[1][0] = 0# 初始状态：只访问了起点1（索引0），mask的第0位为1

for mask in range(1 << n): # 遍历所有可能的状态
    for u in range(n): # 遍历当前顶点
        if not (mask & (1 << u)):# 如果u不在mask中，跳过
            continue
        current_time = dp[mask][u]
        if current_time == math.inf:
            continue
        for v in range(n): # 尝试转移到下一个顶点v
            if u == v or mask & (1 << v): # 不能转移到自身;如果v已经在mask中，跳过
                continue
            new_mask = mask | (1 << v)# 将v加入mask
            # 终点n-1（索引n-1）只能在最后一步访问
            if v != n - 1 or bin(new_mask).count('1') == n:
                dp[new_mask][v] = min(dp[new_mask][v], dp[mask][u] + dist[u][v])

# 最终状态是访问了所有节点，且位于终点n-1
print(dp[(1 << n) - 1][n - 1])

"""
N（1 ≤ N ≤ 100）头牛，编号为 1..N,，每场比赛两两对决，实力较强者总能战胜较弱者。每位选手的实力唯一。
给定M场比赛的结果，每场结果由两个整数 𝐴和 𝐵表示，表示选手 𝐴打败了选手𝐵。

请计算，有多少位选手的相对名次可以被准确确定。即该选手与其他所有𝑁−1位选手之间的胜负关系都可以从已知信息中推断出。

输入
第一行：两个用空格分隔的整数：N 和 M
2到M+1行：每行包含两个用空格分隔的整数，描述了一轮比赛的参赛者和结果（第一个整数 A 是获胜者）：A 和 B
输出：
一行一个整数，表示可以确定相对名次的选手数量
样例输入
5 5
4 3
4 2
3 2
1 2
2 5
样例输出
2
"""
"""
Floyd-Warshall 算法
graph[i][j] = True 表示牛 i 打败了牛 j
对每头牛 i，统计它：
    打败了多少牛（向外有多少边）
    被多少牛打败（有多少边指向它）
    若两者之和为 N - 1，说明它与所有牛都有胜负关系，排名可以确定。
"""
N, M = map(int, input().split())
graph = [[False] * (N + 1) for _ in range(N + 1)]

# 读入结果，建立初始胜负关系图
for _ in range(M):
    a, b = map(int, input().split())
    graph[a][b] = True

# Floyd-Warshall 算法，传递闭包
for k in range(1, N + 1):
    for i in range(1, N + 1):
        for j in range(1, N + 1):
            if graph[i][k] and graph[k][j]:
                graph[i][j] = True

# 统计每头牛与其他牛的胜负关系数
result = 0
for i in range(1, N + 1):
    count = 0
    for j in range(1, N + 1):
        if i == j:
            continue
        if graph[i][j] or graph[j][i]:
            count += 1
    if count == N - 1:
        result += 1

print(result)

"""
问题描述：
有 N 个孩子（N <= 300 ）分糖果，存在 M 个关系（M <= 30000 ），每个关系用 “A B C” 表示（A、B 为孩子编号，从 1 开始，C 为整数 ），即 A 比 B 少的糖果数不超 C。求第 N 个孩子最多比第 1 个孩子多分的糖果数（数据保证有解）。

输入：
第一行 N 和 M，分别为孩子数量和关系数量。
接下来 M 行，每行按 “A B C” 格式表示一个关系。

输出：
第 N 个孩子最多比第 1 个孩子多分的糖果数。

样例输入
2 2
1 2 5
2 1 4
样例输出
5
"""
import sys
from collections import deque


def main():
    n, m = map(int, sys.stdin.readline().split())
    graph = [[] for _ in range(n + 1)]
    for _ in range(m):
        a, b, c = map(int, sys.stdin.readline().split())
        graph[a].append((b, c))

    dist = [float('inf')] * (n + 1) #第N个孩子最多比第1个孩子多分的糖果数目
    dist[1] = 0
    in_queue = [False] * (n + 1)# in_queue[i] 为 True 表示节点 i 当前在队列中
    queue = deque([1])
    in_queue[1] = True

    while queue:
        u = queue.popleft()
        in_queue[u] = False
        for v, c in graph[u]:
            if dist[v] > dist[u] + c:
                dist[v] = dist[u] + c
                if not in_queue[v]:
                    queue.append(v)
                    in_queue[v] = True

    print(dist[n])


if __name__ == "__main__":
    main()

"""
描述：
一个 9 行 9 列的正方形表格被分成 9 个 3x3 的小方格，如图所示。在有些单元格中写有 1 到 9 的十进制数字。其他单元格为空。目标是使用 1 到 9 的十进制数字填充空单元格，每个单元格一个数字，使得每一行、每一列以及每个标记的 3x3 子方格中都能出现 1 到 9 的所有数字。编写一个程序来解决给定的数独任务。
输入：
输入数据将以测试用例的数量开始。对于每个测试用例，将跟随 9 行，对应于表格的行。每行给出一个由 9 个十进制数字组成的字符串，对应于该行中的单元格。如果一个单元格为空，则用 0 表示。
输出：
对于每个测试用例，你的程序应该以与输入数据相同的格式打印解决方案。空单元格必须按照规则填写。如果解决方案不唯一，则程序可以打印其中任何一个。

样例输入
1
103000509
002109400
000704000
300502006
060000050
700803004
000401000
009205800
804000107
样例输出
143628579
572139468
986754231
391542786
468917352
725863914
237481695
619275843
854396127
"""
def solve_sudoku():
    def is_valid(row, col, num): # #rows[row] 是该行已经填过的数；cols[col] 是该列已经填过的数；boxes[box_index(row, col)] 是该3x3小格已填数字；
        return not (rows[row] & (1 << num)) and not (cols[col] & (1 << num)) and not (boxes[box_index(row, col)] & (1 << num))

    def place_number(row, col, num):# 把数字 num 填进 (row, col)，并更新行、列、小格中的状态。
        rows[row] |= (1 << num)
        cols[col] |= (1 << num)
        boxes[box_index(row, col)] |= (1 << num)
        board[row][col] = num

    def remove_number(row, col, num):##回溯时用的撤销，^= 是位异或，相当于“取消”之前打的标记，二进制位不同时为`1`，相同时为`0
        rows[row] ^= (1 << num)
        cols[col] ^= (1 << num)
        boxes[box_index(row, col)] ^= (1 << num)
        board[row][col] = 0

    def box_index(row, col):#计算一个格子所属的 3x3 小方格编号，总共 9 个小方格，编号从 0 到 8。# 行：012-0；345-1；678-2；列：012-0；345-1；678-2 # 行*3+列
        return (row // 3) * 3 + col // 3

    def find_empty():#找最优填入位置#在所有空格中找“可能填的数字最少”的那个，优先填这个，有助于提高回溯效率。
        min_choices = float('inf')
        best_pos = None
        for i in range(9):# 先遍历每一个位置，空着的位置上再遍历9个数字，看哪些数字可能填
            for j in range(9):
                if board[i][j] == 0:
                    choices = 0
                    for num in range(1, 10):
                        if is_valid(i, j, num):
                            choices += 1
                    if choices < min_choices:
                        min_choices = choices
                        best_pos = (i, j)
        return best_pos

    def backtrack():
        pos = find_empty()
        if not pos:
            return True  # 所有格子都填满
        row, col = pos

        for num in range(1, 10):
            if is_valid(row, col, num):
                place_number(row, col, num)
                if backtrack():
                    return True
                remove_number(row, col, num)
        return False

    # 初始化全局变量
    global rows, cols, boxes, board ##rows[row] 是该行已经填过的数；cols[col] 是该列已经填过的数；boxes[box_index(row, col)] 是该3x3小格已填数字；
    rows = [0] * 9
    cols = [0] * 9
    boxes = [0] * 9
    board = [[0] * 9 for _ in range(9)]

    # 读取输入并初始化
    for i in range(9):
        for j in range(9):
            num = int(input_data[i][j])
            if num != 0:
                place_number(i, j, num)

    # 开始回溯求解
    backtrack()

    # 输出结果
    for row in board:
        print(''.join(map(str, row)))


def main():
    import sys
    input = sys.stdin.read
    data = input().split()

    t = int(data[0])  # 测试用例数量
    index = 1

    for _ in range(t):
        global input_data
        input_data = [data[index + i] for i in range(9)]
        index += 9
        solve_sudoku()


if __name__ == "__main__":
    main()

"""
描述
在n个不同的正整数里，任意取若干个，不能重复取,要求它们的和是7的倍数，问有几种取法。

输入
第一行是整数t，表示有t组数据(t<10)。接下来有t行，每行是一组数据，每组数据第一个数是n（1 <= n <= 16），表示要从n个整数里取数,接下来就是n个整数。
输出
对每组数据，输出一行，表示取法的数目（一个都不取也算一种取法）。
样例输入
3
3 1 2 4
5 1 2 3 4 5
12 1 2 3 4 5 6 7 8 9 10 11 12
样例输出
2
5
586
"""
t = int(input())
for _ in range(t):
    data = list(map(int, input().split()))
    n = data[0]
    nums = data[1:]
    count = 0
    for mask in range(1 << n):  # 枚举所有子集
        total = 0
        for i in range(n):
            if (mask >> i) & 1:  # 如果第 i 位为 1，选中 nums[i]
                total += nums[i]
        if total % 7 == 0:
            count += 1
    print(count)

"""
要求输出给定字符串的 所有排列，而且要按照 字典序升序排列。
"""
from itertools import permutations

s = input().strip()

for p in permutations(s): #自动生成全排列，而且生成顺序就是字典序
    print(''.join(p))

"""
输入: [1,2,3]
输出: [ [1,2,3], [1,3,2], [2,1,3], [2,3,1], [3,1,2], [3,2,1] ]

"""
class Solution:
    def permute(self, nums):
        result = []
        self.backtracking(nums, [], [False] * len(nums), result)
        return result

    def backtracking(self, nums, path, used, result):
        if len(path) == len(nums):
            result.append(path[:])
            return
        for i in range(len(nums)):
            if used[i]:
                continue
            used[i] = True
            path.append(nums[i])
            self.backtracking(nums, path, used, result)
            path.pop()
            used[i] = False

def permute(s, path, used, res):
    if len(path) == len(s):
        res.append(''.join(path))
        return
    for i in range(len(s)):
        if not used[i]:
            used[i] = True
            path.append(s[i])
            permute(s, path, used, res)
            path.pop()
            used[i] = False

s = input().strip()
res = []
permute(s, [], [False]*len(s), res)

for p in res:
    print(p)

"""
给定正整数 N（N≤100），找出所有满足 a³ = b³ + c³ + d³ 的四元组 (a, b, c, d)，其中 a、b、c、d 均大于 1 且不超过 N，且 b≤c≤d。按 a 从小到大输出，若 a 相同则按 b、c、d 从小到大输出，每行格式为 “Cube = a, Triple = (b,c,d)”。
样例输入
24
样例输出
Cube = 6, Triple = (3,4,5)
Cube = 12, Triple = (6,8,10)
Cube = 18, Triple = (2,12,16)
Cube = 18, Triple = (9,12,15)
Cube = 19, Triple = (3,10,18)
Cube = 20, Triple = (7,14,17)
Cube = 24, Triple = (12,16,20)
"""
# 枚举
def find_perfect_cubes_further_optimized(N):
    cubes = [i ** 3 for i in range(N + 1)]
    cubes_set = set(cubes)
    for a in range(2, N + 1):
        a_cubed = cubes[a]
        for b in range(2, a):
            b_cubed = cubes[b]
            for c in range(b, a):
                c_cubed = cubes[c]
                d_cubed = a_cubed - b_cubed - c_cubed
                if d_cubed < c_cubed:
                    break
                if d_cubed in cubes_set:
                    d = round(pow(d_cubed, 1 / 3))
                    if cubes[d] == d_cubed and c <= d < a:
                        print(f"Cube = {a}, Triple = ({b},{c},{d})")

N = int(input())
find_perfect_cubes_further_optimized(N)

"""
问题描述：
已知拼数字 0 - 9 所需火柴棍数量（如图），加号和等号各需 2 根火柴棍。给定火柴棍数量 n（n ≤ 24 ），求能拼出形如 “A + B = C”（A、B、C ≥ 0，A 非零最高位不为 0 ）等式的数量，A ≠ B 时，A + B = C 与 B + A = C 视为不同等式，且 n 根火柴棍需全部用完。

输入：
一个整数 n（n ≤ 24 ）。
输出：
能拼成的不同等式的数量。
样例输入
5
样例输出
0
"""
#枚举
# 每个数字所需火柴棍数量
nums = [6, 2, 5, 5, 4, 5, 6, 3, 7, 6]


def count_matches(num): #数字对应的火柴数
    if num == 0:
        return nums[0]
    count = 0
    while num > 0:
        count += nums[num % 10] #先加个位
        num //= 10 #再加十位等等
    return count


n = int(input())
# 减去加号和等号占用的火柴棍数量
n -= 4
count = 0
for a in range(1000):
    for b in range(1000):
        c = a + b
        if count_matches(a) + count_matches(b) + count_matches(c) == n:
            count += 1
print(count)

"""
描述
给出4个小于10个正整数，你可以使用加减乘除4种运算以及括号把这4个数连接起来得到一个表达式。现在的问题是，是否存在一种方式使得得到的表达式的结果等于24。

比如，对于5，5，5，1，我们知道5 * (5 – 1 / 5) = 24，因此可以得到24。又比如，对于1，1，4，2，我们怎么都不能得到24。

输入
输入数据包括多行，每行给出一组测试数据，包括4个小于10个正整数。最后一组测试数据中包括4个0，表示输入的结束，这组数据不用处理。
输出
对于每一组测试数据，输出一行，如果可以得到24，输出“YES”；否则，输出“NO”。

样例输入
5 5 5 1
1 1 4 2
0 0 0 0
样例输出
YES
NO
"""
# 定义一个极小值EPSILON，用于浮点数比较时的误差容忍
EPSILON = 1e-6


def find_24(numbers):
    n = len(numbers)

    # 基本情况1：如果列表为空，不可能得到24。
    if n == 0:
        return False

    # 基本情况2：如果列表只剩一个数字，检查这个数字是否约等于24。
    if n == 1:
        return abs(numbers[0] - 24) < EPSILON

    # 递归步骤：遍历所有可能的数字对 (numbers[i], numbers[j]) 进行运算。
    for i in range(n):
        for j in range(i + 1, n):

            num1 = numbers[i]
            num2 = numbers[j]

            # 构建下一次递归调用的数字列表：它包含当前列表中除了 numbers[i] 和 numbers[j] 之外的所有其他数字。
            remaining_numbers_after_pair_selection = []
            for k in range(n):
                if k != i and k != j:
                    remaining_numbers_after_pair_selection.append(numbers[k])

            # 尝试6种可能的二元运算结果：
            # 1. 加法: num1 + num2 (num2 + num1 结果相同，无需重复),将运算结果和剩余数字组成新列表，进行递归调用
            if find_24(remaining_numbers_after_pair_selection + [num1 + num2]):
                return True  # 如果递归返回True，说明找到解，立即返回True

            # 2. 乘法: num1 * num2 (num2 * num1 结果相同)
            if find_24(remaining_numbers_after_pair_selection + [num1 * num2]):
                return True

            # 3. 减法: num1 - num2
            if find_24(remaining_numbers_after_pair_selection + [num1 - num2]):
                return True

            # 4. 减法 (交换顺序): num2 - num1
            if find_24(remaining_numbers_after_pair_selection + [num2 - num1]):
                return True

            # 5. 除法: num1 / num2
            #    在进行除法前，必须检查除数 num2 是否接近0 (绝对值小于EPSILON)
            if abs(num2) > EPSILON:  # 避免除以零
                if find_24(remaining_numbers_after_pair_selection + [num1 / num2]):
                    return True

            # 6. 除法 (交换顺序): num2 / num1
            #    同样检查除数 num1 是否接近0
            if abs(num1) > EPSILON:  # 避免除以零
                if find_24(remaining_numbers_after_pair_selection + [num2 / num1]):
                    return True

    return False

while True:
    line_str_parts = input().split()
    current_numbers_as_int = [int(s) for s in line_str_parts]

    if len(current_numbers_as_int) == 4 and all(x == 0 for x in current_numbers_as_int):
        break

    # 将整数列表转换为浮点数列表，因为除法可能产生小数
    current_numbers_as_float = [float(x) for x in current_numbers_as_int]

    # 调用 find_24 函数进行判断
    if find_24(current_numbers_as_float):
        print("YES")
    else:
        print("NO")

"""
描述
用数字'0'–'9'替换字母'A'- 'E'，使得类似于下面形式的等式成立：

ABC + ACDE = DCABC

同一字母必须用同一数字替换，不同字母必须用不同数字替换。如果无解，则输出“No Solution”。替换后产生的数不能有前导0,比如“012”，是不允许出现的。对每个等式，要求输出替换为字母后的等式。如果有多个解，要输出最小的解。两个解比大小，哪个解字母'A'表示的数小就算小；字母'A'表示的数相同，则比较字母'B'表示的数......如果无解，则输出"No Solution"。

输入
输入数据第一行是整数n，代表有n个等式要求解；接下来每行是一个等式，由三个字符串s1、s2、s3组成，等式就是s1+s2=s3。每个字符串长度最多10个字符，只会包含'A'- 'E'这五个字母。
输出
对每个等式，输出替换后的结果
样例输入
5
A A B
AA AA AAA
AB ABC ACDD
A A BC
ABCD BCD ACEA
样例输出
1+1=2
No Solution
No Solution
5+5=10
2371+371=2742
"""

import itertools


def solve_single_equation():
    s1, s2, s3 = input().split()

    # 提取当前等式中出现的所有不同的字母，并进行排序
    unique_letters_in_equation = sorted(list(set(s1 + s2 + s3)))
    # k 是字母总数,最多不超过5个
    k = len(unique_letters_in_equation)

    # 枚举所有排列
    digits = range(10) #准备数字 0~9
    found_solutions = [] #保存所有合法解的列表

    # 对 digits 的 k 个位置进行排列组合，生成所有可能的 k 个不同数字分配方案。总共最多 P(10,5) = 30240 种。
    for p_digits in itertools.permutations(digits, k):
        mapping = {}

        #构建从每个字母到数字的映射
        for i in range(k):
            mapping[unique_letters_in_equation[i]] = p_digits[i]

        # 字母替换为数字字符串
        s1_val_str = "".join(str(mapping[char]) for char in s1)
        s2_val_str = "".join(str(mapping[char]) for char in s2)
        s3_val_str = "".join(str(mapping[char]) for char in s3)

        # 检查前导零
        if (len(s1_val_str) > 1 and s1_val_str[0] == '0') or \
                (len(s2_val_str) > 1 and s2_val_str[0] == '0') or \
                (len(s3_val_str) > 1 and s3_val_str[0] == '0'):
            continue

        num1 = int(s1_val_str)
        num2 = int(s2_val_str)
        num3 = int(s3_val_str)

        # 判断加法是否成立
        if num1 + num2 == num3:
            # 构建排序键
            sort_key_values = []
            canonical_letters = ['A', 'B', 'C', 'D', 'E']
            for char_code in canonical_letters:
                sort_key_values.append(mapping.get(char_code, 10))#不存在的字母赋值为 10（高于任何合法数字0-9）

            found_solutions.append(
                (tuple(sort_key_values), s1_val_str, s2_val_str, s3_val_str)
            )

    if not found_solutions:
        print("No Solution")
    else:
        # 如果有合法解，按 sort_key 排序后取第一个（最小解）
        found_solutions.sort(key=lambda x: x[0])
        best_sol = found_solutions[0]
        print(f"{best_sol[1]}+{best_sol[2]}={best_sol[3]}")

n = int(input())
for _ in range(n):
    solve_single_equation()

"""
给定一棵完全二叉树（节点编号 1-N，自上而下、自左向右），每个节点有一个宝藏价值。选取若干节点，使得任意两个选中节点不相邻（即无父子关系），求所选节点价值总和的最大值。
输入
第一行：节点数 N。
第二行：N 个非负整数，第 i 个数为节点 i 的宝藏价值。
输出
满足条件的最大价值总和。

样例输入：
6
3 4 5 1 3 1
输出：9
"""
"""
最大独立集问题，可以通过动态规划高效解决。
对于每个节点 i，有两种状态：
    选：当前节点 i 被选中时，其左右子节点（2i, 2i+1）不能被选，但可以选孙子节点（4i, 4i+1, 4i+2, 4i+3）。
    不选：当前节点 i 不被选中时，可以选择其左右子节点（2i, 2i+1），但不能选孙子节点。
父节点的计算必须依赖于子节点和孙子节点的结果。如果先处理父节点，子节点的最优解尚未计算，会导致错误。因此，必须从叶子节点开始（最底层），逐步向上计算各层节点，确保处理每个节点时，其所有子节点已处理完毕。
"""
n = int(input())
l = list(map(int, input().split()))
l = [0] + l
#这返回的是一个函数，用于返回节点i的权重
L = lambda i : l[i] if i<=n else 0
for i in range(n, 0, -1):
    l[i] = max(L(2*i)+L(2*i+1), l[i]+L(4*i)+L(4*i+1)+L(4*i+2)+L(4*i+3))
print(l[1])

"""
输入
输入的第一行是一个整数 T (T <= 50) ，表示一共有 T 组数据。
接下来的每组数据，第一行是一个整数 N (1 <= N <= 100, 000) ，表示一共有 N 天。第二行是 N 个被空格分开的整数，表示每天该股票的价格。该股票每天的价格的绝对值均不会超过 1,000,000 。
输出
对于每组数据，输出一行。该行包含一个整数，表示阿福能够获得的最大的利润。
样例输入
3
7
5 14 -2 4 9 3 17
6
6 8 7 4 1 -2
4
18 9 5 2
样例输出
28
2
0
"""

def max_profit(prices,n):
    dp=[[0]*5 for _ in range(n)]
    dp[0][1] = -prices[0]
    dp[0][3] = -prices[0]
    for i in range(1,n):
        dp[i][1] = max(dp[i-1][1],dp[i-1][0]-prices[i])#第一次持有
        dp[i][2] = max(dp[i-1][2],dp[i-1][1]+prices[i])#第一次卖出
        dp[i][3] = max(dp[i-1][3],dp[i-1][2]-prices[i])#第二次持有
        dp[i][4] = max(dp[i-1][4],dp[i-1][3]+prices[i])#第二次卖出
    return dp[n-1][4]
T=int(input())
for _ in range(T):
    n = int(input())
    prices = list(map(int,input().split()))
    print(max_profit(prices,n))

"""
描述
有一个容积为n的背包，有m种物品，要求取出若干种物品，正好将背包填满，问一共有多少种取法。每种物品可以取任意多个。

输入
有几组测试数据。每组测试数据两行。第一行是两个整数，n和m， 0< n,m <= 100。
第二行是m个正整数，表示m种物品的体积。物品体积不超过1000。若干组输入数据后，输入数据以一行“0 0”表示结束。
输出
对每组数据，输出取法种数
样例输入
5 3
1 2 3
5 3
3 4 6
0 0
样例输出
5
0
"""
"""
dp[i] 表示填满体积为 i 的背包的方案数
对于每种物品 v，遍历 i 从 v 到 n：
"""

while True:
    line = input()
    if line == "0 0":
        break
    n, m = map(int, line.split())
    items = list(map(int, input().split()))

    dp = [0] * (n + 1)
    dp[0] = 1  # 初始体积为 0 的方案数为 1

    for v in items:
        for i in range(v, n + 1): #后面i体积的都能放下这个v,dp[i]原本是不放这个物品的数量，放了这个物品后，就剩i-v的体积
            dp[i] += dp[i - v]

    print(dp[n])

"""
给定 n 个物品，每个物品有价值 v 和重量 w（可拆分）。选取若干物品（可拆分任意比例），使总重量不超过给定重量 W，求最大总价值。

输入：
第一行 n 和 W，后续 n 行每行 v(1 <= n <= 100) 和 w（0 < w < 10000）。

输出：
最大总价值（保留 1 位小数）。

样例输入
4 15
100 4
412 8
266 7
591 2
样例输出
1193.0
"""
n,w =map(int,input().split())
candies = []
for _ in range(n):
    value,weight = map(int,input().split())
    candies.append((value,weight,value/weight))
candies.sort(key=lambda x: x[2], reverse=True)
total = 0
for value,weight,ratio in candies:
    if w - weight >=0:
        total += value
        w = w - weight
    else:
        total+=w*ratio
        break
print(f"{total:.1f}")

"""
输入
一次输入可能包含多行，每一行分别给出不同的 n 值 ( 即 3 乘 n 棋盘的列数 )。当输入 -1 的时候结束。
n 的值最大不超过 30.

输出
针对每一行的 n 值，输出 3 乘 n 棋盘的不同的完美覆盖的总数。
样例输入
2
8
12
-1
样例输出
3
153
2131
"""

"""
思路：
每块骨牌必须恰好覆盖两个相邻的格子，3n 必须是偶数，否则无法完全覆盖。

f(n)=3f(n−2)+2f(n−4)+2f(n−6)+2f(n−8)+⋯+2f(0)

当我们把一块 2×3 的区域塞进棋盘中时，可以用 3 种基本方式去填它 → 这就对应 3f(n-2)
但对于更长的区域，比如 n = 4、6、8……，我们可以构造出一种“组合结构”：左右两边对称，中间有一个固定图案

"""


def f(n):
    if n == 0:
        return 1
    elif n == 2:
        return 3
    else:
        return 4*(f(n-2)) - f(n-4)

while True:
    k = int(input().strip())
    if k == -1:
        exit(0)
    if k % 2 == 1:
        print(0)
    else:
        print(f(k))

"""
描述
把M个同样的苹果放在N个同样的盘子里，允许有的盘子空着不放，问共有多少种不同的分法？（用K表示）5，1，1和1，5，1 是同一种分法。
输入
第一行是测试数据的数目t（0 <= t <= 20）。以下每行均包含二个整数M和N，以空格分开。1<=M，N<=10。
输出
对输入的每组数据M和N，用一行输出相应的K。
样例输入
1
7 3
样例输出
8
"""
"""
dp[i][j]i个苹果，有j个盘子时的分法数
"""
def f(m,n):
    dp=[[0 for  _ in range(n+1)] for _ in range(m+1)]
    for i in range(m+1):
        dp[i][1]=1 #只有一个盘子
    for j in range(n+1):
        dp[0][j]=1 #只有0个苹果

    for i in range(1,m+1):
        for j in range(2,n+1):
            if i>=j: #苹果数大于盘子数
                dp[i][j]=dp[i-j][j]+dp[i][j-1] #无空盘子和有空盘子两种情况
            else:
                dp[i][j] =dp[i][i]

    return dp[m][n]
t=int(input())
for _ in range(t):
    m,n=map(int,input().split())
    print(f(m,n))

"""
给定一个二维数组，表示每个位置的高度。一个人可以从当前位置向上下左右四个方向移动，前提是移动后的位置高度比当前低。

请找出一条最长的严格递减路径，并输出该路径的长度。

输入格式
第一行两个整数 R 和 C，表示数组的行数和列数（1 ≤ R, C ≤ 100）。
接下来 R 行，每行 C 个整数，表示高度 h（0 ≤ h ≤ 10000）。

输出格式
输出最长递减路径的长度。

样例输入
5 5
1 2 3 4 5
16 17 18 19 6
15 24 25 20 7
14 23 22 21 8
13 12 11 10 9
样例输出
25
"""

R, C = map(int, input().split())
heights = [list(map(int, input().split())) for _ in range(R)]

dp = [[-1] * C for _ in range(R)]

dirs = [(-1, 0), (1, 0), (0, -1), (0, 1)]


def dfs(x, y):
    if dp[x][y] != -1:
        return dp[x][y]

    max_len = 1  # 最短也能站在自己不动
    for dx, dy in dirs:
        nx, ny = x + dx, y + dy
        if 0 <= nx < R and 0 <= ny < C and heights[nx][ny] < heights[x][y]:
            max_len = max(max_len, 1 + dfs(nx, ny))

    dp[x][y] = max_len
    return dp[x][y]


# 枚举每一个点作为起点
result = 0
for i in range(R):
    for j in range(C):
        result = max(result, dfs(i, j))

print(result)

"""
给定一个整数集合 S = {s1, s2, ..., sn}，以及一个目标数 T，我们需要判断是否存在 S 的某个子集，使得该子集的和恰好等于 T。
"""
"""
dp[j] 表示是否存在某个子集，其和为 j
"""
def subset_sum(S, T):
    n = len(S)
    dp = [False] * (T + 1)
    dp[0] = True  # 和为 0 总是可以通过空集达成

    for num in S:
        for j in range(T, num - 1, -1): #防止同一元素被重复使用
            dp[j] = dp[j] or dp[j - num] #不用这个num或者用这个num

    return dp[T]

S = [1, 2, 3, 5, 10]
T = 8

if subset_sum(S, T):
    print("存在一个子集，其和为", T)
else:
    print("不存在这样的子集")

"""
给定长度为N的三个数组a,b,c,按顺序安排N个元素依次选择一个未选过的位置。每个位置被选时的得分规则如下：
    若所选位置的左右均未被选过（即首次选该位置，且左右无已选位置），得分为a[i] i是他是第几个坐下的
    若所选位置的左右中恰有一个已被选过，得分为b[i]
    若所选位置的左右均已被选过（仅当该位置左右均有已选位置时可能发生），得分为c[i]
目标： 安排选位顺序，使得总得分最大。

输出
一个整数，表示获得最大的能力值和
样例输入
4
1 2 2 4
4 3 3 1
2 1 1 2
样例输出
14
"""
"""
leftmax:在处理前 i 个座位时的最大得分情况
"""

n = int(input())
a = [int(x) for x in input().split()]
b = [int(x) for x in input().split()]
c = [int(x) for x in input().split()]

if n==1:
    result=a[0]
elif n==2:
   result=max(a[0]+b[1],b[0]+a[1])
else:
 leftmax=[[0,0] for i in range(n-1)]
 for i in range(n-1):
    if i==0:
        leftmax[i][1]=b[0] #leftmax[i][1]保存当坐入第i个位置时若右侧已被占，前面所有座位最大能力值总和
        leftmax[i][0]=a[0] #反之，右侧未被占
    else:
        leftmax[i][1]=max(leftmax[i-1][1]+b[i],leftmax[i-1][0]+c[i])
        leftmax[i][0]=max(leftmax[i-1][1]+a[i],leftmax[i-1][0]+b[i])

 result=max(leftmax[n-2][0]+b[n-1],leftmax[n-2][1]+a[n-1])
print(result)

"""
小明打算在一条直线上的若干个位置开餐馆。每个位置有：
    一个坐标（整数，已升序排列）
    在该位置开餐馆的利润
限制：任何两个餐馆之间的距离必须大于k
你的任务是帮他选择一组位置，使得总利润最大。

输入格式：
- 第1行：一个整数 T，表示测试组数
- 每组测试数据包含三行：
    1. 两个整数 n和 k：位置数量和最小距离限制
    2. n个整数：位置数组 m1,m2,...,mnm（升序排列）
    3. n个整数：对应位置的利润数组 p1,p2,...,pn
输出格式：
对于每组测试数据，输出一行，一个整数：最大总利润

样例输入
2
3 11
1 2 15
10 2 30
3 16
1 2 15
10 2 30
样例输出
40
30
"""
"""
dp[i] 表示以第 i 个位置结尾时的最大利润
若前i个位置全在一个大小小于k的区间之内，则dp[i] = max(p[0: i + 1])，即前i个位置的最大利润。
否则，可以选择在第i个位置开店或者不开店，不开店则dp[i] = dp[i - 1]；开店则dp[i] = dp[j] + p[i]，其中，j是满足第j个地点和第i个地点之间间隔超过k的最大的j。可以通过从后向前遍历来找到。因此dp[i] = max(dp[i - 1], dp[j] + p[i])。
"""
T = int(input())
for _ in range(T):
    n, k = map(int, input().split())
    m = list(map(int, input().split()))
    p = list(map(int, input().split()))
    if n == 0:
        print(0)
        continue
    dp = [0] * n
    dp[0] = p[0]
    for i in range(1, n):
        if m[i] - m[0] <= k: # 若第i个位置与第一个地点距离小于k
            dp[i] = max(p[_] for _ in range(i+1)) # 那么只考虑前i个地点的最大利润，由于只能开一个餐馆
        else:
            for j in range(i-1,-1,-1):
                if m[i] - m[j] > k:
                    dp[i] = max(dp[i - 1], dp[j] + p[i])
                    break
    print(dp[-1])

"""
从三角形的顶部到底部有很多条不同的路径。对于每条路径，把路径上面的数加起来可以得到一个和，你的任务就是找到最大的和。
路径上的每一步只能从一个数走到下一层和它最近的左边的那个数或者右边的那个数。

输入
输入的是一行是一个整数N (1 < N <= 100)，给出三角形的行数。下面的N行给出数字三角形。数字三角形上的数的范围都在0和100之间。
输出
输出最大的和。

样例输入
5
7
3 8
8 1 0
2 7 4 4
4 5 2 6 5
样例输出
30
"""
"""
自底向上
"""
def max_path_sum(n, triangle):
    # 从倒数第二行开始进行自底向上的动态规划
    for i in range(n - 2, -1, -1):  # 从倒数第二行开始到第一行
        for j in range(i + 1):  # 第i行有i+1个元素
            # 更新 dp[i][j]，即从当前元素到下方相邻的两元素的最大路径和
            triangle[i][j] += max(triangle[i + 1][j], triangle[i + 1][j + 1])

    # 返回顶点的最大路径和
    return triangle[0][0]

# 输入数据
n = int(input())  # 读入行数
triangle = [list(map(int, input().split())) for _ in range(n)]

# 计算并输出最大路径和
print(max_path_sum(n, triangle))

"""
描述
将正整数n 表示成一系列正整数之和，n=n1+n2+…+nk, 其中n1>=n2>=…>=nk>=1 ，k>=1 。
正整数n 的这种表示称为正整数n 的划分。正整数n 的不同的划分个数称为正整数n 的划分数

输入
一个整数N(0 < N <= 30)。
输出
输出N的划分数。
样例输入
5
样例输出
7
提示
5, 4+1, 3+2, 3+1+1, 2+2+1, 2+1+1+1, 1+1+1+1+1
"""
"""
设 dp[n][k] 表示将整数n 划分为最大加数不超过 k 的划分数。这样定义有助于保证划分中各部分非递增
"""

N = int(input())

dp = [[0] * (N+1) for _ in range(N+1)]

# 边界条件：0的划分数是1
for k in range(N+1):
    dp[0][k] = 1

for n in range(1, N+1):
    for k in range(1, N+1):
        if k > n:
            dp[n][k] = dp[n][n]  # 最大加数超过n时，等于最大加数为n的划分数
        else:
            dp[n][k] = dp[n][k-1] + dp[n-k][k]

print(dp[N][N])

"""
给定一个正整数 n，将其拆分为至少两个正整数的和，并使这些整数的乘积最大化。 返回你可以获得的最大乘积。

示例 1:
输入: 2
输出: 1
解释: 2 = 1 + 1, 1 × 1 = 1。

示例 2:
输入: 10
输出: 36
解释: 10 = 3 + 3 + 4, 3 × 3 × 4 = 36。
"""
"""
dp[i]：分拆数字i，可以得到的最大乘积为dp[i]
从1遍历j,有两种渠道得到dp[i]
    一个是j * (i - j) 直接相乘
    一个是j * dp[i - j]，相当于是拆分(i - j) [j是从1开始遍历，拆分j的情况，在遍历j的过程中其实都计算过了,不用拆分j]
    dp[i] = max({dp[i], (i - j) * j, dp[i - j] * j})

因为拆分一个数n 使之乘积最大，那么一定是拆分成m个近似相同的子数相乘才是最大的。
只不过我们不知道m究竟是多少而已，但可以明确的是m一定大于等于2，既然m大于等于2，也就是 最差也应该是拆成两个相同的 可能是最大值。
那么 j 遍历，只需要遍历到 n/2 就可以，后面就没有必要遍历了，一定不是最大值。
"""


def integerBreak(n):
    dp = [0] * (n + 1)  # 创建一个大小为n+1的数组来存储计算结果
    dp[2] = 1  # 初始化dp[2]为1，因为当n=2时，只有一个切割方式1+1=2，乘积为1

    # 从3开始计算，直到n
    for i in range(3, n + 1):
        # 遍历所有可能的切割点
        for j in range(1, i // 2 + 1):
            # 计算切割点j和剩余部分(i-j)的乘积，并与之前的结果进行比较取较大值

            dp[i] = max(dp[i], (i - j) * j, dp[i - j] * j)

    return dp[n]  # 返回最终的计算结果

#n拆成k个正整数
"""
dp[i][j]
    最后一个加数是 1
    所有加数都 ≥ 2
"""
def count_k_partitions(n, k):
    dp = [[0] * (n + 1) for _ in range(k + 1)]
    dp[0][0] = 1
    for i in range(1, k + 1):
        for j in range(1, n + 1):
            if j >= i: #要凑成的数至少要等于个数，否则0中拆法
                dp[i][j] = dp[i - 1][j - 1] + dp[i][j - i]
    return dp[k][n]

# N划分成若干个奇正整数之和的划分数目
#允许重复使用
def count_odd_partitions(n):
    dp = [0] * (n + 1)
    dp[0] = 1
    for i in range(1, n + 1, 2): # 只遍历奇数
        for j in range(i, n + 1):# j 是当前目标和
            dp[j] += dp[j - i]
    return dp[n]

#N划分成若干个不同正整数之和的划分数目
"""
每个数只能用一次
 0/1背包问题（物品体积为数值 i，每个只能选一次，目标是放满n的背包。

 倒序遍历：防止重复使用i
"""
def count_distinct_partitions(n):
    dp = [0] * (n + 1)
    dp[0] = 1
    for i in range(1, n + 1):
        for j in range(n, i - 1, -1):  # 从大到小倒着更新，确保每个i只用一次
            dp[j] += dp[j - i]
    return dp[n]
print(count_distinct_partitions(5))

"""
给你两个单词 word1 和 word2， 请返回将 word1 转换成 word2 所使用的最少操作数  。

你可以对一个单词进行如下三种操作：

插入一个字符
删除一个字符
替换一个字符


示例 1：

输入：word1 = "horse", word2 = "ros"
输出：3
解释：
horse -> rorse (将 'h' 替换为 'r')
rorse -> rose (删除 'r')
rose -> ros (删除 'e')
"""
"""
dp[i][j] 代表 word1 到 i 位置转换成 word2 到 j 位置需要最少步数
"""
class Solution:
    def minDistance(self, word1: str, word2: str) -> int:
        n1 = len(word1)
        n2 = len(word2)
        dp = [[0] * (n2 + 1) for _ in range(n1 + 1)]
        # 第一行
        for j in range(1, n2 + 1):
            dp[0][j] = dp[0][j-1] + 1 #word1 为空变成 word2 最少步数
        # 第一列
        for i in range(1, n1 + 1):
            dp[i][0] = dp[i-1][0] + 1 #word2 为空，需要的最少步数，就是删除操作
        for i in range(1, n1 + 1):
            for j in range(1, n2 + 1):
                if word1[i-1] == word2[j-1]:
                    dp[i][j] = dp[i-1][j-1]
                else:
                    dp[i][j] = min(dp[i][j-1], dp[i-1][j], dp[i-1][j-1] ) + 1 #dp[i-1][j-1] 表示替换操作，dp[i-1][j] 表示删除操作，dp[i][j-1] 表示插入操作
        #print(dp)
        return dp[-1][-1]

"""
输入
输入的第一行是序列的长度N (1 <= N <= 1000)。第二行给出序列中的N个整数，这些整数的取值范围都在0到10000。
输出
最长上升子序列的长度。[b1 < b2 < ... < bS的时候，我们称这个序列是上升的。]

样例输入
7
1 7 3 5 9 4 8
样例输出
4
"""
"""
dp[i] 表示以第 i 个元素结尾的最长上升子序列的长度。
"""
n = int(input())
a = list(map(int, input().split()))

dp = [1] * n

for i in range(n):
    for j in range(i):
        if a[j] < a[i]:
            dp[i] = max(dp[i], dp[j] + 1)

print(max(dp))

"""
子序列：不用连续，但元素顺序要一致
输入中的每个数据集包含表示给定序列的两个字符串。序列由任意数量的空白字符分隔。
对于每组数据，打印最大长度公共子序列的长度，每行一个。

样例输入
abcfbc         abfcab
programming    contest
abcd           mnp
样例输出
4
2
0
"""
"""
dp[i][j]：长度为[0, i - 1]的字符串text1与长度为[0, j - 1]的字符串text2的最长公共子序列的长度

两大情况： text1[i - 1] 与 text2[j - 1]相同，text1[i - 1] 与 text2[j - 1]不相同

如果text1[i - 1] 与 text2[j - 1]相同，那么找到了一个公共元素，所以dp[i][j] = dp[i - 1][j - 1] + 1
如果text1[i - 1] 与 text2[j - 1]不相同，那就看看text1[0, i - 2]与text2[0, j - 1]的最长公共子序列 和 text1[0, i - 1]与text2[0, j - 2]的最长公共子序列，取最大的。
    即：dp[i][j] = max(dp[i - 1][j], dp[i][j - 1]);
"""
def longestCommonSubsequence(text1, text2):
    # 创建一个二维数组 dp，用于存储最长公共子序列的长度
    dp = [[0] * (len(text2) + 1) for _ in range(len(text1) + 1)]

    # 遍历 text1 和 text2，填充 dp 数组
    for i in range(1, len(text1) + 1):
        for j in range(1, len(text2) + 1):
            if text1[i - 1] == text2[j - 1]:
                dp[i][j] = dp[i - 1][j - 1] + 1
            else:
                dp[i][j] = max(dp[i - 1][j], dp[i][j - 1])

    # 返回最长公共子序列的长度
    return dp[len(text1)][len(text2)]

import sys
for line in sys.stdin:
    text1, text2 = line.split()
    print(longestCommonSubsequence(text1, text2))

"""
描述
一共有n种硬币，每种只有一个：面值分别为a1,a2… an。 求为了凑成X元哪些硬币是必须被使用的
输入
第一行包含两个正整数n和x。（1 <= n <= 200, 1 <= x <= 10000)
第二行从小到大为n个正整数a1, a2, a3 … an （1 <= ai <= 10000)
输出
第一行是一个整数，即有多少种硬币是必须被使用的。
第二行是这些必须使用的硬币的面值（从小到大排列）。
样例输入
5 18
1 2 3 5 10
样例输出
2
5 10
提示
输入数据将保证给定面值的硬币中至少有一种组合能恰好能够支付X元。
如果不存在必须被使用的硬币，则第一行输出0，第二行输出空行。
"""
n, x = map(int, input().split())
coins = list(map(int, input().split()))
#dp[s] 表示：凑出金额 s 的所有方案中，哪些硬币是“共同用到的”
dp = {}
dp[0] = set()  # 初始状态：0元，使用空硬币集合

for coin in coins: # 因为当前dp是选择这个coin之前的dp，下面s要在当前dp中遍历，更改dp，s只能是当前dp中的s,不能是新加入的，因此要浅拷贝【浅拷贝后的 current_dp 和 dp 是两个独立的字典对象】，current_dp = dp不是浅拷贝，而是引用赋值，会指向完全同一个字典对象，没有创建副本。
    current_dp = dict(dp)
    for s in current_dp: #遍历所有当前已知金额组合
        new_sum = s + coin #当前已有金额 s，加上这个 coin 后会变成 new_sum
        if new_sum > x: #如果它超过目标金额 x，就跳过。
            continue
        new_set = current_dp[s] | {coin} #构成这种new_sum的硬币集合
        if new_sum in dp:
            dp[new_sum] = dp[new_sum] & new_set  # 保留多个方案中共同必须使用的硬币
        else:
            dp[new_sum] = new_set

# 输出结果
if x in dp:
    must_use = sorted(dp[x])
    print(len(must_use))
    if must_use:
        print(' '.join(map(str, must_use)))
else:
    print(0)
    print()

"""
你每个月可以选择在北京或南京工作,每当你从一个城市换到另一个城市，需要支付一次交通费M
请规划每个月在哪个城市工作，使总收入最大。

**输入格式**：
- 第一行两个整数：T（总月数）和 M（交通费）。
- 接下来的 T行，每行两个整数分别表示第i月在北京或南京工作的收入。
**输出格式**：
- 一行一个整数，表示最大总收入。

样例输入
4 3
10 9
2 8
9 5
8 2
样例输出
31
"""
"""
dp_b[i]: 第 i 月在北京办公时可获得的最大收入。
dp_n[i]: 第 i 月在南京办公时可获得的最大收入。
"""
T, M = map(int, input().split())
P = [0]  # P[1..T]
N = [0]  # N[1..T]
for _ in range(T):
    p, n = map(int, input().split())
    P.append(p)
    N.append(n)

dp_b = [0] * (T + 1)
dp_n = [0] * (T + 1)

dp_b[1] = P[1]
dp_n[1] = N[1]

for i in range(2, T + 1):
    dp_b[i] = max(dp_b[i - 1], dp_n[i - 1] - M) + P[i]
    dp_n[i] = max(dp_n[i - 1], dp_b[i - 1] - M) + N[i]

print(max(dp_b[T], dp_n[T]))

"""
给定 T 组数据，每组包含 N 个由 AGCT 组成的基因片段（N≤9），求能包含所有片段的最短 DNA 单链长度。单链中基因片段可重叠（顺序不变，不可倒置），需计算满足条件的最短单链长度。
**输入：**
- 第一行 T 为数据组数。
- 每组数据第一行 N 为基因片段数，接下来 N 行每行一个基因片段。
**输出**：
每组数据输出包含所有基因片段的最短单链长度。
**样例输入**：
1
5
TCGG
GCAG
CCGC
GATC
ATCG
样例输出：
11
"""
import sys


def calculate_overlap(s1, s2):
    """
    计算s1的后缀与s2的前缀的最大重叠长度。
    """
    max_overlap = 0
    for i in range(1, min(len(s1), len(s2)) + 1):
        # 检查s1的最后i个字符是否与s2的前i个字符相同
        if s1[-i:] == s2[:i]:
            max_overlap = i
    return max_overlap


def solve():
    T = int(sys.stdin.readline())
    results = []

    for _ in range(T):
        N = int(sys.stdin.readline())
        fragments = []
        for i in range(N):
            fragments.append(sys.stdin.readline().strip())

        # Step 1: 消除冗余基因片段
        # is_redundant[i] 为 True 表示第 i 个片段是冗余的
        is_redundant = [False] * N
        for i in range(N):
            for j in range(N):
                if i == j:
                    continue
                # 如果 fragments[i] 包含 fragments[j]，则 fragments[j] 是冗余的
                if fragments[i].find(fragments[j]) != -1:
                    is_redundant[j] = True

        # 过滤掉冗余片段
        filtered_fragments = [fragments[i] for i in range(N) if not is_redundant[i]]

        # 如果所有片段都被过滤掉（极端情况，所有片段都被包含），或者只剩下一个，直接返回最长片段的长度
        if not filtered_fragments:
            results.append(0)
            continue
        if len(filtered_fragments) == 1:
            results.append(len(filtered_fragments[0]))
            continue

        num_fragments = len(filtered_fragments)

        # Step 2: 计算任意两个基因片段之间的最大重叠长度
        # overlap_matrix[i][j] 表示 filtered_fragments[i] 的后缀与 filtered_fragments[j] 的前缀的最大重叠长度
        overlap_matrix = [[0] * num_fragments for _ in range(num_fragments)]
        for i in range(num_fragments):
            for j in range(num_fragments):
                if i == j:
                    continue
                overlap_matrix[i][j] = calculate_overlap(filtered_fragments[i], filtered_fragments[j])

        # Step 3: 状态压缩动态规划 (TSP)
        # dp[mask][last_node] 表示访问了 mask 中所有片段，且 last_node 是最后一个访问片段时的最小总长度
        # 初始化 dp 数组为无穷大
        INF = float('inf')
        dp = [[INF] * num_fragments for _ in range(1 << num_fragments)]

        # 初始化起始状态：以每个片段作为第一个片段
        for i in range(num_fragments):
            dp[1 << i][i] = len(filtered_fragments[i])

        # 遍历所有可能的 mask (从只包含一个片段的 mask 开始)
        for mask in range(1, 1 << num_fragments):
            # 遍历 mask 中的每个 last_node
            for last_node in range(num_fragments):
                if not (mask & (1 << last_node)):  # 如果 last_node 不在当前 mask 中，跳过
                    continue

                if dp[mask][last_node] == INF:  # 如果当前状态不可达，跳过
                    continue

                # 遍历所有尚未访问的 next_node
                for next_node in range(num_fragments):
                    # 如果 next_node 已经在 mask 中，或者 next_node 就是 last_node，跳过
                    if (mask & (1 << next_node)):
                        continue

                    # 计算新的 mask
                    new_mask = mask | (1 << next_node)

                    # 计算从 last_node 到 next_node 所需的额外长度
                    # 新片段长度 - 重叠长度
                    added_length = len(filtered_fragments[next_node]) - overlap_matrix[last_node][next_node]

                    # 更新 dp 值
                    dp[new_mask][next_node] = min(dp[new_mask][next_node], dp[mask][last_node] + added_length)

        # 找到最终答案：所有片段都被访问 (mask 为 (1 << num_fragments) - 1)
        final_mask = (1 << num_fragments) - 1
        min_total_length = INF

        for last_node in range(num_fragments):
            min_total_length = min(min_total_length, dp[final_mask][last_node])

        results.append(min_total_length)

    sys.stdout.write("\n".join(map(str, results)) + "\n")


solve()

# O(n)将两个有序序列合并为一个
n = int(input())
list_a=list(map(int,input().split()))
list_b=list(map(int,input().split()))

i=j=0
result =[]
while i<=(n-1) and j<=(n-1):
    a=list_a[i]
    b=list_b[j]
    if a <= b:
        result.append(a)
        i+=1
    else:
        result.append(b)
        j+=1


result.extend(list_a[i:])
result.extend(list_b[j:])

print(" ".join(map(str,result)))

"""
第一行：两个整数 n 和 k，分别表示牛的总数和需要选出的前 k 头牛（第一轮晋级者数量）
接下来的 n 行：每行两个整数 a 和 b，表示每头牛的两项属性值（假设为 “属性 A” 和 “属性 B”）。

第一轮按a筛选 选出最高的k个，第二轮在k个中找b最大的编号
"""
n, k = map(int, input().split())

cows = []  # 存储 (编号, A, B)
for i in range(1, n + 1):
    a, b = map(int, input().split())
    cows.append((i, a, b))

# 按照 A 值排序，选出前 K 头牛（第一轮晋级者）
cows.sort(key=lambda x: -x[1])
top_k = cows[:k]

# 在 top_k 中找 B 值最大的牛
winner = max(top_k, key=lambda x: x[2])

print(winner[0])  # 输出编号

"""
总时间限制: 1000ms 内存限制: 65536kB

将一些整数从小到大排序

输入
有多组数据
每组数据两行。第一行是整数n(n<30000)表示有n个整数要排序
第二行是n个整数，整数绝对值不超过30000
n = 0时表示输入数据结束
输出
对每组数据输出排序结果
样例输入
2
1 2
3
3 2 1
0
样例输出
1 2
1 2 3
"""
while True:
    n = int(input())
    if n == 0:
        break
    numbers = list(map(int, input().split()))
    sorted_numbers = sorted(numbers)
    print(' '.join(map(str, sorted_numbers)))

"""
题目描述

给定 N 个蚂蚁的速度序列（按初始位置从前到后排列），每个蚂蚁以恒定速度向同一方向移动。若前面的蚂蚁速度小于后面的蚂蚁，则后面的蚂蚁会赶超前面的，形成一对 “赶超事件”。求总共有多少对这样的事件。

输入
第一行：整数 N（2 ≤ N ≤ 1e5）。
接下来 N 行：每行一个非负整数，表示每个蚂蚁的速度（按初始顺序从前到后给出）。
输出
一个整数，表示赶超事件的总对数。
样例输入
5
1
5
10
7
6

5
1
5
5
7
6
样例输出
7

8
"""
def mergeSort(nums,tmp,l,r):
    if l>=r:
        return 0

    mid = (l+r)//2
    count = mergeSort(nums,tmp,l,mid)+mergeSort(nums,tmp,mid+1,r)

    i,j,pos=l,mid+1,l
    while i <= mid and j <= r:
        if nums[i]<nums[j]:
            tmp[pos]=nums[i]
            count+= r-j+1
            i+=1
        else:
            tmp[pos]=nums[j]
            j+=1
        pos+=1

    for k in range(i,mid+1):
        tmp[pos] = nums[k]
        pos+=1

    for k in range(j,r+1):
        tmp[pos] = nums[k]
        pos+=1

    nums[l:r+1]=tmp[l:r+1]
    return count

def main():
    N = int(input())
    tmp=[0]*N
    nums = []
    for i in range(N):
        nums.append(int(input()))
    print(mergeSort(nums,tmp,0,N-1))

if __name__ =="__main__":
    main()

"""
在数轴上，给定起点N(0<=N<=100000)和终点K(0<=K<=100000)，每次可选择以下三种移动方式之一：
    向左移动 1 步（X→X−1）
    向右移动 1 步（X→X+1）
    teleport 到当前位置的 2 倍（X→2X）
求从 N到 K的最短移动次数。

样例输入
5 17
样例输出
4
"""

from collections import deque

def minTimeToCatchTheCow(N, K):
    queue = deque([(N, 0)])  # (位置, 时间)
    visited = set([N]) #此时visited不是[N] 而是{N}
    #set而非数组（如visited = [False] * 100001）因为当K较小时（如K=10），使用数组需要预分配大小为100001的空间，浪费内存。同时set的查找操作平均时间复杂度为 O(1）

    while queue:
        x, time = queue.popleft()
        if x == K:
            return time
        for next_x in [x - 1, x + 1, 2 * x]:
            if 0 <= next_x <= 100000 and next_x not in visited:
                visited.add(next_x)
                queue.append((next_x, time + 1))

N, K = map(int,input().split())
print(minTimeToCatchTheCow(N, K))

"""
在数轴上，从起点 n 出发，每次可进行以下操作之一：

H 操作：跳至当前位置的 3 倍坐标（x → 3x）。
O 操作：跳至当前位置折半并向下取整的坐标（x → x//2）。
求到达终点 m 的最少操作次数，若存在多种方案，选择字典序最小的操作序列（H 的字典序小于 O）。
"""
import heapq


def minimal_steps(n, m):
    if n == m:
        return 0, ""

    visited = {n: ""}  # 记录到达每个位置的最小字典序路径
    heap = []
    heapq.heappush(heap, (0, n, ""))  # (步数, 当前位置, 路径)

    while heap:
        steps, pos, path = heapq.heappop(heap)

        if pos == m:
            return steps, path

        # 优先尝试H（乘法），因为H字典序更小
        next_h = pos * 3
        new_path_h = path + 'H'
        if next_h not in visited or len(new_path_h) < len(visited[next_h]) or (
                len(new_path_h) == len(visited[next_h]) and new_path_h < visited[next_h]):
            visited[next_h] = new_path_h
            heapq.heappush(heap, (steps + 1, next_h, new_path_h))

        # 尝试O（除法）
        next_o = pos // 2
        new_path_o = path + 'O'
        if next_o not in visited or len(new_path_o) < len(visited[next_o]) or (
                len(new_path_o) == len(visited[next_o]) and new_path_o < visited[next_o]):
            visited[next_o] = new_path_o
            heapq.heappush(heap, (steps + 1, next_o, new_path_o))

    return -1, ""  # 题目保证有解，不会执行到这行


# 处理输入输出
import sys

for line in sys.stdin:
    line = line.strip()
    if not line:
        continue
    n, m = map(int, line.split())
    if n == 0 and m == 0:
        break
    steps, path = minimal_steps(n, m)
    print(steps)
    print(path)

"""
给定多个牢房矩阵，每个矩阵中包含骑士（r）、公主（a）、道路（@）、守卫（x）和墙壁（#）。骑士需从r出发，移动至a的位置，移动规则如下：

移动至相邻格子（上下左右）耗时 1 单位时间。
若移动至守卫（x）所在格子，需额外花费 1 单位时间（总耗时 + 2）。
墙壁（#）不可通行。
求骑士到达公主位置的最短时间，若无法到达则输出 "Impossible"。

输入
第一行：测试用例数S。
每组用例：
第一行：矩阵行数N和列数M。
接下来N行：每行M个字符，表示牢房布局（保证有且仅有一个r和一个a）。

输出
每组用例输出最短时间，若无法到达则输出 "Impossible"。

样例输入
2
7 8
#@#####@
#@a#@@r@
#@@#x@@@
@@#@@#@#
#@@@##@@
@#@@@@@@
@@@@@@@@
13 40
@x@@##x@#x@x#xxxx##@#x@x@@#x#@#x#@@x@#@x
xx###x@x#@@##xx@@@#@x@@#x@xxx@@#x@#x@@x@
#@x#@x#x#@@##@@x#@xx#xxx@@x##@@@#@x@@x@x
@##x@@@x#xx#@@#xxxx#@@x@x@#@x@@@x@#@#x@#
@#xxxxx##@@x##x@xxx@@#x@x####@@@x#x##@#@
#xxx#@#x##xxxx@@#xx@@@x@xxx#@#xxx@x#####
#x@xxxx#@x@@@@##@x#xx#xxx@#xx#@#####x#@x
xx##@#@x##x##x#@x#@a#xx@##@#@##xx@#@@x@x
x#x#@x@#x#@##@xrx@x#xxxx@##x##xx#@#x@xx@
#x@@#@###x##x@x#@@#@@x@x@@xx@@@@##@@x@@x
x#xx@x###@xxx#@#x#@@###@#@##@x#@x@#@@#@@
#@#x@x#x#x###@x@@xxx####x@x##@x####xx#@x
#x#@x#x######@@#x@#xxxx#xx@@@#xx#x#####@
样例输出
13
7
"""
"""
典型的带权最短路径问题，可以使用 Dijkstra 算法解决。
"""
import heapq
S = int(input())

for _ in range(S):
    N,M = map(int,input().split())
    grid = []
    for _ in range(N):
        line = input()
        grid.append(list(line))

    # 找到骑士和公主的位置
    r_x, r_y = -1, -1
    a_x, a_y = -1, -1
    for i in range(N):
        for j in range(M):
            if grid[i][j] == 'r':
                r_x, r_y = i, j
            elif grid[i][j] == 'a':
                a_x, a_y = i, j

    # 初始化距离数组
    INF = float('inf')
    dist = [[INF for _ in range(M)] for __ in range(N)]
    dist[r_x][r_y] = 0

    # 优先队列 (距离, x, y)
    heap = []
    heapq.heappush(heap, (0, r_x, r_y))

    # 方向数组
    dirs = [(-1, 0), (1, 0), (0, -1), (0, 1)]

    found = False

    while heap:
        current_dist, x, y = heapq.heappop(heap)

        # 如果到达公主位置，输出结果
        if x == a_x and y == a_y:
            print(current_dist)
            found = True
            break

        # 如果当前距离大于已记录的最小距离，跳过
        if current_dist > dist[x][y]:
            continue

        # 尝试四个方向
        for dx, dy in dirs:
            nx = x + dx
            ny = y + dy

            # 检查边界和墙壁
            if nx < 0 or nx >= N or ny < 0 or ny >= M:
                continue
            if grid[nx][ny] == '#':
                continue

            # 计算移动到新位置的时间
            if grid[nx][ny] == 'x':
                time = 2
            else:
                time = 1

            new_dist = current_dist + time

            # 如果新路径更短，更新距离并加入队列
            if new_dist < dist[nx][ny]:
                dist[nx][ny] = new_dist
                heapq.heappush(heap, (new_dist, nx, ny))

    # 如果没有找到路径
    if not found:
        print("Impossible")

"""
输入
一个整数N，表示要把N个皇后摆放在一个N行N列的国际象棋棋盘上【不能同行同列同对角线】
输出
所有的摆放放案。每个方案一行，依次是第0行皇后位置、第1行皇后位置......第N-1行皇后位置。
多种方案输出顺序如下：优先输出第0行皇后列号小的方案。如果两个方案第0行皇后列号一致，那么优先输出第1行皇后列号小的方案......以此类推
样例输入
4
样例输出
1 3 0 2
2 0 3 1
"""
class Solution:
    def solveQueens(self,N):
        chessboard=["*"*N for _ in range(N)]
        result=[]
        self.backtracking(N,0,chessboard,result)
        return result
    def backtracking(self,N,row,chessboard,result):
        if row==N:
            solu=[]
            for r in range(N):
                for c in range(N):
                    if chessboard[r][c]=="Q":
                        solu.append(c)
            result.append(solu)
            return
        for col in range(N):
            if self.isValid(row,col,chessboard):
                chessboard[row]=chessboard[row][:col]+"Q"+chessboard[row][col+1:]
                self.backtracking(N,row+1,chessboard,result)
                chessboard[row]=chessboard[row][:col]+"."+chessboard[row][col+1:]

    def isValid(self,row,col,chessboard):
        if chessboard[row][col] == "Q":
            return False

        for i in range(row):
            if chessboard[i][col] == "Q":
                return False

        i,j=row-1,col-1
        while i >= 0 and j >=0 :
            if chessboard[i][j]=='Q':
                return False
            i-=1
            j-=1

        i,j=row-1,col+1
        while i >=0 and j<len(chessboard):
            if chessboard[i][j]=='Q':
                return False
            i-=1
            j+=1
        return True
S=Solution()
N=int(input())
result=S.solveQueens(N)
if result:
    result.sort()
    for solution in result:
        print(" ".join(map(str,solution)))
else:
        print("NO ANSWER")

"""输出 [[".Q..","...Q","Q...","..Q."],["..Q.","Q...","...Q",".Q.."]]"""
class Solution:
    def solveNQueens(self, n):
        result = []  # 存储最终结果的二维字符串数组

        chessboard = ['.' * n for _ in range(n)]  # 初始化棋盘
        self.backtracking(n, 0, chessboard, result)  # 回溯求解
        return [[''.join(row) for row in solution] for solution in result]  # 返回结果集

    def backtracking(self, n, row, chessboard, result):
        if row == n:
            result.append(chessboard[:])  # 棋盘填满，将当前解加入结果集
            return

        for col in range(n):
            if self.isValid(row, col, chessboard):
                chessboard[row] = chessboard[row][:col] + 'Q' + chessboard[row][col+1:]  # 放置皇后
                self.backtracking(n, row + 1, chessboard, result)  # 递归到下一行
                chessboard[row] = chessboard[row][:col] + '.' + chessboard[row][col+1:]  # 回溯，撤销当前位置的皇后

    def isValid(self, row, col, chessboard):
        # 检查列
        for i in range(row):
            if chessboard[i][col] == 'Q':
                return False  # 当前列已经存在皇后，不合法

        # 检查 45 度角是否有皇后
        i, j = row - 1, col - 1
        while i >= 0 and j >= 0:
            if chessboard[i][j] == 'Q':
                return False  # 左上方向已经存在皇后，不合法
            i -= 1
            j -= 1

        # 检查 135 度角是否有皇后
        i, j = row - 1, col + 1
        while i >= 0 and j < len(chessboard):
            if chessboard[i][j] == 'Q':
                return False  # 右上方向已经存在皇后，不合法
            i -= 1
            j += 1

        return True  # 当前位置合法

s=Solution()
print(s.solveNQueens(8))

class Solution:
    def solveNQueens(self, n):
        result = []
        chessboard = ['.' * n for _ in range(n)]
        self.backtracking(n, 0, chessboard, result)
        return result

    def backtracking(self, n, col, chessboard, result):
        if col == n:
            result.append(chessboard[:])
            return

        for row in range(n):
            if self.isValid(row, col, chessboard):
                chessboard[row] = chessboard[row][:col] + 'Q' + chessboard[row][col+1:]
                self.backtracking(n, col + 1, chessboard, result)
                chessboard[row] = chessboard[row][:col] + '.' + chessboard[row][col+1:]

    def isValid(self, row, col, chessboard):
        # 检查该行是否已有皇后
        for j in range(col):
            if chessboard[row][j] == 'Q':
                return False
        # 检查左上对角线
        i, j = row - 1, col - 1
        while i >= 0 and j >= 0:
            if chessboard[i][j] == 'Q':
                return False
            i -= 1
            j -= 1
        # 检查左下对角线
        i, j = row + 1, col - 1
        while i < len(chessboard) and j >= 0:
            if chessboard[i][j] == 'Q':
                return False
            i += 1
            j -= 1
        return True

# 执行并格式化输出
s = Solution()
solutions = s.solveNQueens(8)

for idx, solution in enumerate(solutions, 1):
    print(f"No. {idx}")
    for row in solution:
        print(' '.join(['1' if ch == 'Q' else '0' for ch in row]))

"""
No. 1
1 0 0 0 ...
0 0 0 1 ...
...
"""

# 逐行放置
class Solution:
    def solveNQueens(self, n):
        result = []  # 存储所有合法解
        chessboard = ['.' * n for _ in range(n)]  # 初始化棋盘
        self.backtracking(n, 0, chessboard, result)  # 开始回溯
        return result  # 每个解是一个n行字符串列表

    def backtracking(self, n, row, chessboard, result):
        if row == n:
            result.append(chessboard[:])  # 保存当前棋盘状态
            return

        for col in range(n):
            if self.isValid(row, col, chessboard):
                # 放置皇后
                chessboard[row] = chessboard[row][:col] + 'Q' + chessboard[row][col+1:]
                self.backtracking(n, row + 1, chessboard, result)
                # 回溯，移除皇后
                chessboard[row] = chessboard[row][:col] + '.' + chessboard[row][col+1:]

    def isValid(self, row, col, chessboard):
        # 检查列
        for i in range(row):
            if chessboard[i][col] == 'Q':
                return False
        # 检查左上对角线
        i, j = row - 1, col - 1
        while i >= 0 and j >= 0:
            if chessboard[i][j] == 'Q':
                return False
            i -= 1
            j -= 1
        # 检查右上对角线
        i, j = row - 1, col + 1
        while i >= 0 and j < len(chessboard):
            if chessboard[i][j] == 'Q':
                return False
            i -= 1
            j += 1
        return True

# 执行并格式化输出
s = Solution()
solutions = s.solveNQueens(8)

for idx, solution in enumerate(solutions, 1): #同时获取每个解的编号（从 1 开始）
    print(f"No. {idx}")
    for row in solution:
        print(' '.join(['1' if ch == 'Q' else '0' for ch in row]))

"""
在一个 4x4 的棋盘上，每个格子放置一个双面棋子（一面黑b，一面白w）。每次操作可选择一个格子，翻转该格子及其上下左右相邻格子（共 3-5 个格子，若存在相邻格子）。目标是通过最少操作次数，将所有棋子变为全白或全黑。若无法实现，输出 "Impossible"。
样例输入
bwwb
bbwb
bwwb
bwww
样例输出
4
"""
from collections import deque

def board_to_int(board):
    res = 0
    for i in range(4):
        for j in range(4):
            if board[i][j] == 'b':
                res |= 1 << (i * 4 + j)
    return res

def generate_flip_masks():
    masks = []
    for i in range(4):
        for j in range(4):
            mask = 0
            for dx, dy in [(-1,0), (1,0), (0,-1), (0,1), (0,0)]:
                nx, ny = i + dx, j + dy
                if 0 <= nx < 4 and 0 <= ny < 4:
                    mask |= 1 << (nx * 4 + ny)
            masks.append(mask)
    return masks

def bfs(start):
    target1 = 0
    target2 = 0xFFFF  # 16个1的二进制
    if start in (target1, target2):
        return 0

    visited = set()
    queue = deque([(start, 0)])
    visited.add(start)
    flip_masks = generate_flip_masks()

    while queue:
        current, steps = queue.popleft()
        for mask in flip_masks:
            new_state = current ^ mask
            if new_state in (target1, target2):
                return steps + 1
            if new_state not in visited:
                visited.add(new_state)
                queue.append((new_state, steps + 1))
    return "Impossible"

def main():
    board = [list(input().strip()) for _ in range(4)]
    start = board_to_int(board)
    print(bfs(start))

if __name__ == "__main__":
    main()

"""
描述
在一个给定形状的棋盘（形状可能是不规则的）上面摆放棋子，棋子没有区别。要求摆放时任意的两个棋子不能放在棋盘中的同一行或者同一列，请编程求解对于给定形状和大小的棋盘，摆放k个棋子的所有可行的摆放方案C。
输入
输入含有多组测试数据。
每组数据的第一行是两个正整数，n k，用一个空格隔开，表示了将在一个n*n的矩阵内描述棋盘，以及摆放棋子的数目。 n <= 8 , k <= n
当为-1 -1时表示输入结束。
随后的n行描述了棋盘的形状：每行有n个字符，其中 # 表示棋盘区域， . 表示空白区域（数据保证不出现多余的空白行或者空白列）。
输出
对于每一组数据，给出一行输出，输出摆放的方案数目C （数据保证C<2^31）。

样例输入
2 1
#.
.#
4 4
...#
..#.
.#..
#...
-1 -1
样例输出
2
1
"""
def dfs(row, count, n, k, board, col_used):
    if count == k:
        return 1  # 成功放置了 k 个棋子
    if row >= n:
        return 0  # 行数越界，回溯
    total = 0
    for j in range(n):
        if board[row][j] == '#' and not col_used[j]:
            col_used[j] = True
            total += dfs(row + 1, count + 1, n, k, board, col_used)
            col_used[j] = False  # 回溯
    # 也可以不在当前行放棋子，直接跳到下一行
    total += dfs(row + 1, count, n, k, board, col_used)
    return total


while True:
    n, k = map(int, input().split())
    if n == k == -1:
        break
    board = [input().strip() for _ in range(n)]
    col_used = [False] * n
    result = dfs(0, 0, n, k, board, col_used)
    print(result)


"""
描述
有一个方格矩阵，矩阵边界在无穷远处。我们做如下假设：
a.    每走一步时，只能从当前方格移动一格，走到某个相邻的方格上；
b.    走过的格子立即塌陷无法再走第二次；
c.    只能向北、东、西三个方向走；
请问：如果允许在方格矩阵上走n步，共有多少种不同的方案。2种走法只要有一步不一样，即被认为是不同的方案。

输入
允许在方格上行走的步数n(n <= 20)
输出
计算出的方案数量
样例输入
2
样例输出
7
"""

def count_paths(n):
    visited = set()
    directions = [(-1, 0), (0, 1), (0, -1)]  # 北、东、西方向

    def dfs(x, y, step):
        if step == n:
            return 1  # 成功走了n步，返回1种方案
        total = 0
        for dx, dy in directions:
            nx, ny = x + dx, y + dy
            if (nx, ny) not in visited:
                visited.add((nx, ny))
                total += dfs(nx, ny, step + 1)
                visited.remove((nx, ny))  # 回溯
        return total

    visited.add((0, 0))
    return dfs(0, 0, 0)

# 输入读取
n = int(input())
print(count_paths(n))


"""
描述
马在中国象棋以日字形规则移动。

请编写一段程序，给定n*m大小的棋盘，以及马的初始位置(x，y)，要求不能重复经过棋盘上的同一个点，计算马可以有多少途径遍历棋盘上的所有点。

输入
第一行为整数T(T < 10)，表示测试数据组数。
每一组测试数据包含一行，为四个整数，分别为棋盘的大小以及初始位置坐标n,m,x,y。(0<=x<=n-1,0<=y<=m-1, m < 10, n < 10)
输出
每组测试数据包含一行，为一个整数，表示马能遍历棋盘的途径总数，0为无法遍历一次。
样例输入
1
5 4 0 0
样例输出
32
"""
# 马的八个移动方向
dx = [1, 2, 2, 1, -1, -2, -2, -1]
dy = [2, 1, -1, -2, -2, -1, 1, 2]

def count_tours(n, m, x, y):
    visited = [[False] * m for _ in range(n)]
    total_cells = n * m
    result = [0]
    """
    如果你在 内层函数（如 DFS） 中想修改一个外部变量,如果这个变量是 不可变类型（如 int），你无法直接修改它,如果是 可变类型（如 list），你可以通过引用修改它的内容。
    """
    def dfs(i, j, step):
        if step == total_cells:
            result[0] += 1
            return
        for k in range(8):
            ni, nj = i + dx[k], j + dy[k]
            if 0 <= ni < n and 0 <= nj < m and not visited[ni][nj]:
                visited[ni][nj] = True
                dfs(ni, nj, step + 1)
                visited[ni][nj] = False  # 回溯

    visited[x][y] = True
    dfs(x, y, 1) #这里的step是经历过的点数
    return result[0]

# 处理输入
T = int(input())
for _ in range(T):
    n, m, x, y = map(int, input().split())
    print(count_tours(n, m, x, y))

"""
描述
N*N(2 <= N <= 20)的迷宫
从左上角(0, 0)处的入口跑到右下角(N-1, N-1)处
只会向右和向下走
我们知道迷宫的地图（以0代表通路，以1代表障碍）
判断能否从入口跑到出口

输入
第一行为一个整数N，代表迷宫的大小
接下来N行为迷宫地图，迷宫地块之间以空格分隔
输入保证(0, 0)和(N - 1, N - 1)处可以通过
输出
一行字符串，如果能跑到出口则输出Yes，否则输出No
样例输入
5
0 0 1 1 0
0 0 0 0 0
0 1 1 1 0
0 1 1 1 0
0 1 1 1 0
样例输出
Yes
提示
用递归解。设计函数ok(r,c)，返回True或False，表示从位置(r,c)出发能否走到终点。
从(r,c）出发可以想办法往前走一步，然后看问题变成什么

题目说了只能走到0的格子，不能走到1的格子
"""
def find_path(x, y):
    if x >= N or y >= N or maze[x][y] == 1:
        return False
    if (x == N - 1 and y == N - 2) or (x == N - 2 and y == N - 1): #最后终点肯定是0，判断上一步
        return True
    else:
        return find_path(x + 1, y) or find_path(x, y + 1)


N = int(input())
maze = []
for i in range(N):
    maze.append(list(map(int,input().split())))
if find_path(0, 0):
    print("Yes")
else:
    print("No")

"""
'.'是可以走的空地，'#’是不能走的墙壁。迷宫入口在左上角，出口在右下角。只能往上下左右四个方向的空地走。出口和入口一定是空地。问从入口是否可以走到出口。
输入
第一行是整数n,m,( 0 < m ,n < 20)表示迷宫字符矩阵有n行m列。接下来就是n行m列的字符矩阵。
输出
如果可以走到出口，输出1，否则输出0。
样例输入
6 8
.#######
........
.#.#.##.
.#....#.
.####.#.
........
样例输出
7
"""
directions = [(-1,0),(1,0),(0,-1),(0,1)]

def dfs(x, y):
    if x == N - 1 and y == M - 1:
        return True

    visited[x][y] = True
    for dx, dy in directions:
        nx, ny = x + dx, y + dy
        if 0 <= nx < N and 0 <= ny < M and not visited[nx][ny] and maze[nx][ny] == '.':
            if dfs(nx, ny):
                return True
    return False

N, M = map(int, input().split())
maze = [list(input()) for _ in range(N)]

visited = [[False]*M for _ in range(N)]

if dfs(0, 0):
    print(1)
else:
    print(0)

"""
描述：
在一个 N×N 的矩阵宫殿中，孙悟空（K）需从起点出发，收集所有 M 种钥匙（按 1 到 M 的顺序获取），杀死路径上的蛇（S），最终到达唐僧（T）的位置。矩阵中，'#' 为不可通过的致命房间，数字 '1'-'9' 代表对应种类的钥匙（需按顺序获取），'S' 房间需额外 1 分钟杀蛇。求从 K 到 T 的最短时间，若无法完成（如无法收集所有钥匙或无法到达）则输出 “impossible”。

输入：

每行先给出 N 和 M（N≤100，M≤9），随后是 N×N 的矩阵。
输入以 N=0 且 M=0 结束。

输出：

输出最短时间（分钟），若无法完成则输出 “impossible”。

样例输入
3 1
K.S
##1
1#T
3 1
K#T
.S#
1#.
3 2
K#T
.S.
21.
0 0
样例输出
5
impossible
8
"""

import heapq
import sys

input = sys.stdin.read
DIRS = [(-1, 0), (1, 0), (0, -1), (0, 1)]  # 4 个方向：上、下、左、右


class Node:
    def __init__(self, x, y, time, key, snake):
        self.x = x  # 当前位置
        self.y = y  # 当前位置
        self.time = time  # 从起点到当前状态的总耗费时间
        self.key = key  # 表示已按序获得的最高钥匙等级。
        self.snake = snake  # 当前杀死的蛇的状态（用 bitmask 记录）这是一个整数，其二进制位表示对应编号的蛇是否已被杀死。例如，如果第0条蛇和第2条蛇被杀死，则 snake = (1<<0) | (1<<2) = 1 | 4 = 5

    def __lt__(self, other):
        return self.time < other.time  #确保每次弹出的是 time 值最小的 Node


def bfs(maze, N, M):
    # 记录初始位置和蛇的位置
    x0, y0, snake_count = 0, 0, 0
    snake_map = [[-1] * N for _ in range(N)]  #  记录每条蛇在 grid 中的唯一 ID
    for i in range(N):
        for j in range(N):
            if maze[i][j] == 'K':  # 孙悟空的起点
                x0, y0 = i, j
            elif maze[i][j] == 'S':  # 找到蛇，并给它分配一个从 0 开始的 ID
                snake_map[i][j] = snake_count
                snake_count += 1

    # Dijkstra 需要的优先队列
    queue = []
    heapq.heappush(queue, Node(x0, y0, 0, 0, 0))

    # 记录访问状态：memo[x][y][key_count] 表示在 (x, y) 拥有 key_count 把钥匙的最短时间
    INF = float('inf')
    memo = [[[INF] * (M + 1) for _ in range(N)] for _ in range(N)]
    memo[x0][y0][0] = 0  # 初始状态

    while queue:
        node = heapq.heappop(queue)

        # 遍历四个方向
        for dx, dy in DIRS:
            nx, ny = node.x + dx, node.y + dy
            if 0 <= nx < N and 0 <= ny < N:
                cell = maze[nx][ny]
                new_time = node.time + 1
                new_key = node.key
                new_snake_mask = node.snake

                if cell == '#':  # 死亡房间，不能进入
                    continue
                elif cell == 'S':  # 遇到蛇
                    snake_id = snake_map[nx][ny]
                    if (node.snake & (1 << snake_id)):  # 已杀死，正常通行
                        pass
                    else:  # 需要额外 1 分钟杀死蛇
                        new_time += 1
                        new_snake_mask |= (1 << snake_id)
                elif cell.isdigit():  # 遇到钥匙
                    key_id = int(cell)
                    if key_id == node.key + 1:  # 必须按顺序拾取
                        new_key += 1
                elif cell == 'T' and new_key == M:  # 唐僧，并且钥匙足够
                    return new_time

                # 如果新的状态更优，则更新
                if new_time < memo[nx][ny][new_key]:
                    memo[nx][ny][new_key] = new_time
                    heapq.heappush(queue, Node(nx, ny, new_time, new_key, new_snake_mask))

    return "impossible"  # 无法到达


# 读取输入
def main():
    input_data = input().strip().split("\n")
    index = 0
    results = []

    while index < len(input_data):
        # 读取 N, M
        N, M = map(int, input_data[index].split())
        if N == 0 and M == 0:
            break

        # 读取宫殿地图
        maze = [list(input_data[i]) for i in range(index + 1, index + 1 + N)]
        results.append(str(bfs(maze, N, M)))

        # 更新索引
        index += N + 1

    # 输出结果
    print("\n".join(results))


if __name__ == "__main__":
    main()

"""
描述
一个字符矩阵代表一个迷宫。'.'是可以走的空地，'#’是不能走的墙壁。迷宫入口在左上角，出口在右下角。只能往上下左右四个方向的空地走。出口和入口一定是空地。

求从入口到出口步数最少的走法。如果有不止一个答案，随便输出哪个答案都可以。如果走法不存在，则输出0。

输入
第一行是整数n,m,( 0 < m ,n < 20)表示迷宫字符矩阵有n行m列。接下来就是n行m列的字符矩阵。
输出
步数最少的走法。每步输出形式为:
(x,y)
表示走到第x行，第y列
将所有步骤输出在一行
样例输入
6 8
.#######
........
.#.#.##.
.#....#.
.####.#.
........
样例输出
(0,0)(1,0)(2,0)(3,0)(4,0)(5,0)(5,1)(5,2)(5,3)(5,4)(5,5)(5,6)(5,7)
"""
from collections import deque

def bfs(maze, n, m):
    # 初始化队列和访问记录
    queue = deque([(0, 0)])
    visited = [[False] * m for _ in range(n)]
    visited[0][0] = True
    prev = [[None] * m for _ in range(n)]

    # 方向向量
    directions = [(0, 1), (1, 0), (0, -1), (-1, 0)]

    while queue:
        x, y = queue.popleft()
        if (x, y) == (n-1, m-1):
            break
        for dx, dy in directions:
            nx, ny = x + dx, y + dy
            if 0 <= nx < n and 0 <= ny < m and maze[nx][ny] == '.' and not visited[nx][ny]:
                queue.append((nx, ny))
                visited[nx][ny] = True
                prev[nx][ny] = (x, y)

    # 回溯路径
    if prev[n-1][m-1] is not None: # 终点的前驱节点存在，说明有路径
        path = []
        x, y = n-1, m-1 # 从终点开始回溯
        while (x, y) != (0, 0): # 直到回到起点
            path.append((x, y))  # 记录当前节点
            x, y = prev[x][y]  # 跳到前驱节点
        path.append((0, 0)) # 加入起点
        path.reverse() # 反转路径，变成从起点到终点的顺序
        return path
    else:
        return [] # 无前驱节点，说明无法到达终点

def main():
    n, m = map(int, input().split())
    maze = [input() for _ in range(n)]
    path = bfs(maze, n, m)
    if path:
        print(''.join(f'({x},{y})' for x, y in path))
    else:
        print(0)

if __name__ == "__main__":
    main()

"""
题目描述
给定多个 R×C 的迷宫矩阵，每个矩阵中包含起点 S、终点 E、墙壁 #和可通行的.。阿尔吉侬从 S 出发，每次可向上下左右移动一格（不能穿墙或出界），求到达 E 的最短时间。若无法到达，输出 "oop!"。
输入

第一行：测试用例数 T。
每组用例：
第一行：R 和 C（行数和列数）。
接下来 R 行：每行 C 个字符表示迷宫，保证有且仅有一个 S 和 E。
输出
每组用例输出最短时间，无法到达则输出 "oop!"。
"""
from collections import deque

def solve_maze(grid, R, C):
    # 找到起点 S 和终点 E 的坐标
    start = None
    end = None
    for i in range(R):
        for j in range(C):
            if grid[i][j] == 'S':
                start = (i, j)
            elif grid[i][j] == 'E':
                end = (i, j)

    # 定义四个方向：上、下、左、右
    directions = [(-1, 0), (1, 0), (0, -1), (0, 1)]

    # 初始化队列和访问数组
    queue = deque()
    visited = [[False for _ in range(C)] for _ in range(R)]

    # 将起点加入队列并标记为已访问
    queue.append((start[0], start[1], 0))  # (x, y, steps)
    visited[start[0]][start[1]] = True

    while queue:
        x, y, steps = queue.popleft()

        # 如果到达终点，返回步数
        if (x, y) == end:
            return steps

        # 尝试四个方向
        for dx, dy in directions:
            nx = x + dx
            ny = y + dy

            # 检查是否越界
            if nx < 0 or nx >= R or ny < 0 or ny >= C:
                continue

            # 检查是否是墙或已访问
            if grid[nx][ny] == '#' or visited[nx][ny]:
                continue

            # 将新位置加入队列并标记为已访问
            queue.append((nx, ny, steps + 1))
            visited[nx][ny] = True

    # 无法到达终点
    return -1


# 读取输入
T = int(input())
for _ in range(T):
    R, C = map(int, input().split())
    grid = [input().strip() for _ in range(R)]

    # 求解迷宫
    result = solve_maze(grid, R, C)

    # 输出结果
    print(result if result != -1 else "oop!")

"""
描述
给定一个由 .（黑格）、#（红格）、@（起点黑格）组成的二维网格。你从 @ 所在位置出发，只能向上下左右相邻的黑格（即 .）移动，且不能重复经过同一位置。请计算从起点出发，最多能访问多少个黑格（包括起点）

输入
包括多个数据集合。每个数据集合的第一行是两个整数W和H，分别表示x方向和y方向瓷砖的数量。W和H都不超过20。在接下来的H行中，每行包括W个字符。每个字符表示一块瓷砖的颜色，规则如下
1）‘.’：黑色的瓷砖；
2）‘#’：红色的瓷砖；
3）‘@’：黑色的瓷砖，并且你站在这块瓷砖上。该字符在每个数据集合中唯一出现一次。
当在一行中读入的是两个零时，表示输入结束。
输出
对每个数据集合，分别输出一行，显示你从初始位置出发能到达的瓷砖数(记数时包括初始位置的瓷砖)。
样例输入
6 9
....#.
.....#
......
......
......
......
......
#@...#
.#..#.
0 0
样例输出
45
"""
def dfs(x, y):
    visited[x][y] = True
    cnt = 1
    for dx, dy in directions:
        nx, ny = x + dx,y + dy
        if 0 <= nx < H and 0 <= ny < W:
            if not visited[nx][ny] and grid[nx][ny] == ".":
                cnt += dfs(nx, ny)
    return cnt

while True:
    W, H = map(int, input().split())
    if W == 0 and H == 0:
        break

    grid = []
    start_x = start_y = -1

    for i in range(H):
        row = list(input())
        for j, ch in enumerate(row):
            if ch == '@':
                start_x, start_y = i, j
        grid.append(row)

    visited = [[False]*W for _ in range(H)]
    directions = [(1, 0), (-1, 0), (0, 1), (0, -1)]

    result = dfs(start_x, start_y)
    print(result)

"""
描述
任何一个正整数都可以用2的幂次方表示。例如：

    137=2^7+2^3+2^0

同时约定方次用括号来表示，即ab可表示为a(b)。由此可知，137可表示为：

    2(7)+2(3)+2(0)

进一步：7=22+2+20（21用2表示）

        3=2+20

所以最后137可表示为：

    2(2(2)+2+2(0))+2(2+2(0))+2(0)

又如：

    1315=210+28+25+2+1

所以1315最后可表示为：

    2(2(2+2(0))+2)+2(2(2+2(0)))+2(2(2)+2(0))+2+2(0)

输入
一个正整数n（n≤20000）。
输出
一行，符合约定的n的0，2表示（在表示中不能有空格）。
样例输入
137
样例输出
2(2(2)+2+2(0))+2(2+2(0))+2(0)
"""

def convert(n):
    if n == 0:
        return "0"
    if n == 1:
        return "2(0)"
    if n == 2:
        return "2"

    res = []
    power = 0
    while n > 0:
        if n % 2 == 1:
            if power == 0:
                res.append("2(0)")
            elif power == 1:
                res.append("2")
            else:
                res.append(f"2({convert(power)})")
        n //= 2
        power += 1
    return '+'.join(reversed(res))


n = int(input())
print(convert(n))

"""
每次可以走 1 步 或 2 步
求从 第 0 级走到第 n 级 有多少种不同的走法

解法：
f(n) 表示走到第 n 级台阶的总走法数
f(n) = f(n - 1) + f(n - 2)。要么是从 n-1 级走 1 步，要么是从 n-2 级走 2 步

初始条件（边界）：
f(0) = 1（0 级台阶，有一种什么都不走的走法）
f(1) = 1（只能一步到 1）
f(2) = 2（1+1 或 2）
"""

def f(n):
    if n == 0:
        return 1
    elif n == 1:
        return 1
    else:
        return f(n - 1)+f(n - 2)


n = int(input())
print(f(n))

"""
有n级台阶，每步可以走1级、3级或5级，走完n级台阶有多少种不同的走法

输入
整数n ( 1<=n <= 20)
输出
不同走法总数
样例输入
5
样例输出
5
"""

def f(n):
    if n == 1:
        return 1
    elif n == 2:
        return 1
    elif n == 3:
        return 2
    elif n == 4:
        return 3
    elif n==5:
        return 5
    else:
        return f(n - 1)+f(n - 3)+f(n-5)


n = int(input())
print(f(n))

"""
Cn = 1/(n+1) * C2n n = (2n)!/n!(n+1)!

有效括号匹配方式的总数（n 对括号）
栈的合法出栈序列个数（n 个元素）--push：相当于左括号 (;pop：相当于右括号 );
有多少种不同结构的完全二叉树（n 个节点）
从左下走到右上，不越过对角线的路径数（n×n 格子）
"""


"""
为了能形成合法的出栈序列，整个操作必须满足两个条件：
任何时刻，pop 的次数不能超过 push（否则栈空无法 pop）
最终 push 和 pop 次数都为n
"""

n = int(input())

def catalan(n):
    if n == 0 or n == 1:
        return 1
    catalan = [0] * (n + 1)
    catalan[0] = catalan[1] = 1
    for i in range(2, n + 1):
        for j in range(i):
            catalan[i] += catalan[j] * catalan[i - j - 1]
    return catalan[n]

print(catalan(n))

from functools import lru_cache

@lru_cache(None)
def fib(n):
    if n <= 1:
        return n
    return fib(n-1) + fib(n-2)

"""
@lru_cache
缓存函数的计算结果，避免对相同输入的重复计算，提高程序效率。
参数None表示缓存大小无限制，默认会缓存所有调用过的参数结果。

比如递归总fib会被多次调用，使用@lru_cache后，第一次计算某组参数的结果会被保存，下一次调用相同参数时直接返回缓存结果，不再重复计算。
"""

print(fib(6))

"""
描述
古代有一个梵塔，塔内有三个座A、B、C，A座上有n个盘子，盘子大小不等，大的在下，小的在上。三个座都可以用来放盘子。有一个和尚想把这n个盘子从A座移到C座，但每次只能允许移动一个盘子，并且在移动过程中，3个座上的盘子始终保持大盘在下，小盘在上。输入盘子数目n，要求输出移动的步骤。

输入
盘子数目n ( n < 8)
输出
移动方案
样例输入
3
样例输出
A->C
A->B
C->B
A->C
B->A
B->C
A->C
"""
"""
思路：递归
将 n-1 个盘子从 A 移动到 B，使用 C 作为中介。
将第 n 个盘子（最大的）从 A 移动到 C。
将 n-1 个盘子从 B 移动到 C，使用 A 作为中介。
"""

def hanoi(n,a,b,c):
    if n == 1:
        print(f'{a}->{c}')
        return
    else:
        hanoi(n-1,a,c,b)
        print(f'{a}->{c}')
        hanoi(n-1,b,a,c)

n=int(input())
hanoi(n,'A','B','C')

"""
有ｎ只猴子，按顺时针方向围成一圈选大王（编号从１到ｎ），从第１号开始报数，一直数到ｍ，数到ｍ的猴子退出圈外，剩下的猴子再接着从1开始报数。就这样，直到圈内只剩下一只猴子时，这个猴子就是猴王，编程求输入ｎ，ｍ后，输出最后猴王的编号。

输入
每行是用空格分开的两个整数，第一个是 n, 第二个是 m ( 0 < m,n <=300)。最后一行是：0 0

输出
对于每行输入数据（最后一行除外)，输出数据也是一行，即最后猴王的编号
样例输入
6 2
12 4
8 3
0 0
样例输出
5
1
7
"""
def josephus(n, m):
    monkeys = list(range(1, n + 1))
    index = 0
    while len(monkeys) > 1:
        index = (index + m - 1) % len(monkeys)
        monkeys.pop(index)
    return monkeys[0]
while True:
    n, m=map(int,input().split())
    if n == m == 0:
        break
    print(josephus(n,m))

"""
输入
输入包含多个测试用例。每个测试用例由一个整数 n 指定。输入以 n=0 结束。1<=n<=10 表示递归深度。

输出
对于每个测试用例，绘制一个边长总和为 2 n 个字符的 Sierpinski 三角形轮廓。将输出左对齐，即从第一列打印最底部的斜杠。输出不得包含任何尾随空格。每个测试用例后打印一个空行。

样例输入
3
2
1
0
样例输出
       /\
      /__\
     /\  /\
    /__\/__\
   /\      /\
  /__\    /__\
 /\  /\  /\  /\
/__\/__\/__\/__\

   /\
  /__\
 /\  /\
/__\/__\

 /\
/__\
"""

def draw(canvas,x,y,height):
    if height==2:
        canvas[x][y]='/'
        canvas[x][y+1]="\\"
        canvas[x+1][y-1]="/"
        canvas[x+1][y]="_"
        canvas[x + 1][y + 1] = "_"
        canvas[x+1][y+2]="\\"
    else:
        half=height//2
        draw(canvas,x,y,half)
        draw(canvas,x+half,y-half,half)
        draw(canvas,x+half,y+half,half)
    return canvas


while True:
    n = int(input())
    if n==0:
        break
    height=2**n
    width = 2*height
    canvas = [[' 'for _ in range(width)] for _ in range(height)]
    result = draw(canvas,0,height-1,height)
    for line in result:
        print("".join(line))
    print("")


"""
给定直角坐标系，x 轴为海岸线，上方为海洋，下方为陆地。海洋中有若干岛屿，每个岛屿的坐标为 (x, y)。现需在海岸线上安装雷达，每个雷达的覆盖半径为 d。求覆盖所有岛屿所需的最小雷达数量，若无法覆盖所有岛屿则输出 -1。

输入格式
    输入包含多组测试数据。
    每组数据首行包含两个整数 n（岛屿数量，1 ≤ n ≤ 1000）和 d（雷达覆盖半径）。
    随后 n 行，每行包含两个整数 x, y，表示岛屿坐标。
    每组数据后有一个空行分隔。
    输入以 0 0 结束。

输出格式
    对于每组数据，输出一行 Case k: m，其中 k 为测试数据编号，m 为最小雷达数量。若无法覆盖所有岛屿，输出 -1。

样例输入
3 2
1 2
-3 1
2 1

1 2
0 2

0 0

样例输出
Case 1: 2
Case 2: 1
"""
"""
贪心
对于每个岛屿，计算其在 x 轴上的投影区间（即雷达可以覆盖该岛屿的 x 坐标范围）
如果岛屿的 y 坐标超过 d，则直接判定无解
"""
import math

s = 0
while True:
    line = input().strip()
    while line == '':  # 跳过空行
        line = input().strip()
    n, d = map(int, line.split())
    if n == 0 and d == 0:
        break
    s += 1 #雷达编号
    x = []
    y = []
    flag = 0
    for _ in range(n):
        xi, yi = map(int, input().split())
        x.append(xi)
        y.append(yi)
        if yi > d:
            flag = -1
    if flag == -1:
        print(f"Case {s}: -1")
    else:
        f = [] # 存储每个岛屿对应的区间 雷达要是不在这个区间里就覆盖不了这个岛
        for i in range(n):
            k = math.sqrt(d*d - y[i]*y[i])
            left = x[i] - k
            right = x[i] + k
            f.append((left, right))
        # 按left排序
        f.sort(key=lambda item: item[0])
        num = 0 # 雷达数量
        p = -1e9  # 当前雷达的位置，初始化为负无穷
        for left, right in f:
            if left > p: #当前雷达无法覆盖这个岛屿
                num += 1 #新增一个雷达
                p = right #新雷达放在当前岛屿区间的 right 端
            elif right < p: #此时首先满足left <= p，而又p<right,因此当前雷达可以继续覆盖这个岛屿，可以把雷达位置再往左移动一点，以便覆盖更多后续的岛屿。
                p = right
                """
                假设你目前雷达的位置是 p = 10，现在处理的区间是 [6, 8]：
                6 <= p <= 8，说明当前雷达还能覆盖这个区间，但你发现 right = 8 < p = 10。
                那你就可以把雷达位置从 10 向左挪到 8，这样可能能覆盖下一个 [7, 9] 的区间。
                """

        print(f"Case {s}: {num}")

"""
找一个整数 x，使它除以 23 余 4，除以 28 余 5，除以 33 余 5
"""
"""
这个题是
第p, e, i天分别是体力、感情和智力的高峰，下次高峰分别为23天、28天和33天后，现在是第7天
求从给定时间（第七天）起，下一次三个高峰同天的时间
"""

def next_peak(p, e, i, d):
    day = d + 1
    while True:
        if (day - p) % 23 == 0 and (day - e) % 28 == 0 and (day - i) % 33 == 0:
            return day - d
        day += 1

# 输入处理
p, e, i, d = map(int, input().split()) #4 5 6 7
print(next_peak(p, e, i, d)) #16994

"""
描述
有 12 枚银币（标号 A-L），其中 1 枚为假币（重量与真币不同，可能轻或重），其余为真币。通过三次天平称量结果（每次称量给出左右两边硬币及平衡状态），判断哪枚是假币，并确定其比真币轻或重。

输入
第一行 n 为测试用例数。每组测试用例包含三行，每行三个字符串，依次为天平左边硬币、右边硬币、平衡状态（up/down/even）。

输出
对每组测试用例，输出假币标号及轻重（heavy/light），格式如 “A is the counterfeit coin and it is light”。

样例输入
1
ABCD EFGH even
ABCI EFJK up
ABIJ EFGH even
样例输出
K is the counterfeit coin and it is light.
"""
# 状态枚举
n = int(input())
for _ in range(n):
    coins = set('ABCDEFGHIJKL')
    one = input().split()
    two = input().split()
    three = input().split() # 分别读入各次尝试的数据
    real = set() # 一定真的硬币的集合
    posfakelight = set('ABCDEFGHIJKL') # 可能假且轻的硬币的集合
    posfakeheavy = set('ABCDEFGHIJKL') # 可能假且重的硬币的集合
    # 在没有数据输入的时候每一个都有可能是假的而且轻或者重，所以这两个集合开始时候应该为每一个硬币
    for i in [one, two, three]: # 对于每一个尝试
        if i[-1] == 'even': # 如果这一次尝试天平平衡
            real = real|set(i[0])|set(i[1]) # 取并集
        elif i[-1] == 'up': # 如果这一次尝试天平右端高
            posfakelight &= set(i[1]) # 右端的硬币可能轻 取交集
            posfakeheavy &= set(i[0]) # 左端的硬币可能重 取交集
        elif i[-1] == 'down': # 如果这一次尝试天平右端低
            posfakelight &= set(i[0]) # 左端的硬币可能轻
            posfakeheavy &= set(i[1]) # 右端的硬币可能重
        # 由于每次尝试都显示可能轻的硬币才是可能轻，所以应该取交集。
    for i in coins.difference(real): # 遍历在硬币集合和一定真硬币集合的差集中的硬币并按照其可能的轻或重输出。
        if i in posfakelight:
            print(f'{i} is the counterfeit coin and it is light.')
        elif i in posfakeheavy:
            print(f'{i} is the counterfeit coin and it is heavy.')

#由于每个移动操作执行次数为 0-3 次（4 次相当于没动），共有 9 种移动，总状态数为4的9次方=262144
#可以通过遍历所有可能的移动组合找到最优解

#mask 是一个 0 到 262143 之间的整数，我们把它看作是一个9位的4进制数（因为每个操作可取 0-3）
"""
输入
9个整数，表示各时钟指针的起始位置，相邻两个整数之间用单个空格隔开。其中，0=12点、1=3点、2=6点、3=9点。
输出
输出一个最短的移动序列，使得9个时钟的指针都指向12点。按照移动的序号从小到大输出结果。相邻两个整数之间用单个空格隔开。
样例输入
3 3 0
2 2 2
2 1 2
样例输出
4 5 8 9
"""
import sys

# 定义每个移动操作影响的时钟
moves = [
    [0, 1, 3, 4],  # 移动1: ABDE
    [0, 1, 2],  # 移动2: ABC
    [1, 2, 4, 5],  # 移动3: BCEF
    [0, 3, 6],  # 移动4: ADG
    [1, 3, 4, 5, 7],  # 移动5: BDEFH
    [2, 5, 8],  # 移动6: CFI
    [3, 4, 6, 7],  # 移动7: DEGH
    [6, 7, 8],  # 移动8: GHI
    [4, 5, 7, 8]  # 移动9: EFHI
]



# 读取输入
clocks = list(map(int, sys.stdin.read().split()))

min_moves = None
min_count = float('inf')

# 遍历所有可能的移动组合
for mask in range(4 ** 9): #遍历每一种可能
    # 把 mask 拆成 9 个 0~3 的数，放到 move_counts 里
    # 例如 mask = 123  => move_counts = [3, 2, 1, 1, 0, 0, 0, 0, 0] 即操作1执行3次、操作2执行2次……
    current_mask = mask
    # 记录每种可能下，每个操作的次数
    move_counts = [0] * 9
    for i in range(9):
        move_counts[i] = current_mask % 4 #取余
        current_mask //= 4 #整除

    # 计算当前组合下的最终时钟状态
    final_clocks = clocks.copy() #试探某个操作组合的效果，而不能修改原始输入 clocks.不 .copy()的话final_clocks 和 clocks 其实指向同一个列表对象，当修改 final_clocks[i] 时，clocks[i] 也会一起被改掉。
    for move_idx in range(9):
        count = move_counts[move_idx] #看每个操作进行了几次
        if count == 0:
            continue
        for clock_idx in moves[move_idx]: #对每个操作下的时钟进行拨动
            final_clocks[clock_idx] = (final_clocks[clock_idx] + count) % 4

    # 检查是否所有时钟都指向12点
    if all(c == 0 for c in final_clocks):
        # 计算总操作次数
        total = sum(move_counts)
        # 选择移动次数最少的组合
        if total < min_count:
            min_count = total
            min_moves = move_counts.copy()
        # 如果移动次数相同，选择字典序更小的组合
        elif total == min_count:
            # 比较字典序 列表之间的比较是按字典序进行的
            if move_counts < min_moves:
                min_moves = move_counts.copy()

# 生成结果
result = []
for move_idx in range(9):
    count = min_moves[move_idx] #每个操作的次数
    for _ in range(count): #要是这个操作的次数count>1 要连续输出这个操作
        result.append(move_idx + 1)  # 移动编号从1开始

# 输出结果
print(' '.join(map(str, result)))

"""
给定每部电影的放映时间区间，区间重叠的电影不可能同时看（端点可以重合），问李雷最多可以看多少部电影。

输入
多组数据。每组数据开头是n(n<=100)，表示共n场电影。
接下来n行，每行两个整数(0到1000之间)，表示一场电影的放映区间
n=0则数据结束
输出
对每组数据输出最多能看几部电影
样例输入
8
3 4
0 7
3 8
15 19
15 20
10 15
8 18
6 12
0
样例输出
3
"""
import sys


for line in sys.stdin:
    n = int(line.strip())
    if n == 0:
        break
    movies = []
    for _ in range(n):
        start, end = map(int, sys.stdin.readline().split())
        movies.append((end, start))  # 存储时以结束时间为第一关键字
    movies.sort()  # 按结束时间升序排序
    count = 0
    last_end = -1
    for end, start in movies:
        if start >= last_end:
            count += 1
            last_end = end
    print(count)


"""
农场有 N 头牛，每头牛会在一个特定的时间区间 [A, B]（包括 A 和 B）在畜栏里挤奶，且一个畜栏里同时只能有一头牛在挤奶。
求最少需要几个畜栏能满足所有牛的挤奶需求，并给出每头牛被安排的畜栏方案（输出一种即可）。

输入
输入的第一行包含一个整数N(1 ≤ N ≤ 50, 000)，表示有N牛头；接下来N行每行包含两个数，分别表示这头牛的挤奶时间[Ai, Bi](1 ≤ A≤ B ≤ 1, 000, 000)。
输出
输出的第一行包含一个整数，表示最少需要的畜栏数；接下来N行，第i+1行描述了第i头牛所被分配的畜栏编号（从1开始）。
样例输入
5
1 10
2 4
3 6
5 8
4 7
样例输出
4
1
2
3
2
4
"""
"""
最小堆:动态维护所有畜栏的当前结束时间
"""

import heapq
N = int(input())
cows = []
for i in range(1,N+1):
    start,end = map(int,input().split())
    cows.append((start,end,i)) #记录编号，因为后面cows会排序，会打乱编号，不好输出

cows.sort() #根据开始时间排序
stalls = [] #建立堆，每个元素是（此槽号结束时间，槽号）,结束时间由小到大，和创建空列表一样，但是后面添加和删除元素就是堆特有的,heap.__(里面要加元素)
# stalls只记录结束时间和槽号
assignment = [0]*(N+1) #记录每个牛分配的槽号
stall_num = 0

# 遍历牛
for start,end,i in cows:
    if stalls and stalls[0][0] < start:#用已有堆的情况：堆里有，且堆最早结束的时间小于这个牛的开始时间
        earliest_end,old_stall = heapq.heappop(stalls)
        heapq.heappush(stalls,(end,old_stall))
        assignment[i]=old_stall
    else: #要么是第一个入堆，要么前面的都不能用
        stall_num+=1
        heapq.heappush(stalls,(end,stall_num))
        assignment[i]=stall_num
print(stall_num)

for assign in assignment[1:]:
    print(assign)

"""
给定两个等长的由 '0' 和 '1' 构成的字符串 start_str 和 target_str，
通过“按按钮”改变状态（一个按钮会翻转自己和相邻按钮）,
计算最少需要按几次才能从 start_str 变成 target_str，否则输出 "impossible"。

如果按下中间的按钮 i，则影响 i-1, i, i+1
如果按下最左边按钮（i=0），只影响 0, 1
如果按下最右边按钮（i=n-1），只影响 n-2, n-1

从左往右贪心：
每一位，从左到右，如果当前位不对（当前状态不等于目标状态）
我们就必须按下下一位的按钮，以改变当前位（因为我们无法再改变左边了）
但是，第一个位置的改变必须通过按第0位来触发，因此我们需要枚举“第0位是否按下”的两种情况：
情况1：不按第0位
情况2：按下第0位
每种情况都模拟一次操作，最后比较操作次数，取较小的那个。
"""

def flip(state, i): #在 state（当前状态）中按下第 i 个按钮
    n = len(state)
    for j in [i - 1, i, i + 1]:
        if 0 <= j < n:
            state[j] = '0' if state[j] == '1' else '1' #'0' 变 '1'，'1' 变 '0'

def solve(start_str, target_str):
    n = len(start_str)
    res = float('inf')

    for first_press in [False, True]:  # 枚举第0个是否按
        count = 0
        state = list(start_str)

        if first_press: #如果按了第0个按钮，就调用 flip()，操作次数+1。
            flip(state, 0)
            count += 1

        # 贪心地决定接下来的按钮
        #每次看前一个位置 i-1 是否已经变成目标状态,如果没有，就必须按下当前这个按钮 i，以改变它左边那个（也会改变自己和右边）。
        for i in range(1, n):
            if state[i - 1] != target_str[i - 1]:
                flip(state, i)
                count += 1

        if ''.join(state) == target_str:
            res = min(res, count)

    return res if res != float('inf') else "impossible"

# 示例输入
start = input().strip()
target = input().strip()
print(solve(start, target))

# 只穷举第一行按钮的按法(共2的6次方种）根据第一行的按法，从上往下推导后续每一行的按法
"""
有一个由按钮组成的矩阵，其中每行有6个按钮，共5行。每个按钮的位置上有一盏灯。当按下一个按钮后，该按钮以及周围位置(上边、下边、左边、右边)的灯都会改变一次
请你写一个程序，确定需要按下哪些按钮，恰好使得所有的灯都熄灭。
根据上面的规则，我们知道
1）第2次按下同一个按钮时，将抵消第1次按下时所产生的结果。因此，每个按钮最多只需要按下一次；
2）各个按钮被按下的顺序对最终的结果没有影响；
3）对第1行中每盏点亮的灯，按下第2行对应的按钮，就可以熄灭第1行的全部灯。如此重复下去，可以熄灭第1、2、3、4行的全部灯。同样，按下第1、2、3、4、5列的按钮，可以熄灭前5列的灯。

输入
5行组成，每一行包括6个数字（0或1）。相邻两个数字之间用单个空格隔开。0表示灯的初始状态是熄灭的，1表示灯的初始状态是点亮的。
输出
5行组成，每一行包括6个数字（0或1）。相邻两个数字之间用单个空格隔开。其中的1表示需要把对应的按钮按下，0则表示不需要按对应的按钮。

样例输入
0 1 1 0 1 0
1 0 0 1 1 1
0 0 1 0 0 1
1 0 0 1 0 1
0 1 1 1 0 0
样例输出
1 0 1 0 0 1
1 1 0 1 0 1
0 0 1 0 1 1
1 0 0 1 0 0
0 1 0 0 0 0
"""

import copy

# 输入
start = [input().split() for _ in range(5)]


# 翻转函数
def flip(grid, r, c):
    for dr, dc in [(0, 0), (0, 1), (0, -1), (1, 0), (-1, 0)]:
        nr, nc = r + dr, c + dc
        if 0 <= nr < 5 and 0 <= nc < 6:
            grid[nr][nc] = '0' if grid[nr][nc] == '1' else '1'

# 解决函数
def solve(start):
    for mask in range(2**6):  # 枚举第一行的按法
        state = copy.deepcopy(start)
        press = [['0'] * 6 for _ in range(5)]

        # 按第一行
        for j in range(6):
            if (mask >> j) & 1: #第一行j列按了
                press[0][j] = '1'
                flip(state, 0, j)

        # 从第二行开始逐行决定按法
        for i in range(1, 5):
            for j in range(6):
                if state[i - 1][j] == '1':  # 如果上一行灯亮，必须按
                    press[i][j] = '1'
                    flip(state, i, j)

        # 检查最后一行是否全灭
        if all(state[4][j] == '0' for j in range(6)):
            return press

    return "impossible"

# 输出
ans = solve(start)
if ans == "impossible":
    print(ans)
else:
    for row in ans:
        print(" ".join(row))

"""
输入描述
第一行包含两个正整数，第一个整数 M 代表研究材料的种类，第二个正整数 N，代表小明的行李空间。
第二行包含 M 个正整数，代表每种研究材料的所占空间。 
第三行包含 M 个正整数，代表每种研究材料的价值。
6 1
2 2 3 1 5 2
2 3 1 5 4 3

输出描述
输出一个整数，代表小明能够携带的研究材料的最大价值。
"""
n, bagweight = map(int, input().split())

weight = list(map(int, input().split()))
value = list(map(int, input().split()))

dp = [[0] * (bagweight + 1) for _ in range(n)] #dp[i][j] 表示从下标为[0-i]的物品里任意取，放进容量为j的背包，价值总和最大是多少

for j in range(weight[0], bagweight + 1):
    dp[0][j] = value[0]

for i in range(1, n):
    for j in range(bagweight + 1):
        if j < weight[i]:
            dp[i][j] = dp[i - 1][j]
        else:
            dp[i][j] = max(dp[i - 1][j], dp[i - 1][j - weight[i]] + value[i])

print(dp[n - 1][bagweight])

"""
给定一个只包含正整数的非空数组。是否可以将这个数组分割成两个子集，使得两个子集的元素和相等。
示例 1:
输入: [1, 5, 11, 5]
输出: true
解释: 数组可以分割成 [1, 5, 5] 和 [11].
"""
class Solution:
    def canPartition(self, nums: List[int]) -> bool:

        total_sum = sum(nums)

        if total_sum % 2 != 0:
            return False

        target_sum = total_sum // 2
        dp = [[False] * (target_sum + 1) for _ in range(len(nums) + 1)]

        # 初始化第一行（空子集可以得到和为0）
        for i in range(len(nums) + 1):
            dp[i][0] = True

        for i in range(1, len(nums) + 1):
            for j in range(1, target_sum + 1):
                if j < nums[i - 1]:
                    # 当前数字大于目标和时，无法使用该数字
                    dp[i][j] = dp[i - 1][j]
                else:
                    # 当前数字小于等于目标和时，可以选择使用或不使用该数字
                    dp[i][j] = dp[i - 1][j] or dp[i - 1][j - nums[i - 1]]

        return dp[len(nums)][target_sum]

"""
输入： nums = [4, 3, 2, 3, 5, 2, 1], k = 4
输出： True
说明： 有可能将其分成 4 个子集（5），（1,4），（2,3），（2,3）等于总和。
"""
class Solution:
    def canPartitionKSubsets(self, nums: List[int], k: int) -> bool:
        all = sum(nums)
        if all % k:
            return False
        per = all // k
        nums.sort()
        if nums[-1] > per:
            return False
        n = len(nums)
        dp = [False] * (1 << n)
        dp[0] = True
        cursum = [0] * (1 << n)
        for i in range(0, 1 << n):
            if not dp[i]:
                continue
            for j in range(n):
                if cursum[i] + nums[j] > per:
                    break
                if (i >> j & 1) == 0:
                    next = i | (1 << j)
                    if not dp[next]:
                        cursum[next] = (cursum[i] + nums[j]) % per
                        dp[next] = True
        return dp[(1 << n) - 1]